// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.SphericalOperatorsExist
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Statements.EllipticCurveLevels.HasLevel public import Development.AbelianVarietyTheory.Statements.EllipticCurveLevels.ClosedAtLConclusionOfMem public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.ContinuousMapPFin public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.IsSubquotientDetRepParInd public import Development.AbelianVarietyTheory.Definitions.Foundations.IsSatVecUOfIsSphericalU public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.SatakeParameterSphericalProductSpehQuotients public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsIntPolyEsymmEqPowerSumMultiset public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.OpOfAevalExists public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.EsymmInvMulProd
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cong_SphOpsProof_zq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cong_SphOpsProof_zq___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cong_SphOpsProof_zq(lean_object* v_q_1_, lean_object* v_hq_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_box(0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cong_SphOpsProof_zq___boxed(lean_object* v_q_4_, lean_object* v_hq_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_tree_GlobalTheory_Cong_SphOpsProof_zq(v_q_4_, v_hq_5_);
lean_dec(v_q_4_);
return v_res_6_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_EllipticCurveLevels_HasLevel(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_EllipticCurveLevels_ClosedAtLConclusionOfMem(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_ContinuousMapPFin(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_IsSubquotientDetRepParInd(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_IsSatVecUOfIsSphericalU(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SatakeParameterSphericalProductSpehQuotients(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIntPolyEsymmEqPowerSumMultiset(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_OpOfAevalExists(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_EsymmInvMulProd(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_SphericalOperatorsExist(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_EllipticCurveLevels_HasLevel(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_EllipticCurveLevels_ClosedAtLConclusionOfMem(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_ContinuousMapPFin(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_IsSubquotientDetRepParInd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_IsSatVecUOfIsSphericalU(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SatakeParameterSphericalProductSpehQuotients(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIntPolyEsymmEqPowerSumMultiset(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_OpOfAevalExists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_EsymmInvMulProd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

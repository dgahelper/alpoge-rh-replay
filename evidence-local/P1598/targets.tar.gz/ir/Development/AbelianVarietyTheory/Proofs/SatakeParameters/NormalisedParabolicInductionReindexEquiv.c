// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.NormalisedParabolicInductionReindexEquiv
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ThetaMod public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HasFiniteLengthOfIsIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.ExistsCellOfIsSubquotient public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.UnlinkedProductIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.DepthZeroJacquetInjective public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ExistsInSupportOfMultiProd public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.InSupportOfIsSubquotient public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.NotInSupportOfSubsingleton public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.NonemptyEquivOfRangeEq public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ExistsEquivDetCharacterOfIrreducibleRankLeOne public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ParIndJacPlacing public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsEquivProdIrrTw public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsIrreducibleTensorOfJacquetSubquotient public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsSphericalTwistOfJacquetConstituentEmptyBlock
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg___lam__0(lean_object* v_00_u03c6_1_, lean_object* v_f_2_, lean_object* v___y_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; 
v___x_4_ = lean_apply_1(v_00_u03c6_1_, v___y_3_);
v___x_5_ = lean_apply_1(v_f_2_, v___x_4_);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg(lean_object* v_00_u03c6_6_){
_start:
{
lean_object* v___f_7_; 
v___f_7_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg___lam__0), 3, 1);
lean_closure_set(v___f_7_, 0, v_00_u03c6_6_);
return v___f_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull(lean_object* v_F_8_, lean_object* v_G_9_, lean_object* v_H_10_, lean_object* v_V_11_, lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_inst_14_, lean_object* v_inst_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_P_21_, lean_object* v_Q_22_, lean_object* v_00_u03c3_23_, lean_object* v_00_u03c4_24_, lean_object* v_00_u03c6_25_, lean_object* v_h_u03c6_26_, lean_object* v_h_27_){
_start:
{
lean_object* v___f_28_; 
v___f_28_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SmGL_Relabel_indPull___redArg___lam__0), 3, 1);
lean_closure_set(v___f_28_, 0, v_00_u03c6_25_);
return v___f_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SmGL_Relabel_indPull___boxed(lean_object** _args){
lean_object* v_F_29_ = _args[0];
lean_object* v_G_30_ = _args[1];
lean_object* v_H_31_ = _args[2];
lean_object* v_V_32_ = _args[3];
lean_object* v_inst_33_ = _args[4];
lean_object* v_inst_34_ = _args[5];
lean_object* v_inst_35_ = _args[6];
lean_object* v_inst_36_ = _args[7];
lean_object* v_inst_37_ = _args[8];
lean_object* v_inst_38_ = _args[9];
lean_object* v_inst_39_ = _args[10];
lean_object* v_inst_40_ = _args[11];
lean_object* v_inst_41_ = _args[12];
lean_object* v_P_42_ = _args[13];
lean_object* v_Q_43_ = _args[14];
lean_object* v_00_u03c3_44_ = _args[15];
lean_object* v_00_u03c4_45_ = _args[16];
lean_object* v_00_u03c6_46_ = _args[17];
lean_object* v_h_u03c6_47_ = _args[18];
lean_object* v_h_48_ = _args[19];
_start:
{
lean_object* v_res_49_; 
v_res_49_ = lp_tree_GlobalTheory_SmGL_Relabel_indPull(v_F_29_, v_G_30_, v_H_31_, v_V_32_, v_inst_33_, v_inst_34_, v_inst_35_, v_inst_36_, v_inst_37_, v_inst_38_, v_inst_39_, v_inst_40_, v_inst_41_, v_P_42_, v_Q_43_, v_00_u03c3_44_, v_00_u03c4_45_, v_00_u03c6_46_, v_h_u03c6_47_, v_h_48_);
lean_dec(v_00_u03c4_45_);
lean_dec(v_00_u03c3_44_);
lean_dec(v_inst_37_);
lean_dec_ref(v_inst_36_);
lean_dec_ref(v_inst_35_);
lean_dec_ref(v_inst_34_);
lean_dec_ref(v_inst_33_);
return v_res_49_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsInSupportOfMultiProd(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_InSupportOfIsSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_NotInSupportOfSubsingleton(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivOfRangeEq(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsEquivDetCharacterOfIrreducibleRankLeOne(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ParIndJacPlacing(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEquivProdIrrTw(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIrreducibleTensorOfJacquetSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsSphericalTwistOfJacquetConstituentEmptyBlock(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_NormalisedParabolicInductionReindexEquiv(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsInSupportOfMultiProd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_InSupportOfIsSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_NotInSupportOfSubsingleton(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivOfRangeEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsEquivDetCharacterOfIrreducibleRankLeOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ParIndJacPlacing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEquivProdIrrTw(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIrreducibleTensorOfJacquetSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsSphericalTwistOfJacquetConstituentEmptyBlock(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

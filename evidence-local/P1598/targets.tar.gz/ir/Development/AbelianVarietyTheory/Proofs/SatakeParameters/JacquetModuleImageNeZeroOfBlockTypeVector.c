// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.JacquetModuleImageNeZeroOfBlockTypeVector
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ThetaMod public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HasFiniteLengthOfIsIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.ExistsCellOfIsSubquotient public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.UnlinkedProductIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.DepthZeroJacquetInjective public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.TameBlockVectorJacquetNonzero
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Fin_cases___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_SmGL_stdBlocks___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecEmpty___boxed(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecCons___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_JacBlockTwo_sz___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_Matrix_vecEmpty___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_tree_GlobalTheory_JacBlockTwo_sz___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_JacBlockTwo_sz___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_sz(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_sz___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_JacBlockTwo_blocks2___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_JacBlockTwo_blocks2___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_sz(lean_object* v_r_2_, lean_object* v_t_3_, lean_object* v_a_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = ((lean_object*)(lp_tree_GlobalTheory_JacBlockTwo_sz___closed__0));
v___x_7_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_7_, 0, lean_box(0));
lean_closure_set(v___x_7_, 1, v___x_5_);
lean_closure_set(v___x_7_, 2, v_t_3_);
lean_closure_set(v___x_7_, 3, v___x_6_);
v___x_8_ = l_Fin_cases___redArg(v_r_2_, v___x_7_, v_a_4_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_sz___boxed(lean_object* v_r_9_, lean_object* v_t_10_, lean_object* v_a_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_JacBlockTwo_sz(v_r_9_, v_t_10_, v_a_11_);
lean_dec(v_a_11_);
lean_dec(v_r_9_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0(lean_object* v___y_13_){
_start:
{
lean_internal_panic_unreachable();
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0___boxed(lean_object* v___y_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__0(v___y_14_);
lean_dec(v___y_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1(lean_object* v_t_16_, lean_object* v___f_17_, lean_object* v___y_18_){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = l_Fin_cases___redArg(v_t_16_, v___f_17_, v___y_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1___boxed(lean_object* v_t_20_, lean_object* v___f_21_, lean_object* v___y_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1(v_t_20_, v___f_21_, v___y_22_);
lean_dec(v___y_22_);
lean_dec(v_t_20_);
return v_res_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2(lean_object* v_r_24_, lean_object* v___f_25_, lean_object* v___y_26_){
_start:
{
lean_object* v___x_27_; 
v___x_27_ = l_Fin_cases___redArg(v_r_24_, v___f_25_, v___y_26_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2___boxed(lean_object* v_r_28_, lean_object* v___f_29_, lean_object* v___y_30_){
_start:
{
lean_object* v_res_31_; 
v_res_31_ = lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2(v_r_28_, v___f_29_, v___y_30_);
lean_dec(v___y_30_);
lean_dec(v_r_28_);
return v_res_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JacBlockTwo_blocks2(lean_object* v_r_33_, lean_object* v_t_34_){
_start:
{
lean_object* v___f_35_; lean_object* v___f_36_; lean_object* v___f_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; 
v___f_35_ = ((lean_object*)(lp_tree_GlobalTheory_JacBlockTwo_blocks2___closed__0));
lean_inc(v_t_34_);
v___f_36_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__1___boxed), 3, 2);
lean_closure_set(v___f_36_, 0, v_t_34_);
lean_closure_set(v___f_36_, 1, v___f_35_);
lean_inc(v_r_33_);
v___f_37_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_JacBlockTwo_blocks2___lam__2___boxed), 3, 2);
lean_closure_set(v___f_37_, 0, v_r_33_);
lean_closure_set(v___f_37_, 1, v___f_36_);
v___x_38_ = lean_unsigned_to_nat(2u);
v___x_39_ = lean_nat_add(v_r_33_, v_t_34_);
lean_dec(v_t_34_);
lean_dec(v_r_33_);
v___x_40_ = lp_tree_GlobalTheory_SmGL_stdBlocks___redArg(v___x_38_, v___x_39_, v___f_37_);
lean_dec(v___x_39_);
return v___x_40_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_TameBlockVectorJacquetNonzero(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_JacquetModuleImageNeZeroOfBlockTypeVector(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_TameBlockVectorJacquetNonzero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

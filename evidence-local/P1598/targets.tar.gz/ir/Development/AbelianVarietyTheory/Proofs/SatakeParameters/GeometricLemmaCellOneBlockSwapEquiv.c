// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.GeometricLemmaCellOneBlockSwapEquiv
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ThetaMod public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HasFiniteLengthOfIsIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.ExistsCellOfIsSubquotient public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.UnlinkedProductIrreducible public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.DepthZeroJacquetInjective public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ExistsInSupportOfMultiProd public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.InSupportOfIsSubquotient public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.NotInSupportOfSubsingleton public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.NonemptyEquivOfRangeEq public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ExistsEquivDetCharacterOfIrreducibleRankLeOne public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ParIndJacPlacing public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsEquivProdIrrTw public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsIrreducibleTensorOfJacquetSubquotient public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.IsSphericalTwistOfJacquetConstituentEmptyBlock
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__1(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0(lean_object* v_p_1_){
_start:
{
lean_object* v_snd_2_; 
v_snd_2_ = lean_ctor_get(v_p_1_, 1);
lean_inc(v_snd_2_);
return v_snd_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0___boxed(lean_object* v_p_3_){
_start:
{
lean_object* v_res_4_; 
v_res_4_ = lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__0(v_p_3_);
lean_dec_ref(v_p_3_);
return v_res_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__1(lean_object* v_a_u2080_5_, lean_object* v_x_6_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_7_, 0, v_a_u2080_5_);
lean_ctor_set(v___x_7_, 1, v_x_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg(lean_object* v_a_u2080_9_){
_start:
{
lean_object* v___f_10_; lean_object* v___f_11_; lean_object* v___x_12_; 
v___f_10_ = ((lean_object*)(lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___closed__0));
v___f_11_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg___lam__1), 2, 1);
lean_closure_set(v___f_11_, 0, v_a_u2080_9_);
v___x_12_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_12_, 0, v___f_10_);
lean_ctor_set(v___x_12_, 1, v___f_11_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv(lean_object* v_00_u03b2_13_, lean_object* v_n_14_, lean_object* v_t_15_, lean_object* v_a_u2080_16_, lean_object* v_ha_u2080_17_, lean_object* v_h0_18_){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = lp_tree_GlobalTheory_OneBlockCell_valEquiv___redArg(v_a_u2080_16_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_OneBlockCell_valEquiv___boxed(lean_object* v_00_u03b2_20_, lean_object* v_n_21_, lean_object* v_t_22_, lean_object* v_a_u2080_23_, lean_object* v_ha_u2080_24_, lean_object* v_h0_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GlobalTheory_OneBlockCell_valEquiv(v_00_u03b2_20_, v_n_21_, v_t_22_, v_a_u2080_23_, v_ha_u2080_24_, v_h0_25_);
lean_dec(v_t_22_);
lean_dec_ref(v_n_21_);
return v_res_26_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsInSupportOfMultiProd(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_InSupportOfIsSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_NotInSupportOfSubsingleton(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivOfRangeEq(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsEquivDetCharacterOfIrreducibleRankLeOne(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ParIndJacPlacing(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEquivProdIrrTw(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIrreducibleTensorOfJacquetSubquotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsSphericalTwistOfJacquetConstituentEmptyBlock(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_GeometricLemmaCellOneBlockSwapEquiv(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ThetaMod(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HasFiniteLengthOfIsIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_ExistsCellOfIsSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_UnlinkedProductIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_DepthZeroJacquetInjective(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsInSupportOfMultiProd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_InSupportOfIsSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_NotInSupportOfSubsingleton(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivOfRangeEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsEquivDetCharacterOfIrreducibleRankLeOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ParIndJacPlacing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEquivProdIrrTw(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsIrreducibleTensorOfJacquetSubquotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_IsSphericalTwistOfJacquetConstituentEmptyBlock(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

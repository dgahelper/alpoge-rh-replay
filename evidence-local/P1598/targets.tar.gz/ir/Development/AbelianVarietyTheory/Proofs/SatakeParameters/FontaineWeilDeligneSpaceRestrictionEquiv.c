// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.SatakeParameters.FontaineWeilDeligneSpaceRestrictionEquiv
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.RestrictsSelf public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.DeRhamPotSemistable public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.WeilDeligneParamAboveLIndependentLocalEmbedding public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.NormVZpowDegEq
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0___boxed(lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_Pst_ResLetter_toRes___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_Pst_ResLetter_toRes___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_ofRes(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_ofRes___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0(lean_object* v_x_1_){
_start:
{
lean_inc(v_x_1_);
return v_x_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0___boxed(lean_object* v_x_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_tree_GlobalTheory_Pst_ResLetter_toRes___lam__0(v_x_2_);
lean_dec(v_x_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes(lean_object* v_l_5_, lean_object* v_inst_6_, lean_object* v_P_7_, lean_object* v_LL_8_, lean_object* v_V_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_K_14_, lean_object* v_K_x27_15_, lean_object* v_00_u03c1_16_, lean_object* v_hle_17_){
_start:
{
lean_object* v___f_18_; 
v___f_18_ = ((lean_object*)(lp_tree_GlobalTheory_Pst_ResLetter_toRes___closed__0));
return v___f_18_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_toRes___boxed(lean_object* v_l_19_, lean_object* v_inst_20_, lean_object* v_P_21_, lean_object* v_LL_22_, lean_object* v_V_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_K_28_, lean_object* v_K_x27_29_, lean_object* v_00_u03c1_30_, lean_object* v_hle_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_GlobalTheory_Pst_ResLetter_toRes(v_l_19_, v_inst_20_, v_P_21_, v_LL_22_, v_V_23_, v_inst_24_, v_inst_25_, v_inst_26_, v_inst_27_, v_K_28_, v_K_x27_29_, v_00_u03c1_30_, v_hle_31_);
lean_dec(v_00_u03c1_30_);
lean_dec(v_inst_26_);
lean_dec(v_inst_25_);
lean_dec_ref(v_inst_24_);
lean_dec_ref(v_P_21_);
lean_dec(v_l_19_);
return v_res_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_ofRes(lean_object* v_l_33_, lean_object* v_inst_34_, lean_object* v_P_35_, lean_object* v_LL_36_, lean_object* v_V_37_, lean_object* v_inst_38_, lean_object* v_inst_39_, lean_object* v_inst_40_, lean_object* v_inst_41_, lean_object* v_K_42_, lean_object* v_K_x27_43_, lean_object* v_00_u03c1_44_, lean_object* v_hle_45_){
_start:
{
lean_object* v___f_46_; 
v___f_46_ = ((lean_object*)(lp_tree_GlobalTheory_Pst_ResLetter_toRes___closed__0));
return v___f_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Pst_ResLetter_ofRes___boxed(lean_object* v_l_47_, lean_object* v_inst_48_, lean_object* v_P_49_, lean_object* v_LL_50_, lean_object* v_V_51_, lean_object* v_inst_52_, lean_object* v_inst_53_, lean_object* v_inst_54_, lean_object* v_inst_55_, lean_object* v_K_56_, lean_object* v_K_x27_57_, lean_object* v_00_u03c1_58_, lean_object* v_hle_59_){
_start:
{
lean_object* v_res_60_; 
v_res_60_ = lp_tree_GlobalTheory_Pst_ResLetter_ofRes(v_l_47_, v_inst_48_, v_P_49_, v_LL_50_, v_V_51_, v_inst_52_, v_inst_53_, v_inst_54_, v_inst_55_, v_K_56_, v_K_x27_57_, v_00_u03c1_58_, v_hle_59_);
lean_dec(v_00_u03c1_58_);
lean_dec(v_inst_54_);
lean_dec(v_inst_53_);
lean_dec_ref(v_inst_52_);
lean_dec_ref(v_P_49_);
lean_dec(v_l_47_);
return v_res_60_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_RestrictsSelf(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DeRhamPotSemistable(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_WeilDeligneParamAboveLIndependentLocalEmbedding(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_NormVZpowDegEq(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_FontaineWeilDeligneSpaceRestrictionEquiv(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_RestrictsSelf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DeRhamPotSemistable(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_WeilDeligneParamAboveLIndependentLocalEmbedding(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_NormVZpowDegEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

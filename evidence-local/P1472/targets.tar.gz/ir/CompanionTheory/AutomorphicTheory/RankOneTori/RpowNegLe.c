// Lean compiler output
// Module: CompanionTheory.AutomorphicTheory.RankOneTori.RpowNegLe
// Imports: public import Init public meta import Init public import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RootLatticeThresholds.CompactCellConvergence.CellConvergence public import Formalism.SharpRestriction.CuspSpanNormBounds.SLemOm public import Formalism.PeriodIntegrals.UnitaryGroupMassFormula.UnitaryQuotientCompactness.UnipotentRadicalContracting public import Formalism.HermitianCurvature.HermitianCurvatureProofs.LUFactorOrbitBounds public import Formalism.HermitianCurvature.HermitianCurvatureProofs.VectorVanishesBigCell public import Formalism.HermitianCurvature.HermitianCurvatureProofs.TwoByOneBlock public import Formalism.HermitianCurvature.HermitianCurvatureProofs.BigCellHermitian public import Formalism.SharpRestriction.CuspSpanNormBounds.FrobeniusCoefficientMemLp.SigmaFiniteAmplitudes.FlipOneTwo
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_FlagStabilizerTensors_RootLatticeThresholds_CompactCellConvergence_CellConvergence(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_CuspSpanNormBounds_SLemOm(uint8_t builtin);
lean_object* initialize_tree_Formalism_PeriodIntegrals_UnitaryGroupMassFormula_UnitaryQuotientCompactness_UnipotentRadicalContracting(uint8_t builtin);
lean_object* initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_LUFactorOrbitBounds(uint8_t builtin);
lean_object* initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_VectorVanishesBigCell(uint8_t builtin);
lean_object* initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_TwoByOneBlock(uint8_t builtin);
lean_object* initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_BigCellHermitian(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_CuspSpanNormBounds_FrobeniusCoefficientMemLp_SigmaFiniteAmplitudes_FlipOneTwo(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_RankOneTori_RpowNegLe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_FlagStabilizerTensors_RootLatticeThresholds_CompactCellConvergence_CellConvergence(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_CuspSpanNormBounds_SLemOm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_PeriodIntegrals_UnitaryGroupMassFormula_UnitaryQuotientCompactness_UnipotentRadicalContracting(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_LUFactorOrbitBounds(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_VectorVanishesBigCell(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_TwoByOneBlock(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_HermitianCurvature_HermitianCurvatureProofs_BigCellHermitian(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_CuspSpanNormBounds_FrobeniusCoefficientMemLp_SigmaFiniteAmplitudes_FlipOneTwo(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

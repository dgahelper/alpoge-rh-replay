// Lean compiler output
// Module: CompanionTheory.AutomorphicTheory.ProductFormulaTheory.GrothendieckRingPolynomial.TriSupportedLe
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.AutomorphicTheory.ProductFormulaTheory.GrothendieckRingPolynomial.ProdList
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___redArg(lean_object* v_00_u03c8_1_){
_start:
{
lean_inc_ref(v_00_u03c8_1_);
return v_00_u03c8_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___redArg___boxed(lean_object* v_00_u03c8_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___redArg(v_00_u03c8_2_);
lean_dec_ref(v_00_u03c8_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg(lean_object* v_00_u03c3_4_, lean_object* v_00_u03c8_5_){
_start:
{
lean_inc_ref(v_00_u03c8_5_);
return v_00_u03c8_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg___boxed(lean_object* v_00_u03c3_6_, lean_object* v_00_u03c8_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_CompanionTheory_Groth_ChartWirtingerDerivatives_toZAlg(v_00_u03c3_6_, v_00_u03c8_7_);
lean_dec_ref(v_00_u03c8_7_);
return v_res_8_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_ProdList(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_TriSupportedLe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_ProdList(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

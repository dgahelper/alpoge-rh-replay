// Lean compiler output
// Module: CompanionTheory.AutomorphicTheory.ProductFormulaTheory.GrothendieckRingPolynomial.SingleEqSmulSingle
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.AutomorphicTheory.ProductFormulaTheory.GrothendieckRingPolynomial.ProdList
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lp_mathlib_Finsupp_sum___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___boxed(lean_object*);
static const lean_closure_object lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__0 = (const lean_object*)&lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__0_value;
static const lean_ctor_object lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__0_value)}};
static const lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__1 = (const lean_object*)&lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_CompanionTheory_Groth_toR___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_CompanionTheory_Groth_toR___closed__0;
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_toR(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_toR___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0(lean_object* v_m_1_, lean_object* v_C_2_, lean_object* v_x_3_, lean_object* v_toZSMul_4_, lean_object* v_y_5_, lean_object* v_n_6_){
_start:
{
lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; 
v___x_7_ = lean_int_mul(v_m_1_, v_n_6_);
v___x_8_ = lean_apply_2(v_C_2_, v_x_3_, v_y_5_);
v___x_9_ = lean_apply_2(v_toZSMul_4_, v___x_7_, v___x_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0___boxed(lean_object* v_m_10_, lean_object* v_C_11_, lean_object* v_x_12_, lean_object* v_toZSMul_13_, lean_object* v_y_14_, lean_object* v_n_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0(v_m_10_, v_C_11_, v_x_12_, v_toZSMul_13_, v_y_14_, v_n_15_);
lean_dec(v_n_15_);
lean_dec(v_m_10_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1(lean_object* v_C_17_, lean_object* v_toZSMul_18_, lean_object* v_toAddMonoid_19_, lean_object* v_b_20_, lean_object* v_x_21_, lean_object* v_m_22_){
_start:
{
lean_object* v___f_23_; lean_object* v___x_24_; 
v___f_23_ = lean_alloc_closure((void*)(lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__0___boxed), 6, 4);
lean_closure_set(v___f_23_, 0, v_m_22_);
lean_closure_set(v___f_23_, 1, v_C_17_);
lean_closure_set(v___f_23_, 2, v_x_21_);
lean_closure_set(v___f_23_, 3, v_toZSMul_18_);
v___x_24_ = lp_mathlib_Finsupp_sum___redArg(v_toAddMonoid_19_, v_b_20_, v___f_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1___boxed(lean_object* v_C_25_, lean_object* v_toZSMul_26_, lean_object* v_toAddMonoid_27_, lean_object* v_b_28_, lean_object* v_x_29_, lean_object* v_m_30_){
_start:
{
lean_object* v_res_31_; 
v_res_31_ = lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1(v_C_25_, v_toZSMul_26_, v_toAddMonoid_27_, v_b_28_, v_x_29_, v_m_30_);
lean_dec_ref(v_toAddMonoid_27_);
return v_res_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg(lean_object* v_inst_32_, lean_object* v_C_33_, lean_object* v_a_34_, lean_object* v_b_35_){
_start:
{
lean_object* v_toAddMonoid_36_; lean_object* v_toZSMul_37_; lean_object* v___f_38_; lean_object* v___x_39_; 
v_toAddMonoid_36_ = lean_ctor_get(v_inst_32_, 0);
lean_inc_ref_n(v_toAddMonoid_36_, 2);
v_toZSMul_37_ = lean_ctor_get(v_inst_32_, 3);
lean_inc(v_toZSMul_37_);
lean_dec_ref(v_inst_32_);
v___f_38_ = lean_alloc_closure((void*)(lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg___lam__1___boxed), 6, 4);
lean_closure_set(v___f_38_, 0, v_C_33_);
lean_closure_set(v___f_38_, 1, v_toZSMul_37_);
lean_closure_set(v___f_38_, 2, v_toAddMonoid_36_);
lean_closure_set(v___f_38_, 3, v_b_35_);
v___x_39_ = lp_mathlib_Finsupp_sum___redArg(v_toAddMonoid_36_, v_a_34_, v___f_38_);
lean_dec_ref(v_toAddMonoid_36_);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_GrothendieckRing_bil(lean_object* v_00_u03b9_40_, lean_object* v_M_41_, lean_object* v_inst_42_, lean_object* v_C_43_, lean_object* v_a_44_, lean_object* v_b_45_){
_start:
{
lean_object* v___x_46_; 
v___x_46_ = lp_tree_CompanionTheory_Groth_GrothendieckRing_bil___redArg(v_inst_42_, v_C_43_, v_a_44_, v_b_45_);
return v___x_46_;
}
}
static lean_object* _init_lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0(void){
_start:
{
lean_object* v___x_47_; lean_object* v___x_48_; 
v___x_47_ = lean_unsigned_to_nat(0u);
v___x_48_ = lean_nat_to_int(v___x_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0(lean_object* v_x_49_){
_start:
{
lean_object* v___x_50_; 
v___x_50_ = lean_obj_once(&lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0, &lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0_once, _init_lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___closed__0);
return v___x_50_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0___boxed(lean_object* v_x_51_){
_start:
{
lean_object* v_res_52_; 
v_res_52_ = lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___lam__0(v_x_51_);
lean_dec_ref(v_x_51_);
return v_res_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4(lean_object* v_k_57_, lean_object* v_inst_58_, lean_object* v_inst_59_, lean_object* v_inst_60_, lean_object* v_inst_61_){
_start:
{
lean_object* v___x_62_; 
v___x_62_ = ((lean_object*)(lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___closed__1));
return v___x_62_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_instCommRingR___aux__4___boxed(lean_object* v_k_63_, lean_object* v_inst_64_, lean_object* v_inst_65_, lean_object* v_inst_66_, lean_object* v_inst_67_){
_start:
{
lean_object* v_res_68_; 
v_res_68_ = lp_tree_CompanionTheory_Groth_instCommRingR___aux__4(v_k_63_, v_inst_64_, v_inst_65_, v_inst_66_, v_inst_67_);
lean_dec_ref(v_inst_64_);
return v_res_68_;
}
}
static lean_object* _init_lp_tree_CompanionTheory_Groth_toR___closed__0(void){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_toR(lean_object* v_k_70_, lean_object* v_inst_71_, lean_object* v_inst_72_, lean_object* v_inst_73_, lean_object* v_inst_74_, lean_object* v_inst_75_, lean_object* v_inst_76_, lean_object* v_inst_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lean_obj_once(&lp_tree_CompanionTheory_Groth_toR___closed__0, &lp_tree_CompanionTheory_Groth_toR___closed__0_once, _init_lp_tree_CompanionTheory_Groth_toR___closed__0);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Groth_toR___boxed(lean_object* v_k_79_, lean_object* v_inst_80_, lean_object* v_inst_81_, lean_object* v_inst_82_, lean_object* v_inst_83_, lean_object* v_inst_84_, lean_object* v_inst_85_, lean_object* v_inst_86_){
_start:
{
lean_object* v_res_87_; 
v_res_87_ = lp_tree_CompanionTheory_Groth_toR(v_k_79_, v_inst_80_, v_inst_81_, v_inst_82_, v_inst_83_, v_inst_84_, v_inst_85_, v_inst_86_);
lean_dec_ref(v_inst_80_);
return v_res_87_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_ProdList(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_SingleEqSmulSingle(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_GrothendieckRingPolynomial_ProdList(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

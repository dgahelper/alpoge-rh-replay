// Lean compiler output
// Module: CompanionTheory.AutomorphicTheory.ProductFormulaTheory.CuspidalExhaustion.CuspEmbP
// Imports: public import Init public meta import Init public import Mathlib public import Development.WeilBound.CoreStatements.TemperedRepresentationTheory.ZelevinskyJacquet.ZelevinskyExhaustion.PeelDefs public import CompanionTheory.AutomorphicTheory.TemperedLocalSpectra.ZelevinskyClassification.PropsCos public import Development.WeilBound.CoreStatements.TemperedRepresentationTheory.MirabolicDerivatives.SegmentCuspLines.ProdIrrFiniteLength
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_GlobalTheory_SmGL_Segment_first___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_SmGL_Segment_ofFirst___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___redArg(lean_object* v_00_u0394_1_){
_start:
{
lean_object* v_len_2_; lean_object* v___x_3_; lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v_len_2_ = lean_ctor_get(v_00_u0394_1_, 2);
v___x_3_ = lp_tree_GlobalTheory_SmGL_Segment_first___redArg(v_00_u0394_1_);
v___x_4_ = lean_unsigned_to_nat(1u);
v___x_5_ = lean_nat_add(v_len_2_, v___x_4_);
v___x_6_ = lp_tree_GlobalTheory_SmGL_Segment_ofFirst___redArg(v___x_3_, v___x_5_);
lean_dec_ref(v___x_3_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___redArg___boxed(lean_object* v_00_u0394_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_CompanionTheory_Exh_up___redArg(v_00_u0394_7_);
lean_dec_ref(v_00_u0394_7_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up(lean_object* v_k_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_00_u0394_14_){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lp_tree_CompanionTheory_Exh_up___redArg(v_00_u0394_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_Exh_up___boxed(lean_object* v_k_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_00_u0394_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree_CompanionTheory_Exh_up(v_k_16_, v_inst_17_, v_inst_18_, v_inst_19_, v_inst_20_, v_00_u0394_21_);
lean_dec_ref(v_00_u0394_21_);
lean_dec_ref(v_inst_17_);
return v_res_22_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_ZelevinskyJacquet_ZelevinskyExhaustion_PeelDefs(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_TemperedLocalSpectra_ZelevinskyClassification_PropsCos(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_MirabolicDerivatives_SegmentCuspLines_ProdIrrFiniteLength(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_ProductFormulaTheory_CuspidalExhaustion_CuspEmbP(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_ZelevinskyJacquet_ZelevinskyExhaustion_PeelDefs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_AutomorphicTheory_TemperedLocalSpectra_ZelevinskyClassification_PropsCos(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_MirabolicDerivatives_SegmentCuspLines_ProdIrrFiniteLength(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AnalyticIntertwiners.GelfandCentralHolds
// Imports: public import Init public meta import Init public import CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AnalyticIntertwiners.SubquotientNontrivial public import Development.WeilBound.HeckeVectors.SmoothVectors.SobolevApproximation.SobApproxHolds public import Formalism.LocalToGlobal.IndefiniteReal.SmExpSmulContDiff public import Formalism.LocalToGlobal.SiegelLatticeTheory.CasimirReductionTheory.OneParameterDerivatives.AdmissibleCasimirScalars.CasScalar public import CompanionTheory.AutomorphicTheory.HarishChandraMultiplicity.HCMult
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_HarishChandraModules_KFiniteAnalyticVectors_AnalyticIntertwiners_SubquotientNontrivial(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_HeckeVectors_SmoothVectors_SobolevApproximation_SobApproxHolds(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_SmExpSmulContDiff(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_CasimirReductionTheory_OneParameterDerivatives_AdmissibleCasimirScalars_CasScalar(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_AutomorphicTheory_HarishChandraMultiplicity_HCMult(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_HarishChandraModules_KFiniteAnalyticVectors_AnalyticIntertwiners_GelfandCentralHolds(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_HarishChandraModules_KFiniteAnalyticVectors_AnalyticIntertwiners_SubquotientNontrivial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_HeckeVectors_SmoothVectors_SobolevApproximation_SobApproxHolds(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_SmExpSmulContDiff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_CasimirReductionTheory_OneParameterDerivatives_AdmissibleCasimirScalars_CasScalar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_AutomorphicTheory_HarishChandraMultiplicity_HCMult(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

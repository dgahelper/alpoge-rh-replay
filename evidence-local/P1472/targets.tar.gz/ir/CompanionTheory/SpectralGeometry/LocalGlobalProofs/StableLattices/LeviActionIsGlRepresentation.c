// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LeviActionIsGlRepresentation
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.Bdy public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.OrderedCreationCommutesPastLevi
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0;
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___x_4_ = lp_mathlib_Complex_ofReal(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(lean_object* v_a_5_, lean_object* v_b_6_){
_start:
{
uint8_t v___x_7_; 
v___x_7_ = lean_nat_dec_eq(v_a_5_, v_b_6_);
if (v___x_7_ == 0)
{
lean_object* v___x_8_; 
v___x_8_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__0);
return v___x_8_;
}
else
{
lean_object* v___x_9_; 
v___x_9_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___closed__1);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg___boxed(lean_object* v_a_10_, lean_object* v_b_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_a_10_, v_b_11_);
lean_dec(v_b_11_);
lean_dec(v_a_10_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl(lean_object* v_n_13_, lean_object* v_a_14_, lean_object* v_b_15_){
_start:
{
lean_object* v___x_16_; 
v___x_16_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_a_14_, v_b_15_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___boxed(lean_object* v_n_17_, lean_object* v_a_18_, lean_object* v_b_19_){
_start:
{
lean_object* v_res_20_; 
v_res_20_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl(v_n_17_, v_a_18_, v_b_19_);
lean_dec(v_b_19_);
lean_dec(v_a_18_);
lean_dec(v_n_17_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg(lean_object* v_p_21_, lean_object* v_q_22_, lean_object* v_s_23_, lean_object* v_t_24_){
_start:
{
lean_object* v_fst_25_; lean_object* v_snd_26_; lean_object* v_fst_27_; lean_object* v_snd_28_; lean_object* v___x_29_; lean_object* v_re_30_; lean_object* v_im_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v_re_34_; lean_object* v_im_35_; lean_object* v___x_36_; lean_object* v_re_37_; lean_object* v_im_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v_re_41_; lean_object* v_im_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v_re_45_; lean_object* v_im_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v_re_49_; lean_object* v_im_50_; lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_61_; 
v_fst_25_ = lean_ctor_get(v_s_23_, 0);
v_snd_26_ = lean_ctor_get(v_s_23_, 1);
v_fst_27_ = lean_ctor_get(v_t_24_, 0);
v_snd_28_ = lean_ctor_get(v_t_24_, 1);
v___x_29_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_q_22_, v_fst_25_);
v_re_30_ = lean_ctor_get(v___x_29_, 0);
lean_inc(v_re_30_);
v_im_31_ = lean_ctor_get(v___x_29_, 1);
lean_inc(v_im_31_);
lean_dec_ref(v___x_29_);
v___x_32_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_fst_27_, v_p_21_);
v___x_33_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_30_, v_im_31_, v___x_32_);
v_re_34_ = lean_ctor_get(v___x_33_, 0);
lean_inc(v_re_34_);
v_im_35_ = lean_ctor_get(v___x_33_, 1);
lean_inc(v_im_35_);
lean_dec_ref(v___x_33_);
v___x_36_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_snd_26_, v_p_21_);
v_re_37_ = lean_ctor_get(v___x_36_, 0);
lean_inc(v_re_37_);
v_im_38_ = lean_ctor_get(v___x_36_, 1);
lean_inc(v_im_38_);
lean_dec_ref(v___x_36_);
v___x_39_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_fst_27_, v_fst_25_);
v___x_40_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_37_, v_im_38_, v___x_39_);
v_re_41_ = lean_ctor_get(v___x_40_, 0);
lean_inc(v_re_41_);
v_im_42_ = lean_ctor_get(v___x_40_, 1);
lean_inc(v_im_42_);
lean_dec_ref(v___x_40_);
v___x_43_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_snd_28_, v_snd_26_);
v___x_44_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_34_, v_im_35_, v___x_43_);
v_re_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_re_45_);
v_im_46_ = lean_ctor_get(v___x_44_, 1);
lean_inc(v_im_46_);
lean_dec_ref(v___x_44_);
v___x_47_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_dl___redArg(v_snd_28_, v_q_22_);
v___x_48_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_41_, v_im_42_, v___x_47_);
v_re_49_ = lean_ctor_get(v___x_48_, 0);
v_im_50_ = lean_ctor_get(v___x_48_, 1);
v_isSharedCheck_61_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_61_ == 0)
{
v___x_52_ = v___x_48_;
v_isShared_53_ = v_isSharedCheck_61_;
goto v_resetjp_51_;
}
else
{
lean_inc(v_im_50_);
lean_inc(v_re_49_);
lean_dec(v___x_48_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_61_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___f_54_; lean_object* v___f_55_; lean_object* v___f_56_; lean_object* v___f_57_; lean_object* v___x_59_; 
v___f_54_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_54_, 0, v_re_49_);
v___f_55_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_55_, 0, v_re_45_);
lean_closure_set(v___f_55_, 1, v___f_54_);
v___f_56_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_56_, 0, v_im_50_);
v___f_57_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_57_, 0, v_im_46_);
lean_closure_set(v___f_57_, 1, v___f_56_);
if (v_isShared_53_ == 0)
{
lean_ctor_set(v___x_52_, 1, v___f_57_);
lean_ctor_set(v___x_52_, 0, v___f_55_);
v___x_59_ = v___x_52_;
goto v_reusejp_58_;
}
else
{
lean_object* v_reuseFailAlloc_60_; 
v_reuseFailAlloc_60_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_60_, 0, v___f_55_);
lean_ctor_set(v_reuseFailAlloc_60_, 1, v___f_57_);
v___x_59_ = v_reuseFailAlloc_60_;
goto v_reusejp_58_;
}
v_reusejp_58_:
{
return v___x_59_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg___boxed(lean_object* v_p_62_, lean_object* v_q_63_, lean_object* v_s_64_, lean_object* v_t_65_){
_start:
{
lean_object* v_res_66_; 
v_res_66_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg(v_p_62_, v_q_63_, v_s_64_, v_t_65_);
lean_dec_ref(v_t_65_);
lean_dec_ref(v_s_64_);
lean_dec(v_q_63_);
lean_dec(v_p_62_);
return v_res_66_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc(lean_object* v_n_67_, lean_object* v_p_68_, lean_object* v_q_69_, lean_object* v_s_70_, lean_object* v_t_71_){
_start:
{
lean_object* v___x_72_; 
v___x_72_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___redArg(v_p_68_, v_q_69_, v_s_70_, v_t_71_);
return v___x_72_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc___boxed(lean_object* v_n_73_, lean_object* v_p_74_, lean_object* v_q_75_, lean_object* v_s_76_, lean_object* v_t_77_){
_start:
{
lean_object* v_res_78_; 
v_res_78_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LetterGl_cc(v_n_73_, v_p_74_, v_q_75_, v_s_76_, v_t_77_);
lean_dec_ref(v_t_77_);
lean_dec_ref(v_s_76_);
lean_dec(v_q_75_);
lean_dec(v_p_74_);
lean_dec(v_n_73_);
return v_res_78_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_Bdy(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_OrderedCreationCommutesPastLevi(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_LeviActionIsGlRepresentation(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_Bdy(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_OrderedCreationCommutesPastLevi(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

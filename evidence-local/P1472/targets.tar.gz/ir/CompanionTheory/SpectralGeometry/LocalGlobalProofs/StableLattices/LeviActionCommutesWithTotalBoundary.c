// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.LeviActionCommutesWithTotalBoundary
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.Bdy public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.OrderedCreationCommutesPastLevi
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
lean_object* lp_mathlib_LinearMap_compLeft___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_CompanionTheory_D_LK_ann___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lp_mathlib_Pi_addCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_LinearMap_addMonoid___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Multiset_product___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_filter___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_pmap___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_CompanionTheory_RgExh_U_adC(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_CompanionTheory_D_LK_cre___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_Finset_sum___at___00Formalism_FourierDecayAlt_G_superSum_spec__0___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0;
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___x_4_ = lp_mathlib_Complex_ofReal(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(lean_object* v_i_5_, lean_object* v_j_6_, lean_object* v_k_7_){
_start:
{
lean_object* v_fst_10_; lean_object* v_snd_11_; lean_object* v_fst_12_; lean_object* v_snd_13_; uint8_t v___x_14_; 
v_fst_10_ = lean_ctor_get(v_i_5_, 0);
v_snd_11_ = lean_ctor_get(v_i_5_, 1);
v_fst_12_ = lean_ctor_get(v_j_6_, 0);
v_snd_13_ = lean_ctor_get(v_j_6_, 1);
v___x_14_ = lean_nat_dec_eq(v_snd_11_, v_fst_12_);
if (v___x_14_ == 0)
{
goto v___jp_8_;
}
else
{
lean_object* v_fst_15_; lean_object* v_snd_16_; uint8_t v___x_17_; 
v_fst_15_ = lean_ctor_get(v_k_7_, 0);
v_snd_16_ = lean_ctor_get(v_k_7_, 1);
v___x_17_ = lean_nat_dec_eq(v_fst_15_, v_fst_10_);
if (v___x_17_ == 0)
{
goto v___jp_8_;
}
else
{
uint8_t v___x_18_; 
v___x_18_ = lean_nat_dec_eq(v_snd_16_, v_snd_13_);
if (v___x_18_ == 0)
{
goto v___jp_8_;
}
else
{
lean_object* v___x_19_; 
v___x_19_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1);
return v___x_19_;
}
}
}
v___jp_8_:
{
lean_object* v___x_9_; 
v___x_9_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___boxed(lean_object* v_i_20_, lean_object* v_j_21_, lean_object* v_k_22_){
_start:
{
lean_object* v_res_23_; 
v_res_23_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_i_20_, v_j_21_, v_k_22_);
lean_dec_ref(v_k_22_);
lean_dec_ref(v_j_21_);
lean_dec_ref(v_i_20_);
return v_res_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc(lean_object* v_n_24_, lean_object* v_i_25_, lean_object* v_j_26_, lean_object* v_k_27_){
_start:
{
lean_object* v___x_28_; 
v___x_28_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_i_25_, v_j_26_, v_k_27_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___boxed(lean_object* v_n_29_, lean_object* v_i_30_, lean_object* v_j_31_, lean_object* v_k_32_){
_start:
{
lean_object* v_res_33_; 
v_res_33_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc(v_n_29_, v_i_30_, v_j_31_, v_k_32_);
lean_dec_ref(v_k_32_);
lean_dec_ref(v_j_31_);
lean_dec_ref(v_i_30_);
lean_dec(v_n_29_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__0(lean_object* v_E_34_, lean_object* v_n_35_, lean_object* v_inst_36_, lean_object* v_inst_37_, lean_object* v_i_38_, lean_object* v___y_39_, lean_object* v___y_40_){
_start:
{
lean_object* v_fst_41_; lean_object* v_snd_42_; lean_object* v___x_43_; lean_object* v___f_44_; lean_object* v___x_45_; lean_object* v___x_90__overap_46_; lean_object* v___x_47_; 
v_fst_41_ = lean_ctor_get(v_i_38_, 0);
v_snd_42_ = lean_ctor_get(v_i_38_, 1);
lean_inc(v_snd_42_);
lean_inc(v_fst_41_);
v___x_43_ = lean_apply_2(v_E_34_, v_fst_41_, v_snd_42_);
v___f_44_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_compLeft___redArg___lam__0), 3, 1);
lean_closure_set(v___f_44_, 0, v___x_43_);
v___x_45_ = lp_tree_CompanionTheory_D_LK_ann___redArg(v_n_35_, v_inst_36_, v_inst_37_, v_i_38_);
v___x_90__overap_46_ = lp_mathlib_LinearMap_comp___redArg___lam__0(v___x_45_, v___f_44_, v___y_39_);
v___x_47_ = lean_apply_1(v___x_90__overap_46_, v___y_40_);
return v___x_47_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1(lean_object* v_val_48_, lean_object* v_property_49_){
_start:
{
lean_inc_ref(v_val_48_);
return v_val_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1___boxed(lean_object* v_val_50_, lean_object* v_property_51_){
_start:
{
lean_object* v_res_52_; 
v_res_52_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__1(v_val_50_, v_property_51_);
lean_dec_ref(v_val_50_);
return v_res_52_;
}
}
LEAN_EXPORT uint8_t lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2(lean_object* v_a_53_){
_start:
{
lean_object* v_fst_54_; lean_object* v_snd_55_; uint8_t v___x_56_; 
v_fst_54_ = lean_ctor_get(v_a_53_, 0);
v_snd_55_ = lean_ctor_get(v_a_53_, 1);
v___x_56_ = lean_nat_dec_lt(v_fst_54_, v_snd_55_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2___boxed(lean_object* v_a_57_){
_start:
{
uint8_t v_res_58_; lean_object* v_r_59_; 
v_res_58_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__2(v_a_57_);
lean_dec_ref(v_a_57_);
v_r_59_ = lean_box(v_res_58_);
return v_r_59_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3(lean_object* v_toAddMonoid_60_, lean_object* v_i_61_){
_start:
{
lean_inc_ref(v_toAddMonoid_60_);
return v_toAddMonoid_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3___boxed(lean_object* v_toAddMonoid_62_, lean_object* v_i_63_){
_start:
{
lean_object* v_res_64_; 
v_res_64_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3(v_toAddMonoid_62_, v_i_63_);
lean_dec(v_i_63_);
lean_dec_ref(v_toAddMonoid_62_);
return v_res_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg(lean_object* v_n_67_, lean_object* v_inst_68_, lean_object* v_inst_69_, lean_object* v_E_70_){
_start:
{
lean_object* v_toAddMonoid_71_; lean_object* v___f_72_; lean_object* v___f_73_; lean_object* v___f_74_; lean_object* v___f_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; 
v_toAddMonoid_71_ = lean_ctor_get(v_inst_68_, 0);
lean_inc_ref(v_toAddMonoid_71_);
lean_inc(v_n_67_);
v___f_72_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__0), 7, 4);
lean_closure_set(v___f_72_, 0, v_E_70_);
lean_closure_set(v___f_72_, 1, v_n_67_);
lean_closure_set(v___f_72_, 2, v_inst_68_);
lean_closure_set(v___f_72_, 3, v_inst_69_);
v___f_73_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0));
v___f_74_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1));
v___f_75_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3___boxed), 2, 1);
lean_closure_set(v___f_75_, 0, v_toAddMonoid_71_);
v___x_76_ = lp_mathlib_Pi_addCommMonoid___redArg(v___f_75_);
v___x_77_ = lp_mathlib_LinearMap_addMonoid___redArg(v___x_76_);
v___x_78_ = l_List_finRange(v_n_67_);
lean_inc(v___x_78_);
v___x_79_ = lp_mathlib_Multiset_product___redArg(v___x_78_, v___x_78_);
v___x_80_ = lp_mathlib_Multiset_filter___redArg(v___f_74_, v___x_79_);
v___x_81_ = lp_mathlib_Multiset_pmap___redArg(v___f_73_, v___x_80_);
v___x_82_ = lp_mathlib_Finset_sum___redArg(v___x_77_, v___x_81_, v___f_72_);
lean_dec_ref(v___x_77_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1(lean_object* v_n_83_, lean_object* v_V_84_, lean_object* v_inst_85_, lean_object* v_inst_86_, lean_object* v_E_87_){
_start:
{
lean_object* v___x_88_; 
v___x_88_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg(v_n_83_, v_inst_85_, v_inst_86_, v_E_87_);
return v___x_88_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3___redArg(lean_object* v_n_89_, lean_object* v_inst_90_, lean_object* v_inst_91_, lean_object* v_a_92_, lean_object* v_b_93_, lean_object* v_m_94_){
_start:
{
lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___f_97_; lean_object* v___x_98_; lean_object* v___f_99_; 
lean_inc_n(v_inst_91_, 2);
lean_inc_ref_n(v_inst_90_, 2);
lean_inc_n(v_n_89_, 2);
v___x_95_ = lp_tree_CompanionTheory_D_LK_cre___redArg(v_n_89_, v_inst_90_, v_inst_91_, v_m_94_);
v___x_96_ = lp_tree_CompanionTheory_D_LK_ann___redArg(v_n_89_, v_inst_90_, v_inst_91_, v_b_93_);
v___f_97_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_97_, 0, v___x_96_);
lean_closure_set(v___f_97_, 1, v___x_95_);
v___x_98_ = lp_tree_CompanionTheory_D_LK_ann___redArg(v_n_89_, v_inst_90_, v_inst_91_, v_a_92_);
v___f_99_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_99_, 0, v___x_98_);
lean_closure_set(v___f_99_, 1, v___f_97_);
return v___f_99_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3(lean_object* v_n_100_, lean_object* v_V_101_, lean_object* v_inst_102_, lean_object* v_inst_103_, lean_object* v_a_104_, lean_object* v_b_105_, lean_object* v_m_106_){
_start:
{
lean_object* v___x_107_; 
v___x_107_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3___redArg(v_n_100_, v_inst_102_, v_inst_103_, v_a_104_, v_b_105_, v_m_106_);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__3(lean_object* v_i_108_, lean_object* v_j_109_, lean_object* v_n_110_, lean_object* v_inst_111_, lean_object* v_inst_112_, lean_object* v_k_113_, lean_object* v___y_114_, lean_object* v___y_115_){
_start:
{
lean_object* v___x_116_; lean_object* v___x_196__overap_117_; lean_object* v___x_118_; lean_object* v___x_119_; 
v___x_116_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_i_108_, v_j_109_, v_k_113_);
lean_inc(v_inst_112_);
v___x_196__overap_117_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Wt3___redArg(v_n_110_, v_inst_111_, v_inst_112_, v_i_108_, v_j_109_, v_k_113_);
v___x_118_ = lean_apply_2(v___x_196__overap_117_, v___y_114_, v___y_115_);
v___x_119_ = lean_apply_2(v_inst_112_, v___x_116_, v___x_118_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0(lean_object* v_i_120_, lean_object* v_n_121_, lean_object* v_inst_122_, lean_object* v_inst_123_, lean_object* v___x_124_, lean_object* v___x_125_, lean_object* v_j_126_, lean_object* v___y_127_, lean_object* v___y_128_){
_start:
{
lean_object* v___f_129_; lean_object* v___x_205__overap_130_; lean_object* v___x_131_; 
v___f_129_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__3), 8, 5);
lean_closure_set(v___f_129_, 0, v_i_120_);
lean_closure_set(v___f_129_, 1, v_j_126_);
lean_closure_set(v___f_129_, 2, v_n_121_);
lean_closure_set(v___f_129_, 3, v_inst_122_);
lean_closure_set(v___f_129_, 4, v_inst_123_);
v___x_205__overap_130_ = lp_mathlib_Finset_sum___redArg(v___x_124_, v___x_125_, v___f_129_);
v___x_131_ = lean_apply_2(v___x_205__overap_130_, v___y_127_, v___y_128_);
return v___x_131_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0___boxed(lean_object* v_i_132_, lean_object* v_n_133_, lean_object* v_inst_134_, lean_object* v_inst_135_, lean_object* v___x_136_, lean_object* v___x_137_, lean_object* v_j_138_, lean_object* v___y_139_, lean_object* v___y_140_){
_start:
{
lean_object* v_res_141_; 
v_res_141_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0(v_i_132_, v_n_133_, v_inst_134_, v_inst_135_, v___x_136_, v___x_137_, v_j_138_, v___y_139_, v___y_140_);
lean_dec_ref(v___x_136_);
return v_res_141_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__1(lean_object* v_n_142_, lean_object* v_inst_143_, lean_object* v_inst_144_, lean_object* v___x_145_, lean_object* v___x_146_, lean_object* v_i_147_, lean_object* v___y_148_, lean_object* v___y_149_){
_start:
{
lean_object* v___f_150_; lean_object* v___x_213__overap_151_; lean_object* v___x_152_; 
lean_inc(v___x_146_);
lean_inc_ref(v___x_145_);
v___f_150_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__0___boxed), 9, 6);
lean_closure_set(v___f_150_, 0, v_i_147_);
lean_closure_set(v___f_150_, 1, v_n_142_);
lean_closure_set(v___f_150_, 2, v_inst_143_);
lean_closure_set(v___f_150_, 3, v_inst_144_);
lean_closure_set(v___f_150_, 4, v___x_145_);
lean_closure_set(v___f_150_, 5, v___x_146_);
v___x_213__overap_151_ = lp_mathlib_Finset_sum___redArg(v___x_145_, v___x_146_, v___f_150_);
lean_dec_ref(v___x_145_);
v___x_152_ = lean_apply_2(v___x_213__overap_151_, v___y_148_, v___y_149_);
return v___x_152_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg(lean_object* v_n_153_, lean_object* v_inst_154_, lean_object* v_inst_155_){
_start:
{
lean_object* v_toAddMonoid_156_; lean_object* v___f_157_; lean_object* v___f_158_; lean_object* v___f_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_164_; lean_object* v___x_165_; lean_object* v___f_166_; lean_object* v___x_167_; 
v_toAddMonoid_156_ = lean_ctor_get(v_inst_154_, 0);
v___f_157_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1));
v___f_158_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0));
lean_inc_ref(v_toAddMonoid_156_);
v___f_159_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___lam__3___boxed), 2, 1);
lean_closure_set(v___f_159_, 0, v_toAddMonoid_156_);
v___x_160_ = lp_mathlib_Pi_addCommMonoid___redArg(v___f_159_);
v___x_161_ = lp_mathlib_LinearMap_addMonoid___redArg(v___x_160_);
lean_inc(v_n_153_);
v___x_162_ = l_List_finRange(v_n_153_);
lean_inc(v___x_162_);
v___x_163_ = lp_mathlib_Multiset_product___redArg(v___x_162_, v___x_162_);
v___x_164_ = lp_mathlib_Multiset_filter___redArg(v___f_157_, v___x_163_);
v___x_165_ = lp_mathlib_Multiset_pmap___redArg(v___f_158_, v___x_164_);
lean_inc(v___x_165_);
lean_inc_ref(v___x_161_);
v___f_166_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg___lam__1), 8, 5);
lean_closure_set(v___f_166_, 0, v_n_153_);
lean_closure_set(v___f_166_, 1, v_inst_154_);
lean_closure_set(v___f_166_, 2, v_inst_155_);
lean_closure_set(v___f_166_, 3, v___x_161_);
lean_closure_set(v___f_166_, 4, v___x_165_);
v___x_167_ = lp_mathlib_Finset_sum___redArg(v___x_161_, v___x_165_, v___f_166_);
lean_dec_ref(v___x_161_);
return v___x_167_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2(lean_object* v_n_168_, lean_object* v_V_169_, lean_object* v_inst_170_, lean_object* v_inst_171_){
_start:
{
lean_object* v___x_172_; 
v___x_172_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S2___redArg(v_n_168_, v_inst_170_, v_inst_171_);
return v___x_172_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2(lean_object* v_a_173_, lean_object* v_b_174_, lean_object* v_n_175_, lean_object* v_p_176_, lean_object* v_q_177_, lean_object* v_m_178_, lean_object* v_k_179_){
_start:
{
lean_object* v___x_180_; lean_object* v_re_181_; lean_object* v_im_182_; lean_object* v___x_183_; lean_object* v___x_184_; 
v___x_180_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_a_173_, v_b_174_, v_k_179_);
v_re_181_ = lean_ctor_get(v___x_180_, 0);
lean_inc(v_re_181_);
v_im_182_ = lean_ctor_get(v___x_180_, 1);
lean_inc(v_im_182_);
lean_dec_ref(v___x_180_);
v___x_183_ = lp_tree_CompanionTheory_RgExh_U_adC(v_n_175_, v_p_176_, v_q_177_, v_k_179_, v_m_178_);
v___x_184_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_181_, v_im_182_, v___x_183_);
return v___x_184_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2___boxed(lean_object* v_a_185_, lean_object* v_b_186_, lean_object* v_n_187_, lean_object* v_p_188_, lean_object* v_q_189_, lean_object* v_m_190_, lean_object* v_k_191_){
_start:
{
lean_object* v_res_192_; 
v_res_192_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2(v_a_185_, v_b_186_, v_n_187_, v_p_188_, v_q_189_, v_m_190_, v_k_191_);
lean_dec_ref(v_b_186_);
lean_dec_ref(v_a_185_);
return v_res_192_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0(lean_object* v_a_193_, lean_object* v_m_194_, lean_object* v_n_195_, lean_object* v_p_196_, lean_object* v_q_197_, lean_object* v_b_198_, lean_object* v_j_199_){
_start:
{
lean_object* v___x_200_; lean_object* v_re_201_; lean_object* v_im_202_; lean_object* v___x_203_; lean_object* v___x_204_; 
v___x_200_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_a_193_, v_j_199_, v_m_194_);
v_re_201_ = lean_ctor_get(v___x_200_, 0);
lean_inc(v_re_201_);
v_im_202_ = lean_ctor_get(v___x_200_, 1);
lean_inc(v_im_202_);
lean_dec_ref(v___x_200_);
v___x_203_ = lp_tree_CompanionTheory_RgExh_U_adC(v_n_195_, v_p_196_, v_q_197_, v_b_198_, v_j_199_);
v___x_204_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_201_, v_im_202_, v___x_203_);
return v___x_204_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0___boxed(lean_object* v_a_205_, lean_object* v_m_206_, lean_object* v_n_207_, lean_object* v_p_208_, lean_object* v_q_209_, lean_object* v_b_210_, lean_object* v_j_211_){
_start:
{
lean_object* v_res_212_; 
v_res_212_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0(v_a_205_, v_m_206_, v_n_207_, v_p_208_, v_q_209_, v_b_210_, v_j_211_);
lean_dec_ref(v_m_206_);
lean_dec_ref(v_a_205_);
return v_res_212_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1(lean_object* v_b_213_, lean_object* v_m_214_, lean_object* v_n_215_, lean_object* v_p_216_, lean_object* v_q_217_, lean_object* v_a_218_, lean_object* v_i_219_){
_start:
{
lean_object* v___x_220_; lean_object* v_re_221_; lean_object* v_im_222_; lean_object* v___x_223_; lean_object* v___x_224_; 
v___x_220_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg(v_i_219_, v_b_213_, v_m_214_);
v_re_221_ = lean_ctor_get(v___x_220_, 0);
lean_inc(v_re_221_);
v_im_222_ = lean_ctor_get(v___x_220_, 1);
lean_inc(v_im_222_);
lean_dec_ref(v___x_220_);
v___x_223_ = lp_tree_CompanionTheory_RgExh_U_adC(v_n_215_, v_p_216_, v_q_217_, v_a_218_, v_i_219_);
v___x_224_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_221_, v_im_222_, v___x_223_);
return v___x_224_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1___boxed(lean_object* v_b_225_, lean_object* v_m_226_, lean_object* v_n_227_, lean_object* v_p_228_, lean_object* v_q_229_, lean_object* v_a_230_, lean_object* v_i_231_){
_start:
{
lean_object* v_res_232_; 
v_res_232_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1(v_b_225_, v_m_226_, v_n_227_, v_p_228_, v_q_229_, v_a_230_, v_i_231_);
lean_dec_ref(v_m_226_);
lean_dec_ref(v_b_225_);
return v_res_232_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc(lean_object* v_n_233_, lean_object* v_p_234_, lean_object* v_q_235_, lean_object* v_a_236_, lean_object* v_b_237_, lean_object* v_m_238_){
_start:
{
lean_object* v___f_239_; lean_object* v___f_240_; lean_object* v___f_241_; lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; lean_object* v___x_246_; lean_object* v_re_247_; lean_object* v_im_248_; lean_object* v___f_249_; lean_object* v___x_250_; lean_object* v_re_251_; lean_object* v_im_252_; lean_object* v___f_253_; lean_object* v___x_254_; lean_object* v_re_255_; lean_object* v_im_256_; lean_object* v___x_258_; uint8_t v_isShared_259_; uint8_t v_isSharedCheck_271_; 
v___f_239_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__1));
v___f_240_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_S1___redArg___closed__0));
lean_inc_ref_n(v_m_238_, 2);
lean_inc_n(v_q_235_, 2);
lean_inc_n(v_p_234_, 2);
lean_inc_n(v_n_233_, 3);
lean_inc_ref_n(v_b_237_, 2);
lean_inc_ref_n(v_a_236_, 2);
v___f_241_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__2___boxed), 7, 6);
lean_closure_set(v___f_241_, 0, v_a_236_);
lean_closure_set(v___f_241_, 1, v_b_237_);
lean_closure_set(v___f_241_, 2, v_n_233_);
lean_closure_set(v___f_241_, 3, v_p_234_);
lean_closure_set(v___f_241_, 4, v_q_235_);
lean_closure_set(v___f_241_, 5, v_m_238_);
v___x_242_ = l_List_finRange(v_n_233_);
lean_inc(v___x_242_);
v___x_243_ = lp_mathlib_Multiset_product___redArg(v___x_242_, v___x_242_);
v___x_244_ = lp_mathlib_Multiset_filter___redArg(v___f_239_, v___x_243_);
v___x_245_ = lp_mathlib_Multiset_pmap___redArg(v___f_240_, v___x_244_);
lean_inc_n(v___x_245_, 2);
v___x_246_ = lp_tree_Finset_sum___at___00Formalism_FourierDecayAlt_G_superSum_spec__0___redArg(v___x_245_, v___f_241_);
v_re_247_ = lean_ctor_get(v___x_246_, 0);
lean_inc(v_re_247_);
v_im_248_ = lean_ctor_get(v___x_246_, 1);
lean_inc(v_im_248_);
lean_dec_ref(v___x_246_);
v___f_249_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__0___boxed), 7, 6);
lean_closure_set(v___f_249_, 0, v_a_236_);
lean_closure_set(v___f_249_, 1, v_m_238_);
lean_closure_set(v___f_249_, 2, v_n_233_);
lean_closure_set(v___f_249_, 3, v_p_234_);
lean_closure_set(v___f_249_, 4, v_q_235_);
lean_closure_set(v___f_249_, 5, v_b_237_);
v___x_250_ = lp_tree_Finset_sum___at___00Formalism_FourierDecayAlt_G_superSum_spec__0___redArg(v___x_245_, v___f_249_);
v_re_251_ = lean_ctor_get(v___x_250_, 0);
lean_inc(v_re_251_);
v_im_252_ = lean_ctor_get(v___x_250_, 1);
lean_inc(v_im_252_);
lean_dec_ref(v___x_250_);
v___f_253_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_Dc___lam__1___boxed), 7, 6);
lean_closure_set(v___f_253_, 0, v_b_237_);
lean_closure_set(v___f_253_, 1, v_m_238_);
lean_closure_set(v___f_253_, 2, v_n_233_);
lean_closure_set(v___f_253_, 3, v_p_234_);
lean_closure_set(v___f_253_, 4, v_q_235_);
lean_closure_set(v___f_253_, 5, v_a_236_);
v___x_254_ = lp_tree_Finset_sum___at___00Formalism_FourierDecayAlt_G_superSum_spec__0___redArg(v___x_245_, v___f_253_);
v_re_255_ = lean_ctor_get(v___x_254_, 0);
v_im_256_ = lean_ctor_get(v___x_254_, 1);
v_isSharedCheck_271_ = !lean_is_exclusive(v___x_254_);
if (v_isSharedCheck_271_ == 0)
{
v___x_258_ = v___x_254_;
v_isShared_259_ = v_isSharedCheck_271_;
goto v_resetjp_257_;
}
else
{
lean_inc(v_im_256_);
lean_inc(v_re_255_);
lean_dec(v___x_254_);
v___x_258_ = lean_box(0);
v_isShared_259_ = v_isSharedCheck_271_;
goto v_resetjp_257_;
}
v_resetjp_257_:
{
lean_object* v___f_260_; lean_object* v___f_261_; lean_object* v___f_262_; lean_object* v___f_263_; lean_object* v___f_264_; lean_object* v___f_265_; lean_object* v___f_266_; lean_object* v___f_267_; lean_object* v___x_269_; 
v___f_260_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_260_, 0, v_re_251_);
v___f_261_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_261_, 0, v_re_247_);
lean_closure_set(v___f_261_, 1, v___f_260_);
v___f_262_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_262_, 0, v_im_252_);
v___f_263_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_263_, 0, v_im_248_);
lean_closure_set(v___f_263_, 1, v___f_262_);
v___f_264_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_264_, 0, v_re_255_);
v___f_265_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_265_, 0, v___f_261_);
lean_closure_set(v___f_265_, 1, v___f_264_);
v___f_266_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_266_, 0, v_im_256_);
v___f_267_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_267_, 0, v___f_263_);
lean_closure_set(v___f_267_, 1, v___f_266_);
if (v_isShared_259_ == 0)
{
lean_ctor_set(v___x_258_, 1, v___f_267_);
lean_ctor_set(v___x_258_, 0, v___f_265_);
v___x_269_ = v___x_258_;
goto v_reusejp_268_;
}
else
{
lean_object* v_reuseFailAlloc_270_; 
v_reuseFailAlloc_270_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_270_, 0, v___f_265_);
lean_ctor_set(v_reuseFailAlloc_270_, 1, v___f_267_);
v___x_269_ = v_reuseFailAlloc_270_;
goto v_reusejp_268_;
}
v_reusejp_268_:
{
return v___x_269_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg(lean_object* v_p_272_, lean_object* v_q_273_, lean_object* v_a_274_, lean_object* v_b_275_, lean_object* v_m_276_){
_start:
{
lean_object* v_fst_279_; lean_object* v_snd_280_; lean_object* v_fst_281_; lean_object* v_snd_282_; uint8_t v___x_283_; 
v_fst_279_ = lean_ctor_get(v_a_274_, 0);
v_snd_280_ = lean_ctor_get(v_a_274_, 1);
v_fst_281_ = lean_ctor_get(v_b_275_, 0);
v_snd_282_ = lean_ctor_get(v_b_275_, 1);
v___x_283_ = lean_nat_dec_eq(v_snd_280_, v_fst_281_);
if (v___x_283_ == 0)
{
goto v___jp_277_;
}
else
{
uint8_t v___x_284_; 
v___x_284_ = lean_nat_dec_eq(v_q_273_, v_fst_279_);
if (v___x_284_ == 0)
{
goto v___jp_277_;
}
else
{
lean_object* v_fst_285_; lean_object* v_snd_286_; uint8_t v___x_287_; 
v_fst_285_ = lean_ctor_get(v_m_276_, 0);
v_snd_286_ = lean_ctor_get(v_m_276_, 1);
v___x_287_ = lean_nat_dec_eq(v_fst_285_, v_p_272_);
if (v___x_287_ == 0)
{
goto v___jp_277_;
}
else
{
uint8_t v___x_288_; 
v___x_288_ = lean_nat_dec_eq(v_snd_286_, v_snd_282_);
if (v___x_288_ == 0)
{
goto v___jp_277_;
}
else
{
lean_object* v___x_289_; 
v___x_289_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1);
return v___x_289_;
}
}
}
}
v___jp_277_:
{
lean_object* v___x_278_; 
v___x_278_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0);
return v___x_278_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg___boxed(lean_object* v_p_290_, lean_object* v_q_291_, lean_object* v_a_292_, lean_object* v_b_293_, lean_object* v_m_294_){
_start:
{
lean_object* v_res_295_; 
v_res_295_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg(v_p_290_, v_q_291_, v_a_292_, v_b_293_, v_m_294_);
lean_dec_ref(v_m_294_);
lean_dec_ref(v_b_293_);
lean_dec_ref(v_a_292_);
lean_dec(v_q_291_);
lean_dec(v_p_290_);
return v_res_295_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX(lean_object* v_n_296_, lean_object* v_p_297_, lean_object* v_q_298_, lean_object* v_a_299_, lean_object* v_b_300_, lean_object* v_m_301_){
_start:
{
lean_object* v___x_302_; 
v___x_302_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___redArg(v_p_297_, v_q_298_, v_a_299_, v_b_300_, v_m_301_);
return v___x_302_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX___boxed(lean_object* v_n_303_, lean_object* v_p_304_, lean_object* v_q_305_, lean_object* v_a_306_, lean_object* v_b_307_, lean_object* v_m_308_){
_start:
{
lean_object* v_res_309_; 
v_res_309_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cX(v_n_303_, v_p_304_, v_q_305_, v_a_306_, v_b_307_, v_m_308_);
lean_dec_ref(v_m_308_);
lean_dec_ref(v_b_307_);
lean_dec_ref(v_a_306_);
lean_dec(v_q_305_);
lean_dec(v_p_304_);
lean_dec(v_n_303_);
return v_res_309_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg(lean_object* v_p_310_, lean_object* v_q_311_, lean_object* v_a_312_, lean_object* v_b_313_, lean_object* v_m_314_){
_start:
{
lean_object* v_fst_317_; lean_object* v_snd_318_; lean_object* v_fst_319_; lean_object* v_snd_320_; uint8_t v___x_321_; 
v_fst_317_ = lean_ctor_get(v_a_312_, 0);
v_snd_318_ = lean_ctor_get(v_a_312_, 1);
v_fst_319_ = lean_ctor_get(v_b_313_, 0);
v_snd_320_ = lean_ctor_get(v_b_313_, 1);
v___x_321_ = lean_nat_dec_eq(v_snd_318_, v_fst_319_);
if (v___x_321_ == 0)
{
goto v___jp_315_;
}
else
{
uint8_t v___x_322_; 
v___x_322_ = lean_nat_dec_eq(v_snd_320_, v_p_310_);
if (v___x_322_ == 0)
{
goto v___jp_315_;
}
else
{
lean_object* v_fst_323_; lean_object* v_snd_324_; uint8_t v___x_325_; 
v_fst_323_ = lean_ctor_get(v_m_314_, 0);
v_snd_324_ = lean_ctor_get(v_m_314_, 1);
v___x_325_ = lean_nat_dec_eq(v_fst_323_, v_fst_317_);
if (v___x_325_ == 0)
{
goto v___jp_315_;
}
else
{
uint8_t v___x_326_; 
v___x_326_ = lean_nat_dec_eq(v_snd_324_, v_q_311_);
if (v___x_326_ == 0)
{
goto v___jp_315_;
}
else
{
lean_object* v___x_327_; 
v___x_327_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1);
return v___x_327_;
}
}
}
}
v___jp_315_:
{
lean_object* v___x_316_; 
v___x_316_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0);
return v___x_316_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg___boxed(lean_object* v_p_328_, lean_object* v_q_329_, lean_object* v_a_330_, lean_object* v_b_331_, lean_object* v_m_332_){
_start:
{
lean_object* v_res_333_; 
v_res_333_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg(v_p_328_, v_q_329_, v_a_330_, v_b_331_, v_m_332_);
lean_dec_ref(v_m_332_);
lean_dec_ref(v_b_331_);
lean_dec_ref(v_a_330_);
lean_dec(v_q_329_);
lean_dec(v_p_328_);
return v_res_333_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY(lean_object* v_n_334_, lean_object* v_p_335_, lean_object* v_q_336_, lean_object* v_a_337_, lean_object* v_b_338_, lean_object* v_m_339_){
_start:
{
lean_object* v___x_340_; 
v___x_340_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___redArg(v_p_335_, v_q_336_, v_a_337_, v_b_338_, v_m_339_);
return v___x_340_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY___boxed(lean_object* v_n_341_, lean_object* v_p_342_, lean_object* v_q_343_, lean_object* v_a_344_, lean_object* v_b_345_, lean_object* v_m_346_){
_start:
{
lean_object* v_res_347_; 
v_res_347_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cY(v_n_341_, v_p_342_, v_q_343_, v_a_344_, v_b_345_, v_m_346_);
lean_dec_ref(v_m_346_);
lean_dec_ref(v_b_345_);
lean_dec_ref(v_a_344_);
lean_dec(v_q_343_);
lean_dec(v_p_342_);
lean_dec(v_n_341_);
return v_res_347_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg(lean_object* v_p_348_, lean_object* v_q_349_, lean_object* v_a_350_, lean_object* v_b_351_, lean_object* v_m_352_){
_start:
{
lean_object* v_fst_355_; lean_object* v_snd_356_; uint8_t v___x_357_; 
v_fst_355_ = lean_ctor_get(v_a_350_, 0);
v_snd_356_ = lean_ctor_get(v_a_350_, 1);
v___x_357_ = lean_nat_dec_eq(v_snd_356_, v_p_348_);
if (v___x_357_ == 0)
{
goto v___jp_353_;
}
else
{
lean_object* v_fst_358_; lean_object* v_snd_359_; uint8_t v___x_360_; 
v_fst_358_ = lean_ctor_get(v_b_351_, 0);
v_snd_359_ = lean_ctor_get(v_b_351_, 1);
v___x_360_ = lean_nat_dec_eq(v_q_349_, v_fst_358_);
if (v___x_360_ == 0)
{
goto v___jp_353_;
}
else
{
lean_object* v_fst_361_; lean_object* v_snd_362_; uint8_t v___x_363_; 
v_fst_361_ = lean_ctor_get(v_m_352_, 0);
v_snd_362_ = lean_ctor_get(v_m_352_, 1);
v___x_363_ = lean_nat_dec_eq(v_fst_361_, v_fst_355_);
if (v___x_363_ == 0)
{
goto v___jp_353_;
}
else
{
uint8_t v___x_364_; 
v___x_364_ = lean_nat_dec_eq(v_snd_362_, v_snd_359_);
if (v___x_364_ == 0)
{
goto v___jp_353_;
}
else
{
lean_object* v___x_365_; 
v___x_365_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__1);
return v___x_365_;
}
}
}
}
v___jp_353_:
{
lean_object* v___x_354_; 
v___x_354_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_tc___redArg___closed__0);
return v___x_354_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg___boxed(lean_object* v_p_366_, lean_object* v_q_367_, lean_object* v_a_368_, lean_object* v_b_369_, lean_object* v_m_370_){
_start:
{
lean_object* v_res_371_; 
v_res_371_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg(v_p_366_, v_q_367_, v_a_368_, v_b_369_, v_m_370_);
lean_dec_ref(v_m_370_);
lean_dec_ref(v_b_369_);
lean_dec_ref(v_a_368_);
lean_dec(v_q_367_);
lean_dec(v_p_366_);
return v_res_371_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ(lean_object* v_n_372_, lean_object* v_p_373_, lean_object* v_q_374_, lean_object* v_a_375_, lean_object* v_b_376_, lean_object* v_m_377_){
_start:
{
lean_object* v___x_378_; 
v___x_378_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___redArg(v_p_373_, v_q_374_, v_a_375_, v_b_376_, v_m_377_);
return v___x_378_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ___boxed(lean_object* v_n_379_, lean_object* v_p_380_, lean_object* v_q_381_, lean_object* v_a_382_, lean_object* v_b_383_, lean_object* v_m_384_){
_start:
{
lean_object* v_res_385_; 
v_res_385_ = lp_tree_GlobalTheory_CompanionTheory_RgCOBlock_LeviBd_cZ(v_n_379_, v_p_380_, v_q_381_, v_a_382_, v_b_383_, v_m_384_);
lean_dec_ref(v_m_384_);
lean_dec_ref(v_b_383_);
lean_dec_ref(v_a_382_);
lean_dec(v_q_381_);
lean_dec(v_p_380_);
lean_dec(v_n_379_);
return v_res_385_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_Bdy(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_OrderedCreationCommutesPastLevi(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_LeviActionCommutesWithTotalBoundary(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_Bdy(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_OrderedCreationCommutesPastLevi(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

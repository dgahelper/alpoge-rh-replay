// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.CGTrue
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.BlocksUnique public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ExistsIrreducibleFixed
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___redArg(lean_object* v_T_1_){
_start:
{
lean_inc_ref(v_T_1_);
return v_T_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___redArg___boxed(lean_object* v_T_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_tree_GlobalTheory_HeightCounting_wdCG___redArg(v_T_2_);
lean_dec_ref(v_T_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG(lean_object* v_D_4_, lean_object* v_hE_5_, lean_object* v_K_6_, lean_object* v_T_7_){
_start:
{
lean_inc_ref(v_T_7_);
return v_T_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_wdCG___boxed(lean_object* v_D_8_, lean_object* v_hE_9_, lean_object* v_K_10_, lean_object* v_T_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_HeightCounting_wdCG(v_D_8_, v_hE_9_, v_K_10_, v_T_11_);
lean_dec_ref(v_T_11_);
lean_dec_ref(v_K_10_);
lean_dec_ref(v_D_8_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG___redArg(lean_object* v_c_13_){
_start:
{
lean_object* v_P_14_; lean_object* v_W_15_; lean_object* v_mu0_16_; lean_object* v_eta_17_; lean_object* v_chiPsi_18_; lean_object* v_del_19_; lean_object* v_del_x27_20_; lean_object* v___x_22_; uint8_t v_isShared_23_; uint8_t v_isSharedCheck_27_; 
v_P_14_ = lean_ctor_get(v_c_13_, 0);
v_W_15_ = lean_ctor_get(v_c_13_, 1);
v_mu0_16_ = lean_ctor_get(v_c_13_, 2);
v_eta_17_ = lean_ctor_get(v_c_13_, 3);
v_chiPsi_18_ = lean_ctor_get(v_c_13_, 4);
v_del_19_ = lean_ctor_get(v_c_13_, 5);
v_del_x27_20_ = lean_ctor_get(v_c_13_, 6);
v_isSharedCheck_27_ = !lean_is_exclusive(v_c_13_);
if (v_isSharedCheck_27_ == 0)
{
v___x_22_ = v_c_13_;
v_isShared_23_ = v_isSharedCheck_27_;
goto v_resetjp_21_;
}
else
{
lean_inc(v_del_x27_20_);
lean_inc(v_del_19_);
lean_inc(v_chiPsi_18_);
lean_inc(v_eta_17_);
lean_inc(v_mu0_16_);
lean_inc(v_W_15_);
lean_inc(v_P_14_);
lean_dec(v_c_13_);
v___x_22_ = lean_box(0);
v_isShared_23_ = v_isSharedCheck_27_;
goto v_resetjp_21_;
}
v_resetjp_21_:
{
lean_object* v___x_25_; 
if (v_isShared_23_ == 0)
{
v___x_25_ = v___x_22_;
goto v_reusejp_24_;
}
else
{
lean_object* v_reuseFailAlloc_26_; 
v_reuseFailAlloc_26_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_26_, 0, v_P_14_);
lean_ctor_set(v_reuseFailAlloc_26_, 1, v_W_15_);
lean_ctor_set(v_reuseFailAlloc_26_, 2, v_mu0_16_);
lean_ctor_set(v_reuseFailAlloc_26_, 3, v_eta_17_);
lean_ctor_set(v_reuseFailAlloc_26_, 4, v_chiPsi_18_);
lean_ctor_set(v_reuseFailAlloc_26_, 5, v_del_19_);
lean_ctor_set(v_reuseFailAlloc_26_, 6, v_del_x27_20_);
v___x_25_ = v_reuseFailAlloc_26_;
goto v_reusejp_24_;
}
v_reusejp_24_:
{
return v___x_25_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG(lean_object* v_D_28_, lean_object* v_hE_29_, lean_object* v_K_30_, lean_object* v_c_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lp_tree_GlobalTheory_HeightCounting_cfCG___redArg(v_c_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_HeightCounting_cfCG___boxed(lean_object* v_D_33_, lean_object* v_hE_34_, lean_object* v_K_35_, lean_object* v_c_36_){
_start:
{
lean_object* v_res_37_; 
v_res_37_ = lp_tree_GlobalTheory_HeightCounting_cfCG(v_D_33_, v_hE_34_, v_K_35_, v_c_36_);
lean_dec_ref(v_K_35_);
lean_dec_ref(v_D_33_);
return v_res_37_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_BlocksUnique(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsIrreducibleFixed(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_CGTrue(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_BlocksUnique(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsIrreducibleFixed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

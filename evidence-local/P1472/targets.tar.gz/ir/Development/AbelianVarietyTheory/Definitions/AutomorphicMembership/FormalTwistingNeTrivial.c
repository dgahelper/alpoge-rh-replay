// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.FormalTwistingNeTrivial
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.ModuliProofs.ClsLinCombSingle public import Development.AbelianVarietyTheory.Definitions.Divisors.ToNatLengthEqRangeAddRange public import Development.AbelianVarietyTheory.Definitions.ThetaMetrics.ExistsFormOfEqRatioPowMul
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___at___00GlobalTheory_Cartier_secPull_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_setoid(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_setoid___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb___redArg(lean_object* v_L_1_, lean_object* v_e_2_){
_start:
{
lean_object* v_U_3_; lean_object* v_g_4_; lean_object* v___x_6_; uint8_t v_isShared_7_; uint8_t v_isSharedCheck_13_; 
v_U_3_ = lean_ctor_get(v_L_1_, 0);
v_g_4_ = lean_ctor_get(v_L_1_, 1);
v_isSharedCheck_13_ = !lean_is_exclusive(v_L_1_);
if (v_isSharedCheck_13_ == 0)
{
v___x_6_ = v_L_1_;
v_isShared_7_ = v_isSharedCheck_13_;
goto v_resetjp_5_;
}
else
{
lean_inc(v_g_4_);
lean_inc(v_U_3_);
lean_dec(v_L_1_);
v___x_6_ = lean_box(0);
v_isShared_7_ = v_isSharedCheck_13_;
goto v_resetjp_5_;
}
v_resetjp_5_:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_11_; 
lean_inc(v_e_2_);
v___x_8_ = lean_apply_1(v_U_3_, v_e_2_);
v___x_9_ = lean_apply_1(v_g_4_, v_e_2_);
if (v_isShared_7_ == 0)
{
lean_ctor_set(v___x_6_, 1, v___x_9_);
lean_ctor_set(v___x_6_, 0, v___x_8_);
v___x_11_ = v___x_6_;
goto v_reusejp_10_;
}
else
{
lean_object* v_reuseFailAlloc_12_; 
v_reuseFailAlloc_12_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_12_, 0, v___x_8_);
lean_ctor_set(v_reuseFailAlloc_12_, 1, v___x_9_);
v___x_11_ = v_reuseFailAlloc_12_;
goto v_reusejp_10_;
}
v_reusejp_10_:
{
return v___x_11_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb(lean_object* v_X_14_, lean_object* v_i_15_, lean_object* v_L_16_, lean_object* v_e_17_){
_start:
{
lean_object* v_U_18_; lean_object* v_g_19_; lean_object* v___x_21_; uint8_t v_isShared_22_; uint8_t v_isSharedCheck_28_; 
v_U_18_ = lean_ctor_get(v_L_16_, 0);
v_g_19_ = lean_ctor_get(v_L_16_, 1);
v_isSharedCheck_28_ = !lean_is_exclusive(v_L_16_);
if (v_isSharedCheck_28_ == 0)
{
v___x_21_ = v_L_16_;
v_isShared_22_ = v_isSharedCheck_28_;
goto v_resetjp_20_;
}
else
{
lean_inc(v_g_19_);
lean_inc(v_U_18_);
lean_dec(v_L_16_);
v___x_21_ = lean_box(0);
v_isShared_22_ = v_isSharedCheck_28_;
goto v_resetjp_20_;
}
v_resetjp_20_:
{
lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_26_; 
lean_inc(v_e_17_);
v___x_23_ = lean_apply_1(v_U_18_, v_e_17_);
v___x_24_ = lean_apply_1(v_g_19_, v_e_17_);
if (v_isShared_22_ == 0)
{
lean_ctor_set(v___x_21_, 1, v___x_24_);
lean_ctor_set(v___x_21_, 0, v___x_23_);
v___x_26_ = v___x_21_;
goto v_reusejp_25_;
}
else
{
lean_object* v_reuseFailAlloc_27_; 
v_reuseFailAlloc_27_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_27_, 0, v___x_23_);
lean_ctor_set(v_reuseFailAlloc_27_, 1, v___x_24_);
v___x_26_ = v_reuseFailAlloc_27_;
goto v_reusejp_25_;
}
v_reusejp_25_:
{
return v___x_26_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_lb___boxed(lean_object* v_X_29_, lean_object* v_i_30_, lean_object* v_L_31_, lean_object* v_e_32_){
_start:
{
lean_object* v_res_33_; 
v_res_33_ = lp_tree_GlobalTheory_FormalPic_FLB_lb(v_X_29_, v_i_30_, v_L_31_, v_e_32_);
lean_dec_ref(v_i_30_);
lean_dec_ref(v_X_29_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__0(lean_object* v_L_34_, lean_object* v_j_35_, lean_object* v_e_36_, lean_object* v_k_37_){
_start:
{
lean_object* v_U_38_; lean_object* v___x_39_; lean_object* v___x_40_; 
v_U_38_ = lean_ctor_get(v_L_34_, 0);
lean_inc_ref(v_U_38_);
lean_dec_ref(v_L_34_);
v___x_39_ = lean_apply_1(v_j_35_, v_k_37_);
v___x_40_ = lean_apply_2(v_U_38_, v_e_36_, v___x_39_);
return v___x_40_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__1(lean_object* v_L_41_, lean_object* v_j_42_, lean_object* v_e_43_, lean_object* v_k_44_, lean_object* v_l_45_){
_start:
{
lean_object* v_g_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; 
v_g_46_ = lean_ctor_get(v_L_41_, 1);
lean_inc_ref(v_g_46_);
lean_dec_ref(v_L_41_);
lean_inc(v_j_42_);
v___x_47_ = lean_apply_1(v_j_42_, v_k_44_);
v___x_48_ = lean_apply_1(v_j_42_, v_l_45_);
v___x_49_ = lean_apply_3(v_g_46_, v_e_43_, v___x_47_, v___x_48_);
return v___x_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg(lean_object* v_L_50_, lean_object* v_j_51_){
_start:
{
lean_object* v___f_52_; lean_object* v___f_53_; lean_object* v___x_54_; 
lean_inc(v_j_51_);
lean_inc_ref(v_L_50_);
v___f_52_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__0), 4, 2);
lean_closure_set(v___f_52_, 0, v_L_50_);
lean_closure_set(v___f_52_, 1, v_j_51_);
v___f_53_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg___lam__1), 5, 2);
lean_closure_set(v___f_53_, 0, v_L_50_);
lean_closure_set(v___f_53_, 1, v_j_51_);
v___x_54_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_54_, 0, v___f_52_);
lean_ctor_set(v___x_54_, 1, v___f_53_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex(lean_object* v_X_55_, lean_object* v_i_56_, lean_object* v_L_57_, lean_object* v_00_u03ba_58_, lean_object* v_j_59_, lean_object* v_h_60_){
_start:
{
lean_object* v___x_61_; 
v___x_61_ = lp_tree_GlobalTheory_FormalPic_FLB_reindex___redArg(v_L_57_, v_j_59_);
return v___x_61_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_reindex___boxed(lean_object* v_X_62_, lean_object* v_i_63_, lean_object* v_L_64_, lean_object* v_00_u03ba_65_, lean_object* v_j_66_, lean_object* v_h_67_){
_start:
{
lean_object* v_res_68_; 
v_res_68_ = lp_tree_GlobalTheory_FormalPic_FLB_reindex(v_X_62_, v_i_63_, v_L_64_, v_00_u03ba_65_, v_j_66_, v_h_67_);
lean_dec_ref(v_i_63_);
lean_dec_ref(v_X_62_);
return v_res_68_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_setoid(lean_object* v_X_69_, lean_object* v_i_70_){
_start:
{
lean_object* v___x_71_; 
v___x_71_ = lean_box(0);
return v___x_71_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_setoid___boxed(lean_object* v_X_72_, lean_object* v_i_73_){
_start:
{
lean_object* v_res_74_; 
v_res_74_ = lp_tree_GlobalTheory_FormalPic_FLB_setoid(v_X_72_, v_i_73_);
lean_dec_ref(v_i_73_);
lean_dec_ref(v_X_72_);
return v_res_74_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_75_; lean_object* v___x_76_; 
v___x_75_ = lean_unsigned_to_nat(1u);
v___x_76_ = lean_nat_to_int(v___x_75_);
return v___x_76_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0(lean_object* v_x_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lean_obj_once(&lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0, &lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0_once, _init_lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__0___closed__0);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1(lean_object* v___x_79_, lean_object* v_x_80_){
_start:
{
lean_inc_ref(v___x_79_);
return v___x_79_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1___boxed(lean_object* v___x_81_, lean_object* v_x_82_){
_start:
{
lean_object* v_res_83_; 
v_res_83_ = lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1(v___x_81_, v_x_82_);
lean_dec_ref(v___x_81_);
return v_res_83_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__2(lean_object* v_X_84_, lean_object* v_q_85_, lean_object* v_Y_86_, lean_object* v_L_87_, lean_object* v___f_88_, lean_object* v_e_89_, lean_object* v___y_90_){
_start:
{
lean_object* v___x_91_; lean_object* v___x_92_; lean_object* v___f_93_; lean_object* v___x_94_; lean_object* v_U_95_; lean_object* v___x_96_; 
lean_inc(v_e_89_);
v___x_91_ = lean_apply_1(v_X_84_, v_e_89_);
v___x_92_ = lean_apply_1(v_q_85_, v_e_89_);
v___f_93_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_93_, 0, v___x_92_);
v___x_94_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___at___00GlobalTheory_Cartier_secPull_spec__0(v_Y_86_, v___x_91_, v_L_87_, v___f_93_, v___f_88_);
v_U_95_ = lean_ctor_get(v___x_94_, 0);
lean_inc_ref(v_U_95_);
lean_dec_ref(v___x_94_);
v___x_96_ = lean_apply_1(v_U_95_, v___y_90_);
return v___x_96_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__5(lean_object* v_X_97_, lean_object* v_q_98_, lean_object* v_Y_99_, lean_object* v_L_100_, lean_object* v___f_101_, lean_object* v_e_102_, lean_object* v___y_103_, lean_object* v___y_104_){
_start:
{
lean_object* v___x_105_; lean_object* v___x_106_; lean_object* v___f_107_; lean_object* v___x_108_; lean_object* v_g_109_; lean_object* v___x_110_; 
lean_inc(v_e_102_);
v___x_105_ = lean_apply_1(v_X_97_, v_e_102_);
v___x_106_ = lean_apply_1(v_q_98_, v_e_102_);
v___f_107_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_107_, 0, v___x_106_);
v___x_108_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___at___00GlobalTheory_Cartier_secPull_spec__0(v_Y_99_, v___x_105_, v_L_100_, v___f_107_, v___f_101_);
v_g_109_ = lean_ctor_get(v___x_108_, 1);
lean_inc_ref(v_g_109_);
lean_dec_ref(v___x_108_);
v___x_110_ = lean_apply_2(v_g_109_, v___y_103_, v___y_104_);
return v___x_110_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg(lean_object* v_X_112_, lean_object* v_Y_113_, lean_object* v_q_114_, lean_object* v_L_115_){
_start:
{
lean_object* v___f_116_; lean_object* v___f_117_; lean_object* v___f_118_; lean_object* v___x_119_; 
v___f_116_ = ((lean_object*)(lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___closed__0));
lean_inc_ref(v_L_115_);
lean_inc_ref(v_Y_113_);
lean_inc_ref(v_q_114_);
lean_inc_ref(v_X_112_);
v___f_117_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__2), 7, 5);
lean_closure_set(v___f_117_, 0, v_X_112_);
lean_closure_set(v___f_117_, 1, v_q_114_);
lean_closure_set(v___f_117_, 2, v_Y_113_);
lean_closure_set(v___f_117_, 3, v_L_115_);
lean_closure_set(v___f_117_, 4, v___f_116_);
v___f_118_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg___lam__5), 8, 5);
lean_closure_set(v___f_118_, 0, v_X_112_);
lean_closure_set(v___f_118_, 1, v_q_114_);
lean_closure_set(v___f_118_, 2, v_Y_113_);
lean_closure_set(v___f_118_, 3, v_L_115_);
lean_closure_set(v___f_118_, 4, v___f_116_);
v___x_119_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_119_, 0, v___f_117_);
lean_ctor_set(v___x_119_, 1, v___f_118_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull(lean_object* v_X_120_, lean_object* v_i_121_, lean_object* v_Y_122_, lean_object* v_q_123_, lean_object* v_hq_124_, lean_object* v_L_125_, lean_object* v_hL_126_){
_start:
{
lean_object* v___x_127_; 
v___x_127_ = lp_tree_GlobalTheory_FormalPic_FLB_ofPull___redArg(v_X_120_, v_Y_122_, v_q_123_, v_L_125_);
return v___x_127_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_ofPull___boxed(lean_object* v_X_128_, lean_object* v_i_129_, lean_object* v_Y_130_, lean_object* v_q_131_, lean_object* v_hq_132_, lean_object* v_L_133_, lean_object* v_hL_134_){
_start:
{
lean_object* v_res_135_; 
v_res_135_ = lp_tree_GlobalTheory_FormalPic_FLB_ofPull(v_X_128_, v_i_129_, v_Y_130_, v_q_131_, v_hq_132_, v_L_133_, v_hL_134_);
lean_dec_ref(v_i_129_);
return v_res_135_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB___redArg(lean_object* v_L_136_){
_start:
{
lean_object* v_U_137_; lean_object* v_g_138_; lean_object* v___x_140_; uint8_t v_isShared_141_; uint8_t v_isSharedCheck_145_; 
v_U_137_ = lean_ctor_get(v_L_136_, 0);
v_g_138_ = lean_ctor_get(v_L_136_, 1);
v_isSharedCheck_145_ = !lean_is_exclusive(v_L_136_);
if (v_isSharedCheck_145_ == 0)
{
v___x_140_ = v_L_136_;
v_isShared_141_ = v_isSharedCheck_145_;
goto v_resetjp_139_;
}
else
{
lean_inc(v_g_138_);
lean_inc(v_U_137_);
lean_dec(v_L_136_);
v___x_140_ = lean_box(0);
v_isShared_141_ = v_isSharedCheck_145_;
goto v_resetjp_139_;
}
v_resetjp_139_:
{
lean_object* v___x_143_; 
if (v_isShared_141_ == 0)
{
v___x_143_ = v___x_140_;
goto v_reusejp_142_;
}
else
{
lean_object* v_reuseFailAlloc_144_; 
v_reuseFailAlloc_144_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_144_, 0, v_U_137_);
lean_ctor_set(v_reuseFailAlloc_144_, 1, v_g_138_);
v___x_143_ = v_reuseFailAlloc_144_;
goto v_reusejp_142_;
}
v_reusejp_142_:
{
return v___x_143_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB(lean_object* v_X_146_, lean_object* v_i_147_, lean_object* v_00_u03ba_148_, lean_object* v_L_149_){
_start:
{
lean_object* v___x_150_; 
v___x_150_ = lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB___redArg(v_L_149_);
return v___x_150_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB___boxed(lean_object* v_X_151_, lean_object* v_i_152_, lean_object* v_00_u03ba_153_, lean_object* v_L_154_){
_start:
{
lean_object* v_res_155_; 
v_res_155_ = lp_tree_GlobalTheory_FormalPic_FLBOn_toFLB(v_X_151_, v_i_152_, v_00_u03ba_153_, v_L_154_);
lean_dec_ref(v_i_152_);
lean_dec_ref(v_X_151_);
return v_res_155_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn___redArg(lean_object* v_L_156_){
_start:
{
lean_object* v_U_157_; lean_object* v_g_158_; lean_object* v___x_160_; uint8_t v_isShared_161_; uint8_t v_isSharedCheck_165_; 
v_U_157_ = lean_ctor_get(v_L_156_, 0);
v_g_158_ = lean_ctor_get(v_L_156_, 1);
v_isSharedCheck_165_ = !lean_is_exclusive(v_L_156_);
if (v_isSharedCheck_165_ == 0)
{
v___x_160_ = v_L_156_;
v_isShared_161_ = v_isSharedCheck_165_;
goto v_resetjp_159_;
}
else
{
lean_inc(v_g_158_);
lean_inc(v_U_157_);
lean_dec(v_L_156_);
v___x_160_ = lean_box(0);
v_isShared_161_ = v_isSharedCheck_165_;
goto v_resetjp_159_;
}
v_resetjp_159_:
{
lean_object* v___x_163_; 
if (v_isShared_161_ == 0)
{
v___x_163_ = v___x_160_;
goto v_reusejp_162_;
}
else
{
lean_object* v_reuseFailAlloc_164_; 
v_reuseFailAlloc_164_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_164_, 0, v_U_157_);
lean_ctor_set(v_reuseFailAlloc_164_, 1, v_g_158_);
v___x_163_ = v_reuseFailAlloc_164_;
goto v_reusejp_162_;
}
v_reusejp_162_:
{
return v___x_163_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn(lean_object* v_X_166_, lean_object* v_i_167_, lean_object* v_L_168_){
_start:
{
lean_object* v___x_169_; 
v___x_169_ = lp_tree_GlobalTheory_FormalPic_FLB_toOn___redArg(v_L_168_);
return v___x_169_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FormalPic_FLB_toOn___boxed(lean_object* v_X_170_, lean_object* v_i_171_, lean_object* v_L_172_){
_start:
{
lean_object* v_res_173_; 
v_res_173_ = lp_tree_GlobalTheory_FormalPic_FLB_toOn(v_X_170_, v_i_171_, v_L_172_);
lean_dec_ref(v_i_171_);
lean_dec_ref(v_X_170_);
return v_res_173_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_ClsLinCombSingle(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ToNatLengthEqRangeAddRange(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaMetrics_ExistsFormOfEqRatioPowMul(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_FormalTwistingNeTrivial(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_ModuliProofs_ClsLinCombSingle(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ToNatLengthEqRangeAddRange(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaMetrics_ExistsFormOfEqRatioPowMul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.ColDictIsomReTr
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.SameDegreeZeroFormsSelf public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.ECure
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___redArg(lean_object* v_G_1_){
_start:
{
lean_inc(v_G_1_);
return v_G_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___redArg___boxed(lean_object* v_G_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_tree_GlobalTheory_Mem_SRe_reG___redArg(v_G_2_);
lean_dec(v_G_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG(lean_object* v_D_4_, lean_object* v_Z_5_, lean_object* v_X_6_, lean_object* v_G_7_){
_start:
{
lean_inc(v_G_7_);
return v_G_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Mem_SRe_reG___boxed(lean_object* v_D_8_, lean_object* v_Z_9_, lean_object* v_X_10_, lean_object* v_G_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_Mem_SRe_reG(v_D_8_, v_Z_9_, v_X_10_, v_G_11_);
lean_dec(v_G_11_);
lean_dec_ref(v_X_10_);
lean_dec_ref(v_Z_9_);
lean_dec_ref(v_D_8_);
return v_res_12_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_SameDegreeZeroFormsSelf(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_ECure(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_ColDictIsomReTr(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_SameDegreeZeroFormsSelf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_ECure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.AdjKltOfLtDisc
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.ExistsIsLocModelIsPrimeOf
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_SubringClass_subtype___lam__0___boxed(lean_object*);
lean_object* lp_mathlib_RingHom_codRestrict___redArg___lam__0(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_SubringClass_subtype___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_RingHom_codRestrict___redArg___lam__0, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__0_value)} };
static const lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl(lean_object* v_k_4_, lean_object* v_K_5_, lean_object* v_inst_6_, lean_object* v_inst_7_, lean_object* v_c_8_, lean_object* v_Q_9_, lean_object* v_P_10_, lean_object* v_h_11_){
_start:
{
lean_object* v___f_12_; 
v___f_12_ = ((lean_object*)(lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___closed__1));
return v___f_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_FieldPair_AdjKlt_incl___boxed(lean_object* v_k_13_, lean_object* v_K_14_, lean_object* v_inst_15_, lean_object* v_inst_16_, lean_object* v_c_17_, lean_object* v_Q_18_, lean_object* v_P_19_, lean_object* v_h_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = lp_tree_GlobalTheory_FieldPair_AdjKlt_incl(v_k_13_, v_K_14_, v_inst_15_, v_inst_16_, v_c_17_, v_Q_18_, v_P_19_, v_h_20_);
lean_dec(v_c_17_);
lean_dec_ref(v_inst_16_);
lean_dec_ref(v_inst_15_);
return v_res_21_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsIsLocModelIsPrimeOf(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_AdjKltOfLtDisc(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsIsLocModelIsPrimeOf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.ExistsResolProjSpace
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.AevalEqZeroOfMemConeIdeal public import Development.AbelianVarietyTheory.Definitions.Divisors.IsoOverOfIsOpenImmersion
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
extern lean_object* lp_mathlib_PUnit_fintype;
lean_object* lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_div(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_CompHS_Common_pull___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_bd(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_bd___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_off(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_off___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_bd(lean_object* v_F_1_, lean_object* v_inst_2_, lean_object* v_Y_3_, lean_object* v_p_4_, lean_object* v_U_5_, lean_object* v_D_6_, lean_object* v_M_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lean_box(0);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_bd___boxed(lean_object* v_F_9_, lean_object* v_inst_10_, lean_object* v_Y_11_, lean_object* v_p_12_, lean_object* v_U_13_, lean_object* v_D_14_, lean_object* v_M_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_CompHS_Modif_bd(v_F_9_, v_inst_10_, v_Y_11_, v_p_12_, v_U_13_, v_D_14_, v_M_15_);
lean_dec_ref(v_M_15_);
lean_dec(v_D_14_);
lean_dec_ref(v_p_12_);
lean_dec_ref(v_Y_11_);
lean_dec_ref(v_inst_10_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_off(lean_object* v_F_17_, lean_object* v_inst_18_, lean_object* v_Y_19_, lean_object* v_p_20_, lean_object* v_U_21_, lean_object* v_D_22_, lean_object* v_M_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lean_box(0);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Modif_off___boxed(lean_object* v_F_25_, lean_object* v_inst_26_, lean_object* v_Y_27_, lean_object* v_p_28_, lean_object* v_U_29_, lean_object* v_D_30_, lean_object* v_M_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_GlobalTheory_CompHS_Modif_off(v_F_25_, v_inst_26_, v_Y_27_, v_p_28_, v_U_29_, v_D_30_, v_M_31_);
lean_dec_ref(v_M_31_);
lean_dec(v_D_30_);
lean_dec_ref(v_p_28_);
lean_dec_ref(v_Y_27_);
lean_dec_ref(v_inst_26_);
return v_res_32_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_33_ = lean_unsigned_to_nat(1u);
v___x_34_ = lean_nat_to_int(v___x_33_);
return v___x_34_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0(lean_object* v_x_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lean_obj_once(&lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0, &lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0_once, _init_lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__0___closed__0);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1(lean_object* v_00_u03c3_37_, lean_object* v_x_38_){
_start:
{
lean_inc_ref(v_00_u03c3_37_);
return v_00_u03c3_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed(lean_object* v_00_u03c3_39_, lean_object* v_x_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1(v_00_u03c3_39_, v_x_40_);
lean_dec_ref(v_00_u03c3_39_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___redArg(lean_object* v_Y_43_, lean_object* v_B_44_, lean_object* v_R_45_, lean_object* v_a_46_){
_start:
{
lean_object* v_toModif_47_; lean_object* v_X_48_; lean_object* v_00_u03c3_49_; lean_object* v___f_50_; lean_object* v___f_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; 
v_toModif_47_ = lean_ctor_get(v_R_45_, 0);
lean_inc_ref(v_toModif_47_);
lean_dec_ref(v_R_45_);
v_X_48_ = lean_ctor_get(v_toModif_47_, 0);
lean_inc_ref(v_X_48_);
v_00_u03c3_49_ = lean_ctor_get(v_toModif_47_, 1);
lean_inc_ref(v_00_u03c3_49_);
lean_dec_ref(v_toModif_47_);
v___f_50_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_51_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_51_, 0, v_00_u03c3_49_);
v___x_52_ = lean_apply_1(v_B_44_, v_a_46_);
v___x_53_ = lp_mathlib_PUnit_fintype;
v___x_54_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_43_, v_X_48_, v___x_52_, v___x_53_, v___f_51_, v___f_50_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb(lean_object* v_F_55_, lean_object* v_inst_56_, lean_object* v_Y_57_, lean_object* v_p_58_, lean_object* v_00_u039b_59_, lean_object* v_inst_60_, lean_object* v_B_61_, lean_object* v_C_62_, lean_object* v_U_63_, lean_object* v_D_64_, lean_object* v_a_u2081_65_, lean_object* v_a_u2082_66_, lean_object* v_W_u2081_67_, lean_object* v_W_u2082_68_, lean_object* v_R_69_, lean_object* v_a_70_){
_start:
{
lean_object* v_toModif_71_; lean_object* v_X_72_; lean_object* v_00_u03c3_73_; lean_object* v___f_74_; lean_object* v___f_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; 
v_toModif_71_ = lean_ctor_get(v_R_69_, 0);
lean_inc_ref(v_toModif_71_);
lean_dec_ref(v_R_69_);
v_X_72_ = lean_ctor_get(v_toModif_71_, 0);
lean_inc_ref(v_X_72_);
v_00_u03c3_73_ = lean_ctor_get(v_toModif_71_, 1);
lean_inc_ref(v_00_u03c3_73_);
lean_dec_ref(v_toModif_71_);
v___f_74_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_75_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_75_, 0, v_00_u03c3_73_);
v___x_76_ = lean_apply_1(v_B_61_, v_a_70_);
v___x_77_ = lp_mathlib_PUnit_fintype;
v___x_78_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_57_, v_X_72_, v___x_76_, v___x_77_, v___f_75_, v___f_74_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_pb___boxed(lean_object* v_F_79_, lean_object* v_inst_80_, lean_object* v_Y_81_, lean_object* v_p_82_, lean_object* v_00_u039b_83_, lean_object* v_inst_84_, lean_object* v_B_85_, lean_object* v_C_86_, lean_object* v_U_87_, lean_object* v_D_88_, lean_object* v_a_u2081_89_, lean_object* v_a_u2082_90_, lean_object* v_W_u2081_91_, lean_object* v_W_u2082_92_, lean_object* v_R_93_, lean_object* v_a_94_){
_start:
{
lean_object* v_res_95_; 
v_res_95_ = lp_tree_GlobalTheory_CompHS_Resol_pb(v_F_79_, v_inst_80_, v_Y_81_, v_p_82_, v_00_u039b_83_, v_inst_84_, v_B_85_, v_C_86_, v_U_87_, v_D_88_, v_a_u2081_89_, v_a_u2082_90_, v_W_u2081_91_, v_W_u2082_92_, v_R_93_, v_a_94_);
lean_dec(v_a_u2082_90_);
lean_dec(v_a_u2081_89_);
lean_dec(v_D_88_);
lean_dec_ref(v_C_86_);
lean_dec_ref(v_inst_84_);
lean_dec_ref(v_p_82_);
lean_dec_ref(v_inst_80_);
return v_res_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com___redArg(lean_object* v_Y_96_, lean_object* v_C_97_, lean_object* v_R_98_){
_start:
{
lean_object* v_toModif_99_; lean_object* v_X_100_; lean_object* v___x_101_; 
v_toModif_99_ = lean_ctor_get(v_R_98_, 0);
lean_inc_ref(v_toModif_99_);
lean_dec_ref(v_R_98_);
v_X_100_ = lean_ctor_get(v_toModif_99_, 0);
lean_inc_ref(v_X_100_);
lean_dec_ref(v_toModif_99_);
v___x_101_ = lp_tree_GlobalTheory_CompHS_Common_pull___redArg(v_Y_96_, v_X_100_, v_C_97_);
return v___x_101_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com(lean_object* v_F_102_, lean_object* v_inst_103_, lean_object* v_Y_104_, lean_object* v_p_105_, lean_object* v_00_u039b_106_, lean_object* v_inst_107_, lean_object* v_B_108_, lean_object* v_C_109_, lean_object* v_U_110_, lean_object* v_D_111_, lean_object* v_a_u2081_112_, lean_object* v_a_u2082_113_, lean_object* v_W_u2081_114_, lean_object* v_W_u2082_115_, lean_object* v_R_116_){
_start:
{
lean_object* v_toModif_117_; lean_object* v_X_118_; lean_object* v___x_119_; 
v_toModif_117_ = lean_ctor_get(v_R_116_, 0);
lean_inc_ref(v_toModif_117_);
lean_dec_ref(v_R_116_);
v_X_118_ = lean_ctor_get(v_toModif_117_, 0);
lean_inc_ref(v_X_118_);
lean_dec_ref(v_toModif_117_);
v___x_119_ = lp_tree_GlobalTheory_CompHS_Common_pull___redArg(v_Y_104_, v_X_118_, v_C_109_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_com___boxed(lean_object* v_F_120_, lean_object* v_inst_121_, lean_object* v_Y_122_, lean_object* v_p_123_, lean_object* v_00_u039b_124_, lean_object* v_inst_125_, lean_object* v_B_126_, lean_object* v_C_127_, lean_object* v_U_128_, lean_object* v_D_129_, lean_object* v_a_u2081_130_, lean_object* v_a_u2082_131_, lean_object* v_W_u2081_132_, lean_object* v_W_u2082_133_, lean_object* v_R_134_){
_start:
{
lean_object* v_res_135_; 
v_res_135_ = lp_tree_GlobalTheory_CompHS_Resol_com(v_F_120_, v_inst_121_, v_Y_122_, v_p_123_, v_00_u039b_124_, v_inst_125_, v_B_126_, v_C_127_, v_U_128_, v_D_129_, v_a_u2081_130_, v_a_u2082_131_, v_W_u2081_132_, v_W_u2082_133_, v_R_134_);
lean_dec(v_a_u2082_131_);
lean_dec(v_a_u2081_130_);
lean_dec(v_D_129_);
lean_dec_ref(v_B_126_);
lean_dec_ref(v_inst_125_);
lean_dec_ref(v_p_123_);
lean_dec_ref(v_inst_121_);
return v_res_135_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L___redArg(lean_object* v_Y_136_, lean_object* v_B_137_, lean_object* v_a_u2081_138_, lean_object* v_R_139_){
_start:
{
lean_object* v_toModif_140_; lean_object* v_00_u0394_u2081_141_; lean_object* v_X_142_; lean_object* v_00_u03c3_143_; lean_object* v_P_144_; lean_object* v___f_145_; lean_object* v___f_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; 
v_toModif_140_ = lean_ctor_get(v_R_139_, 0);
lean_inc_ref(v_toModif_140_);
v_00_u0394_u2081_141_ = lean_ctor_get(v_R_139_, 1);
lean_inc_ref(v_00_u0394_u2081_141_);
lean_dec_ref(v_R_139_);
v_X_142_ = lean_ctor_get(v_toModif_140_, 0);
lean_inc_ref_n(v_X_142_, 2);
v_00_u03c3_143_ = lean_ctor_get(v_toModif_140_, 1);
lean_inc_ref(v_00_u03c3_143_);
lean_dec_ref(v_toModif_140_);
v_P_144_ = lean_ctor_get(v_00_u0394_u2081_141_, 0);
lean_inc_ref(v_P_144_);
lean_dec_ref(v_00_u0394_u2081_141_);
v___f_145_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_146_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_146_, 0, v_00_u03c3_143_);
v___x_147_ = lean_apply_1(v_B_137_, v_a_u2081_138_);
v___x_148_ = lp_mathlib_PUnit_fintype;
v___x_149_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_136_, v_X_142_, v___x_147_, v___x_148_, v___f_146_, v___f_145_);
v___x_150_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_div(v_X_142_, v___x_149_, v_P_144_);
return v___x_150_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L(lean_object* v_F_151_, lean_object* v_inst_152_, lean_object* v_Y_153_, lean_object* v_p_154_, lean_object* v_00_u039b_155_, lean_object* v_inst_156_, lean_object* v_B_157_, lean_object* v_C_158_, lean_object* v_U_159_, lean_object* v_D_160_, lean_object* v_a_u2081_161_, lean_object* v_a_u2082_162_, lean_object* v_W_u2081_163_, lean_object* v_W_u2082_164_, lean_object* v_R_165_){
_start:
{
lean_object* v_toModif_166_; lean_object* v_00_u0394_u2081_167_; lean_object* v_X_168_; lean_object* v_00_u03c3_169_; lean_object* v_P_170_; lean_object* v___f_171_; lean_object* v___f_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; 
v_toModif_166_ = lean_ctor_get(v_R_165_, 0);
lean_inc_ref(v_toModif_166_);
v_00_u0394_u2081_167_ = lean_ctor_get(v_R_165_, 1);
lean_inc_ref(v_00_u0394_u2081_167_);
lean_dec_ref(v_R_165_);
v_X_168_ = lean_ctor_get(v_toModif_166_, 0);
lean_inc_ref_n(v_X_168_, 2);
v_00_u03c3_169_ = lean_ctor_get(v_toModif_166_, 1);
lean_inc_ref(v_00_u03c3_169_);
lean_dec_ref(v_toModif_166_);
v_P_170_ = lean_ctor_get(v_00_u0394_u2081_167_, 0);
lean_inc_ref(v_P_170_);
lean_dec_ref(v_00_u0394_u2081_167_);
v___f_171_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_172_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_172_, 0, v_00_u03c3_169_);
v___x_173_ = lean_apply_1(v_B_157_, v_a_u2081_161_);
v___x_174_ = lp_mathlib_PUnit_fintype;
v___x_175_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_153_, v_X_168_, v___x_173_, v___x_174_, v___f_172_, v___f_171_);
v___x_176_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_div(v_X_168_, v___x_175_, v_P_170_);
return v___x_176_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L___boxed(lean_object* v_F_177_, lean_object* v_inst_178_, lean_object* v_Y_179_, lean_object* v_p_180_, lean_object* v_00_u039b_181_, lean_object* v_inst_182_, lean_object* v_B_183_, lean_object* v_C_184_, lean_object* v_U_185_, lean_object* v_D_186_, lean_object* v_a_u2081_187_, lean_object* v_a_u2082_188_, lean_object* v_W_u2081_189_, lean_object* v_W_u2082_190_, lean_object* v_R_191_){
_start:
{
lean_object* v_res_192_; 
v_res_192_ = lp_tree_GlobalTheory_CompHS_Resol_L(v_F_177_, v_inst_178_, v_Y_179_, v_p_180_, v_00_u039b_181_, v_inst_182_, v_B_183_, v_C_184_, v_U_185_, v_D_186_, v_a_u2081_187_, v_a_u2082_188_, v_W_u2081_189_, v_W_u2082_190_, v_R_191_);
lean_dec(v_a_u2082_188_);
lean_dec(v_D_186_);
lean_dec_ref(v_C_184_);
lean_dec_ref(v_inst_182_);
lean_dec_ref(v_p_180_);
lean_dec_ref(v_inst_178_);
return v_res_192_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082___redArg(lean_object* v_Y_193_, lean_object* v_B_194_, lean_object* v_a_u2082_195_, lean_object* v_R_196_){
_start:
{
lean_object* v_toModif_197_; lean_object* v_00_u0394_u2082_198_; lean_object* v_X_199_; lean_object* v_00_u03c3_200_; lean_object* v_P_201_; lean_object* v___f_202_; lean_object* v___f_203_; lean_object* v___x_204_; lean_object* v___x_205_; lean_object* v___x_206_; lean_object* v___x_207_; 
v_toModif_197_ = lean_ctor_get(v_R_196_, 0);
lean_inc_ref(v_toModif_197_);
v_00_u0394_u2082_198_ = lean_ctor_get(v_R_196_, 2);
lean_inc_ref(v_00_u0394_u2082_198_);
lean_dec_ref(v_R_196_);
v_X_199_ = lean_ctor_get(v_toModif_197_, 0);
lean_inc_ref_n(v_X_199_, 2);
v_00_u03c3_200_ = lean_ctor_get(v_toModif_197_, 1);
lean_inc_ref(v_00_u03c3_200_);
lean_dec_ref(v_toModif_197_);
v_P_201_ = lean_ctor_get(v_00_u0394_u2082_198_, 0);
lean_inc_ref(v_P_201_);
lean_dec_ref(v_00_u0394_u2082_198_);
v___f_202_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_203_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_203_, 0, v_00_u03c3_200_);
v___x_204_ = lean_apply_1(v_B_194_, v_a_u2082_195_);
v___x_205_ = lp_mathlib_PUnit_fintype;
v___x_206_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_193_, v_X_199_, v___x_204_, v___x_205_, v___f_203_, v___f_202_);
v___x_207_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_div(v_X_199_, v___x_206_, v_P_201_);
return v___x_207_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082(lean_object* v_F_208_, lean_object* v_inst_209_, lean_object* v_Y_210_, lean_object* v_p_211_, lean_object* v_00_u039b_212_, lean_object* v_inst_213_, lean_object* v_B_214_, lean_object* v_C_215_, lean_object* v_U_216_, lean_object* v_D_217_, lean_object* v_a_u2081_218_, lean_object* v_a_u2082_219_, lean_object* v_W_u2081_220_, lean_object* v_W_u2082_221_, lean_object* v_R_222_){
_start:
{
lean_object* v_toModif_223_; lean_object* v_00_u0394_u2082_224_; lean_object* v_X_225_; lean_object* v_00_u03c3_226_; lean_object* v_P_227_; lean_object* v___f_228_; lean_object* v___f_229_; lean_object* v___x_230_; lean_object* v___x_231_; lean_object* v___x_232_; lean_object* v___x_233_; 
v_toModif_223_ = lean_ctor_get(v_R_222_, 0);
lean_inc_ref(v_toModif_223_);
v_00_u0394_u2082_224_ = lean_ctor_get(v_R_222_, 2);
lean_inc_ref(v_00_u0394_u2082_224_);
lean_dec_ref(v_R_222_);
v_X_225_ = lean_ctor_get(v_toModif_223_, 0);
lean_inc_ref_n(v_X_225_, 2);
v_00_u03c3_226_ = lean_ctor_get(v_toModif_223_, 1);
lean_inc_ref(v_00_u03c3_226_);
lean_dec_ref(v_toModif_223_);
v_P_227_ = lean_ctor_get(v_00_u0394_u2082_224_, 0);
lean_inc_ref(v_P_227_);
lean_dec_ref(v_00_u0394_u2082_224_);
v___f_228_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___f_229_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_229_, 0, v_00_u03c3_226_);
v___x_230_ = lean_apply_1(v_B_214_, v_a_u2082_219_);
v___x_231_ = lp_mathlib_PUnit_fintype;
v___x_232_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_210_, v_X_225_, v___x_230_, v___x_231_, v___f_229_, v___f_228_);
v___x_233_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_div(v_X_225_, v___x_232_, v_P_227_);
return v___x_233_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_L_u2082___boxed(lean_object* v_F_234_, lean_object* v_inst_235_, lean_object* v_Y_236_, lean_object* v_p_237_, lean_object* v_00_u039b_238_, lean_object* v_inst_239_, lean_object* v_B_240_, lean_object* v_C_241_, lean_object* v_U_242_, lean_object* v_D_243_, lean_object* v_a_u2081_244_, lean_object* v_a_u2082_245_, lean_object* v_W_u2081_246_, lean_object* v_W_u2082_247_, lean_object* v_R_248_){
_start:
{
lean_object* v_res_249_; 
v_res_249_ = lp_tree_GlobalTheory_CompHS_Resol_L_u2082(v_F_234_, v_inst_235_, v_Y_236_, v_p_237_, v_00_u039b_238_, v_inst_239_, v_B_240_, v_C_241_, v_U_242_, v_D_243_, v_a_u2081_244_, v_a_u2082_245_, v_W_u2081_246_, v_W_u2082_247_, v_R_248_);
lean_dec(v_a_u2081_244_);
lean_dec(v_D_243_);
lean_dec_ref(v_C_241_);
lean_dec_ref(v_inst_239_);
lean_dec_ref(v_p_237_);
lean_dec_ref(v_inst_235_);
return v_res_249_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A___redArg(lean_object* v_Y_250_, lean_object* v_inst_251_, lean_object* v_B_252_, lean_object* v_D_253_, lean_object* v_a_u2081_254_, lean_object* v_a_u2082_255_, lean_object* v_R_256_){
_start:
{
lean_object* v_toAddMonoid_257_; lean_object* v_toModif_258_; lean_object* v_toAddSemigroup_259_; lean_object* v_toNSMul_260_; lean_object* v_X_261_; lean_object* v_00_u03c3_262_; lean_object* v___f_263_; lean_object* v___x_264_; lean_object* v___x_265_; lean_object* v___f_266_; lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; 
v_toAddMonoid_257_ = lean_ctor_get(v_inst_251_, 0);
lean_inc_ref(v_toAddMonoid_257_);
lean_dec_ref(v_inst_251_);
v_toModif_258_ = lean_ctor_get(v_R_256_, 0);
lean_inc_ref(v_toModif_258_);
lean_dec_ref(v_R_256_);
v_toAddSemigroup_259_ = lean_ctor_get(v_toAddMonoid_257_, 0);
lean_inc(v_toAddSemigroup_259_);
v_toNSMul_260_ = lean_ctor_get(v_toAddMonoid_257_, 2);
lean_inc(v_toNSMul_260_);
lean_dec_ref(v_toAddMonoid_257_);
v_X_261_ = lean_ctor_get(v_toModif_258_, 0);
lean_inc_ref(v_X_261_);
v_00_u03c3_262_ = lean_ctor_get(v_toModif_258_, 1);
lean_inc_ref(v_00_u03c3_262_);
lean_dec_ref(v_toModif_258_);
v___f_263_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___x_264_ = lean_apply_2(v_toNSMul_260_, v_D_253_, v_a_u2081_254_);
v___x_265_ = lean_apply_2(v_toAddSemigroup_259_, v_a_u2082_255_, v___x_264_);
v___f_266_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_266_, 0, v_00_u03c3_262_);
v___x_267_ = lean_apply_1(v_B_252_, v___x_265_);
v___x_268_ = lp_mathlib_PUnit_fintype;
v___x_269_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_250_, v_X_261_, v___x_267_, v___x_268_, v___f_266_, v___f_263_);
return v___x_269_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A(lean_object* v_F_270_, lean_object* v_inst_271_, lean_object* v_Y_272_, lean_object* v_p_273_, lean_object* v_00_u039b_274_, lean_object* v_inst_275_, lean_object* v_B_276_, lean_object* v_C_277_, lean_object* v_U_278_, lean_object* v_D_279_, lean_object* v_a_u2081_280_, lean_object* v_a_u2082_281_, lean_object* v_W_u2081_282_, lean_object* v_W_u2082_283_, lean_object* v_R_284_){
_start:
{
lean_object* v_toAddMonoid_285_; lean_object* v_toModif_286_; lean_object* v_toAddSemigroup_287_; lean_object* v_toNSMul_288_; lean_object* v_X_289_; lean_object* v_00_u03c3_290_; lean_object* v___f_291_; lean_object* v___x_292_; lean_object* v___x_293_; lean_object* v___f_294_; lean_object* v___x_295_; lean_object* v___x_296_; lean_object* v___x_297_; 
v_toAddMonoid_285_ = lean_ctor_get(v_inst_275_, 0);
lean_inc_ref(v_toAddMonoid_285_);
lean_dec_ref(v_inst_275_);
v_toModif_286_ = lean_ctor_get(v_R_284_, 0);
lean_inc_ref(v_toModif_286_);
lean_dec_ref(v_R_284_);
v_toAddSemigroup_287_ = lean_ctor_get(v_toAddMonoid_285_, 0);
lean_inc(v_toAddSemigroup_287_);
v_toNSMul_288_ = lean_ctor_get(v_toAddMonoid_285_, 2);
lean_inc(v_toNSMul_288_);
lean_dec_ref(v_toAddMonoid_285_);
v_X_289_ = lean_ctor_get(v_toModif_286_, 0);
lean_inc_ref(v_X_289_);
v_00_u03c3_290_ = lean_ctor_get(v_toModif_286_, 1);
lean_inc_ref(v_00_u03c3_290_);
lean_dec_ref(v_toModif_286_);
v___f_291_ = ((lean_object*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___closed__0));
v___x_292_ = lean_apply_2(v_toNSMul_288_, v_D_279_, v_a_u2081_280_);
v___x_293_ = lean_apply_2(v_toAddSemigroup_287_, v_a_u2082_281_, v___x_292_);
v___f_294_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompHS_Resol_pb___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_294_, 0, v_00_u03c3_290_);
v___x_295_ = lean_apply_1(v_B_276_, v___x_293_);
v___x_296_ = lp_mathlib_PUnit_fintype;
v___x_297_ = lp_tree_ReciprocityTheory_ChartRestriction_G_Semi_LB_LinComb___redArg(v_Y_272_, v_X_289_, v___x_295_, v___x_296_, v___f_294_, v___f_291_);
return v___x_297_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompHS_Resol_A___boxed(lean_object* v_F_298_, lean_object* v_inst_299_, lean_object* v_Y_300_, lean_object* v_p_301_, lean_object* v_00_u039b_302_, lean_object* v_inst_303_, lean_object* v_B_304_, lean_object* v_C_305_, lean_object* v_U_306_, lean_object* v_D_307_, lean_object* v_a_u2081_308_, lean_object* v_a_u2082_309_, lean_object* v_W_u2081_310_, lean_object* v_W_u2082_311_, lean_object* v_R_312_){
_start:
{
lean_object* v_res_313_; 
v_res_313_ = lp_tree_GlobalTheory_CompHS_Resol_A(v_F_298_, v_inst_299_, v_Y_300_, v_p_301_, v_00_u039b_302_, v_inst_303_, v_B_304_, v_C_305_, v_U_306_, v_D_307_, v_a_u2081_308_, v_a_u2082_309_, v_W_u2081_310_, v_W_u2082_311_, v_R_312_);
lean_dec_ref(v_C_305_);
lean_dec_ref(v_p_301_);
lean_dec_ref(v_inst_299_);
return v_res_313_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_AevalEqZeroOfMemConeIdeal(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_IsoOverOfIsOpenImmersion(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsResolProjSpace(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_AevalEqZeroOfMemConeIdeal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_IsoOverOfIsOpenImmersion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

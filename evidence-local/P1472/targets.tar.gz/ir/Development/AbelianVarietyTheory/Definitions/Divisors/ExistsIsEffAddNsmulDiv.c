// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.ExistsIsEffAddNsmulDiv
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.ToNatLengthEqRangeAddRange public import Development.AbelianVarietyTheory.Definitions.ThetaMetrics.CoeNonzeroLocusCanonicalEqComplRange public import Development.AbelianVarietyTheory.Definitions.ShimuraVarieties.IsOpenOfMemIrreducibleComponentsOfFinite public import Development.AbelianVarietyTheory.Definitions.ModuliSpaces.ExistsRetractTensorTriple public import Development.AbelianVarietyTheory.Definitions.Divisors.ExistsIsClosedImmersionGenericPoint
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Additive_ofMul(lean_object*);
lean_object* lp_mathlib_AlgebraicGeometry_Scheme_IdealSheafData_instIdemCommSemiring(lean_object*);
lean_object* lp_mathlib_SubmonoidClass_toMonoid___redArg(lean_object*);
lean_object* lp_mathlib_Additive_addMonoid___redArg(lean_object*);
lean_object* lp_mathlib_AddLocalization_addMonoidOf___redArg(lean_object*);
lean_object* lp_mathlib_AlgebraicGeometry_PresheafedSpace_id___at___00AlgebraicGeometry_LocallyRingedSpace_id_spec__0(lean_object*);
lean_object* lp_mathlib_AlgebraicGeometry_PresheafedSpace_comp___at___00AlgebraicGeometry_LocallyRingedSpace_comp_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_effVert(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_effVert___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg(lean_object* v_Z_1_){
_start:
{
lean_object* v_X_2_; lean_object* v___x_3_; 
v_X_2_ = lean_ctor_get(v_Z_1_, 0);
v___x_3_ = lp_mathlib_AlgebraicGeometry_PresheafedSpace_id___at___00AlgebraicGeometry_LocallyRingedSpace_id_spec__0(v_X_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg___boxed(lean_object* v_Z_4_){
_start:
{
lean_object* v_res_5_; 
v_res_5_ = lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg(v_Z_4_);
lean_dec_ref(v_Z_4_);
return v_res_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id(lean_object* v_O_6_, lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_Z_10_){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lp_tree_GlobalTheory_Vert_Model_Hom_id___redArg(v_Z_10_);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_id___boxed(lean_object* v_O_12_, lean_object* v_inst_13_, lean_object* v_inst_14_, lean_object* v_inst_15_, lean_object* v_Z_16_){
_start:
{
lean_object* v_res_17_; 
v_res_17_ = lp_tree_GlobalTheory_Vert_Model_Hom_id(v_O_12_, v_inst_13_, v_inst_14_, v_inst_15_, v_Z_16_);
lean_dec_ref(v_Z_16_);
lean_dec_ref(v_inst_13_);
return v_res_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp___redArg(lean_object* v_Z_18_, lean_object* v_Z_u2081_19_, lean_object* v_Z_u2082_20_, lean_object* v_g_21_, lean_object* v_f_22_){
_start:
{
lean_object* v_X_23_; lean_object* v_X_24_; lean_object* v_X_25_; lean_object* v___x_26_; 
v_X_23_ = lean_ctor_get(v_Z_u2082_20_, 0);
lean_inc_ref(v_X_23_);
lean_dec_ref(v_Z_u2082_20_);
v_X_24_ = lean_ctor_get(v_Z_u2081_19_, 0);
lean_inc_ref(v_X_24_);
lean_dec_ref(v_Z_u2081_19_);
v_X_25_ = lean_ctor_get(v_Z_18_, 0);
lean_inc_ref(v_X_25_);
lean_dec_ref(v_Z_18_);
v___x_26_ = lp_mathlib_AlgebraicGeometry_PresheafedSpace_comp___at___00AlgebraicGeometry_LocallyRingedSpace_comp_spec__0(v_X_23_, v_X_24_, v_X_25_, v_g_21_, v_f_22_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp(lean_object* v_O_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_Z_31_, lean_object* v_Z_u2081_32_, lean_object* v_Z_u2082_33_, lean_object* v_g_34_, lean_object* v_f_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lp_tree_GlobalTheory_Vert_Model_Hom_comp___redArg(v_Z_31_, v_Z_u2081_32_, v_Z_u2082_33_, v_g_34_, v_f_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_Hom_comp___boxed(lean_object* v_O_37_, lean_object* v_inst_38_, lean_object* v_inst_39_, lean_object* v_inst_40_, lean_object* v_Z_41_, lean_object* v_Z_u2081_42_, lean_object* v_Z_u2082_43_, lean_object* v_g_44_, lean_object* v_f_45_){
_start:
{
lean_object* v_res_46_; 
v_res_46_ = lp_tree_GlobalTheory_Vert_Model_Hom_comp(v_O_37_, v_inst_38_, v_inst_39_, v_inst_40_, v_Z_41_, v_Z_u2081_42_, v_Z_u2082_43_, v_g_44_, v_f_45_);
lean_dec_ref(v_inst_38_);
return v_res_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_effVert(lean_object* v_O_47_, lean_object* v_inst_48_, lean_object* v_inst_49_, lean_object* v_inst_50_, lean_object* v_Z_51_){
_start:
{
lean_object* v___x_52_; 
v___x_52_ = lean_box(0);
return v___x_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_effVert___boxed(lean_object* v_O_53_, lean_object* v_inst_54_, lean_object* v_inst_55_, lean_object* v_inst_56_, lean_object* v_Z_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = lp_tree_GlobalTheory_Vert_Model_effVert(v_O_53_, v_inst_54_, v_inst_55_, v_inst_56_, v_Z_57_);
lean_dec_ref(v_Z_57_);
lean_dec_ref(v_inst_54_);
return v_res_58_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0(void){
_start:
{
lean_object* v___x_59_; 
v___x_59_ = lp_mathlib_Additive_ofMul(lean_box(0));
return v___x_59_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff___redArg(lean_object* v_Z_60_, lean_object* v_I_61_){
_start:
{
lean_object* v_X_62_; lean_object* v___x_63_; lean_object* v_toCommSemiring_64_; lean_object* v_toMonoid_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v_toFun_69_; lean_object* v___x_70_; lean_object* v___x_45__overap_71_; lean_object* v___x_72_; 
v_X_62_ = lean_ctor_get(v_Z_60_, 0);
lean_inc_ref(v_X_62_);
lean_dec_ref(v_Z_60_);
v___x_63_ = lp_mathlib_AlgebraicGeometry_Scheme_IdealSheafData_instIdemCommSemiring(v_X_62_);
v_toCommSemiring_64_ = lean_ctor_get(v___x_63_, 0);
lean_inc_ref(v_toCommSemiring_64_);
lean_dec_ref(v___x_63_);
v_toMonoid_65_ = lean_ctor_get(v_toCommSemiring_64_, 1);
lean_inc_ref(v_toMonoid_65_);
lean_dec_ref(v_toCommSemiring_64_);
v___x_66_ = lp_mathlib_SubmonoidClass_toMonoid___redArg(v_toMonoid_65_);
v___x_67_ = lp_mathlib_Additive_addMonoid___redArg(v___x_66_);
v___x_68_ = lean_obj_once(&lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0, &lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0_once, _init_lp_tree_GlobalTheory_Vert_Model_ofEff___redArg___closed__0);
v_toFun_69_ = lean_ctor_get(v___x_68_, 0);
lean_inc(v_toFun_69_);
v___x_70_ = lean_apply_1(v_toFun_69_, v_I_61_);
v___x_45__overap_71_ = lp_mathlib_AddLocalization_addMonoidOf___redArg(v___x_67_);
lean_dec_ref(v___x_67_);
v___x_72_ = lean_apply_1(v___x_45__overap_71_, v___x_70_);
return v___x_72_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff(lean_object* v_O_73_, lean_object* v_inst_74_, lean_object* v_inst_75_, lean_object* v_inst_76_, lean_object* v_Z_77_, lean_object* v_I_78_){
_start:
{
lean_object* v___x_79_; 
v___x_79_ = lp_tree_GlobalTheory_Vert_Model_ofEff___redArg(v_Z_77_, v_I_78_);
return v___x_79_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Vert_Model_ofEff___boxed(lean_object* v_O_80_, lean_object* v_inst_81_, lean_object* v_inst_82_, lean_object* v_inst_83_, lean_object* v_Z_84_, lean_object* v_I_85_){
_start:
{
lean_object* v_res_86_; 
v_res_86_ = lp_tree_GlobalTheory_Vert_Model_ofEff(v_O_80_, v_inst_81_, v_inst_82_, v_inst_83_, v_Z_84_, v_I_85_);
lean_dec_ref(v_inst_81_);
return v_res_86_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ToNatLengthEqRangeAddRange(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaMetrics_CoeNonzeroLocusCanonicalEqComplRange(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ShimuraVarieties_IsOpenOfMemIrreducibleComponentsOfFinite(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ModuliSpaces_ExistsRetractTensorTriple(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsIsClosedImmersionGenericPoint(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsIsEffAddNsmulDiv(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ToNatLengthEqRangeAddRange(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaMetrics_CoeNonzeroLocusCanonicalEqComplRange(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ShimuraVarieties_IsOpenOfMemIrreducibleComponentsOfFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ModuliSpaces_ExistsRetractTensorTriple(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ExistsIsClosedImmersionGenericPoint(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

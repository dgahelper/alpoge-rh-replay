// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.IsCuspSpaceBot
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.IsSelfDualFor public import Development.DiscreteGroups.GlobalIrreducibility.LConvCut
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_pi___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_GamMul_put___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_GamMul_put___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg___lam__0(lean_object* v_inst_1_, lean_object* v_o_u2081_2_, lean_object* v_p_3_, lean_object* v_o_u2082_4_, lean_object* v_q_5_, lean_object* v_X_6_, lean_object* v_i_7_, lean_object* v_j_8_){
_start:
{
uint8_t v___x_13_; 
v___x_13_ = lean_nat_dec_le(v_o_u2081_2_, v_i_7_);
if (v___x_13_ == 0)
{
lean_dec(v_X_6_);
goto v___jp_9_;
}
else
{
lean_object* v___x_14_; uint8_t v___x_15_; 
v___x_14_ = lean_nat_add(v_o_u2081_2_, v_p_3_);
v___x_15_ = lean_nat_dec_lt(v_i_7_, v___x_14_);
lean_dec(v___x_14_);
if (v___x_15_ == 0)
{
lean_dec(v_X_6_);
goto v___jp_9_;
}
else
{
uint8_t v___x_16_; 
v___x_16_ = lean_nat_dec_le(v_o_u2082_4_, v_j_8_);
if (v___x_16_ == 0)
{
lean_dec(v_X_6_);
goto v___jp_9_;
}
else
{
lean_object* v___x_17_; uint8_t v___x_18_; 
v___x_17_ = lean_nat_add(v_o_u2082_4_, v_q_5_);
v___x_18_ = lean_nat_dec_lt(v_j_8_, v___x_17_);
lean_dec(v___x_17_);
if (v___x_18_ == 0)
{
lean_dec(v_X_6_);
goto v___jp_9_;
}
else
{
lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; 
lean_dec_ref(v_inst_1_);
v___x_19_ = lean_nat_sub(v_i_7_, v_o_u2081_2_);
v___x_20_ = lean_nat_sub(v_j_8_, v_o_u2082_4_);
v___x_21_ = lean_apply_2(v_X_6_, v___x_19_, v___x_20_);
return v___x_21_;
}
}
}
}
v___jp_9_:
{
lean_object* v_toSemiring_10_; lean_object* v___x_11_; lean_object* v_toZero_12_; 
v_toSemiring_10_ = lean_ctor_get(v_inst_1_, 0);
lean_inc_ref(v_toSemiring_10_);
lean_dec_ref(v_inst_1_);
v___x_11_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_10_);
v_toZero_12_ = lean_ctor_get(v___x_11_, 1);
lean_inc(v_toZero_12_);
lean_dec_ref(v___x_11_);
return v_toZero_12_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg___lam__0___boxed(lean_object* v_inst_22_, lean_object* v_o_u2081_23_, lean_object* v_p_24_, lean_object* v_o_u2082_25_, lean_object* v_q_26_, lean_object* v_X_27_, lean_object* v_i_28_, lean_object* v_j_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = lp_tree_GlobalTheory_GamMul_put___redArg___lam__0(v_inst_22_, v_o_u2081_23_, v_p_24_, v_o_u2082_25_, v_q_26_, v_X_27_, v_i_28_, v_j_29_);
lean_dec(v_j_29_);
lean_dec(v_i_28_);
lean_dec(v_q_26_);
lean_dec(v_o_u2082_25_);
lean_dec(v_p_24_);
lean_dec(v_o_u2081_23_);
return v_res_30_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_GamMul_put___redArg___closed__0(void){
_start:
{
lean_object* v___x_31_; 
v___x_31_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___redArg(lean_object* v_inst_32_, lean_object* v_o_u2081_33_, lean_object* v_o_u2082_34_, lean_object* v_p_35_, lean_object* v_q_36_, lean_object* v_X_37_, lean_object* v_a_38_, lean_object* v_a_39_){
_start:
{
lean_object* v___x_40_; lean_object* v_toFun_41_; lean_object* v___f_42_; lean_object* v___x_43_; 
v___x_40_ = lean_obj_once(&lp_tree_GlobalTheory_GamMul_put___redArg___closed__0, &lp_tree_GlobalTheory_GamMul_put___redArg___closed__0_once, _init_lp_tree_GlobalTheory_GamMul_put___redArg___closed__0);
v_toFun_41_ = lean_ctor_get(v___x_40_, 0);
v___f_42_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_GamMul_put___redArg___lam__0___boxed), 8, 6);
lean_closure_set(v___f_42_, 0, v_inst_32_);
lean_closure_set(v___f_42_, 1, v_o_u2081_33_);
lean_closure_set(v___f_42_, 2, v_p_35_);
lean_closure_set(v___f_42_, 3, v_o_u2082_34_);
lean_closure_set(v___f_42_, 4, v_q_36_);
lean_closure_set(v___f_42_, 5, v_X_37_);
lean_inc(v_toFun_41_);
v___x_43_ = lean_apply_3(v_toFun_41_, v___f_42_, v_a_38_, v_a_39_);
return v___x_43_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put(lean_object* v_R_44_, lean_object* v_inst_45_, lean_object* v_n_46_, lean_object* v_o_u2081_47_, lean_object* v_o_u2082_48_, lean_object* v_p_49_, lean_object* v_q_50_, lean_object* v_X_51_, lean_object* v_a_52_, lean_object* v_a_53_){
_start:
{
lean_object* v___x_54_; 
v___x_54_ = lp_tree_GlobalTheory_GamMul_put___redArg(v_inst_45_, v_o_u2081_47_, v_o_u2082_48_, v_p_49_, v_q_50_, v_X_51_, v_a_52_, v_a_53_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_put___boxed(lean_object* v_R_55_, lean_object* v_inst_56_, lean_object* v_n_57_, lean_object* v_o_u2081_58_, lean_object* v_o_u2082_59_, lean_object* v_p_60_, lean_object* v_q_61_, lean_object* v_X_62_, lean_object* v_a_63_, lean_object* v_a_64_){
_start:
{
lean_object* v_res_65_; 
v_res_65_ = lp_tree_GlobalTheory_GamMul_put(v_R_55_, v_inst_56_, v_n_57_, v_o_u2081_58_, v_o_u2082_59_, v_p_60_, v_q_61_, v_X_62_, v_a_63_, v_a_64_);
lean_dec(v_n_57_);
return v_res_65_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0(lean_object* v_toOne_66_, lean_object* v_x_67_){
_start:
{
lean_inc(v_toOne_66_);
return v_toOne_66_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0___boxed(lean_object* v_toOne_68_, lean_object* v_x_69_){
_start:
{
lean_object* v_res_70_; 
v_res_70_ = lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0(v_toOne_68_, v_x_69_);
lean_dec(v_x_69_);
lean_dec(v_toOne_68_);
return v_res_70_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___redArg(lean_object* v_inst_71_, lean_object* v_o_u2081_72_, lean_object* v_o_u2082_73_, lean_object* v_p_74_, lean_object* v_a_75_, lean_object* v_a_76_){
_start:
{
lean_object* v_toSemiring_77_; lean_object* v___x_78_; lean_object* v_toZero_79_; lean_object* v___x_80_; lean_object* v_toAddMonoidWithOne_81_; lean_object* v_toOne_82_; lean_object* v___x_83_; lean_object* v___f_84_; lean_object* v___x_85_; lean_object* v___x_86_; 
v_toSemiring_77_ = lean_ctor_get(v_inst_71_, 0);
lean_inc_ref(v_toSemiring_77_);
v___x_78_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_77_);
v_toZero_79_ = lean_ctor_get(v___x_78_, 1);
lean_inc(v_toZero_79_);
lean_dec_ref(v___x_78_);
lean_inc_ref(v_inst_71_);
v___x_80_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_71_);
v_toAddMonoidWithOne_81_ = lean_ctor_get(v___x_80_, 1);
lean_inc_ref(v_toAddMonoidWithOne_81_);
lean_dec_ref(v___x_80_);
v_toOne_82_ = lean_ctor_get(v_toAddMonoidWithOne_81_, 2);
lean_inc(v_toOne_82_);
lean_dec_ref(v_toAddMonoidWithOne_81_);
lean_inc_n(v_p_74_, 2);
v___x_83_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_83_, 0, v_p_74_);
v___f_84_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_GamMul_eye___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_84_, 0, v_toOne_82_);
v___x_85_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_diagonal), 7, 5);
lean_closure_set(v___x_85_, 0, lean_box(0));
lean_closure_set(v___x_85_, 1, lean_box(0));
lean_closure_set(v___x_85_, 2, v___x_83_);
lean_closure_set(v___x_85_, 3, v_toZero_79_);
lean_closure_set(v___x_85_, 4, v___f_84_);
v___x_86_ = lp_tree_GlobalTheory_GamMul_put___redArg(v_inst_71_, v_o_u2081_72_, v_o_u2082_73_, v_p_74_, v_p_74_, v___x_85_, v_a_75_, v_a_76_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye(lean_object* v_R_87_, lean_object* v_inst_88_, lean_object* v_n_89_, lean_object* v_o_u2081_90_, lean_object* v_o_u2082_91_, lean_object* v_p_92_, lean_object* v_a_93_, lean_object* v_a_94_){
_start:
{
lean_object* v___x_95_; 
v___x_95_ = lp_tree_GlobalTheory_GamMul_eye___redArg(v_inst_88_, v_o_u2081_90_, v_o_u2082_91_, v_p_92_, v_a_93_, v_a_94_);
return v___x_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_eye___boxed(lean_object* v_R_96_, lean_object* v_inst_97_, lean_object* v_n_98_, lean_object* v_o_u2081_99_, lean_object* v_o_u2082_100_, lean_object* v_p_101_, lean_object* v_a_102_, lean_object* v_a_103_){
_start:
{
lean_object* v_res_104_; 
v_res_104_ = lp_tree_GlobalTheory_GamMul_eye(v_R_96_, v_inst_97_, v_n_98_, v_o_u2081_99_, v_o_u2082_100_, v_p_101_, v_a_102_, v_a_103_);
lean_dec(v_n_98_);
return v_res_104_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___redArg___lam__0(lean_object* v_00_u03c0_105_, lean_object* v_l_106_, lean_object* v_g_107_, lean_object* v___y_108_){
_start:
{
lean_object* v___x_109_; lean_object* v___x_110_; 
v___x_109_ = lean_apply_1(v_00_u03c0_105_, v_g_107_);
v___x_110_ = lp_mathlib_LinearMap_comp___redArg___lam__0(v___x_109_, v_l_106_, v___y_108_);
return v___x_110_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___redArg(lean_object* v_00_u03c0_111_, lean_object* v_l_112_){
_start:
{
lean_object* v___f_113_; lean_object* v___f_114_; 
v___f_113_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_GamMul_whMap___redArg___lam__0), 4, 2);
lean_closure_set(v___f_113_, 0, v_00_u03c0_111_);
lean_closure_set(v___f_113_, 1, v_l_112_);
v___f_114_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_pi___redArg___lam__0), 3, 1);
lean_closure_set(v___f_114_, 0, v___f_113_);
return v___f_114_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap(lean_object* v_k_115_, lean_object* v_inst_116_, lean_object* v_n_117_, lean_object* v_V_118_, lean_object* v_inst_119_, lean_object* v_inst_120_, lean_object* v_00_u03c0_121_, lean_object* v_l_122_){
_start:
{
lean_object* v___x_123_; 
v___x_123_ = lp_tree_GlobalTheory_GamMul_whMap___redArg(v_00_u03c0_121_, v_l_122_);
return v___x_123_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GamMul_whMap___boxed(lean_object* v_k_124_, lean_object* v_inst_125_, lean_object* v_n_126_, lean_object* v_V_127_, lean_object* v_inst_128_, lean_object* v_inst_129_, lean_object* v_00_u03c0_130_, lean_object* v_l_131_){
_start:
{
lean_object* v_res_132_; 
v_res_132_ = lp_tree_GlobalTheory_GamMul_whMap(v_k_124_, v_inst_125_, v_n_126_, v_V_127_, v_inst_128_, v_inst_129_, v_00_u03c0_130_, v_l_131_);
lean_dec(v_inst_129_);
lean_dec_ref(v_inst_128_);
lean_dec(v_n_126_);
lean_dec_ref(v_inst_125_);
return v_res_132_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsSelfDualFor(uint8_t builtin);
lean_object* initialize_tree_Development_DiscreteGroups_GlobalIrreducibility_LConvCut(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_IsCuspSpaceBot(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsSelfDualFor(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_DiscreteGroups_GlobalIrreducibility_LConvCut(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

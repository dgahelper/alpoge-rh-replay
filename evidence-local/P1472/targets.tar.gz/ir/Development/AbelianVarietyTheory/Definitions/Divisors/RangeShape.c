// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.RangeShape
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.RealPlaceAnalysis.SmoothOnGVIff public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.PseudoCoefficientUpqTrivial public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.DiscreteSeriesCharacter public import Development.AbelianVarietyTheory.Definitions.Divisors.TCoefMInMMul
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg(lean_object* v_00_u03b5_3_, lean_object* v_B_4_, lean_object* v_a_5_, lean_object* v_b_6_){
_start:
{
lean_object* v___x_9_; uint8_t v___x_26_; 
lean_inc_ref(v_00_u03b5_3_);
lean_inc(v_a_5_);
v___x_9_ = lean_apply_1(v_00_u03b5_3_, v_a_5_);
v___x_26_ = lean_unbox(v___x_9_);
if (v___x_26_ == 0)
{
goto v___jp_10_;
}
else
{
lean_object* v___x_27_; uint8_t v___x_28_; 
lean_inc_ref(v_00_u03b5_3_);
lean_inc(v_b_6_);
v___x_27_ = lean_apply_1(v_00_u03b5_3_, v_b_6_);
v___x_28_ = lean_unbox(v___x_27_);
if (v___x_28_ == 0)
{
lean_object* v___x_29_; lean_object* v___x_30_; 
lean_dec_ref(v_00_u03b5_3_);
v___x_29_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_29_, 0, v_a_5_);
lean_ctor_set(v___x_29_, 1, v_b_6_);
v___x_30_ = lean_apply_1(v_B_4_, v___x_29_);
return v___x_30_;
}
else
{
goto v___jp_10_;
}
}
v___jp_7_:
{
lean_object* v___x_8_; 
v___x_8_ = lean_obj_once(&lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0, &lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0_once, _init_lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg___closed__0);
return v___x_8_;
}
v___jp_10_:
{
lean_object* v___x_11_; uint8_t v___x_12_; 
lean_inc(v_b_6_);
v___x_11_ = lean_apply_1(v_00_u03b5_3_, v_b_6_);
v___x_12_ = lean_unbox(v___x_11_);
if (v___x_12_ == 0)
{
lean_dec(v_b_6_);
lean_dec(v_a_5_);
lean_dec_ref(v_B_4_);
goto v___jp_7_;
}
else
{
uint8_t v___x_13_; 
v___x_13_ = lean_unbox(v___x_9_);
if (v___x_13_ == 0)
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v_re_16_; lean_object* v_im_17_; lean_object* v___x_19_; uint8_t v_isShared_20_; uint8_t v_isSharedCheck_25_; 
v___x_14_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_14_, 0, v_b_6_);
lean_ctor_set(v___x_14_, 1, v_a_5_);
v___x_15_ = lean_apply_1(v_B_4_, v___x_14_);
v_re_16_ = lean_ctor_get(v___x_15_, 0);
v_im_17_ = lean_ctor_get(v___x_15_, 1);
v_isSharedCheck_25_ = !lean_is_exclusive(v___x_15_);
if (v_isSharedCheck_25_ == 0)
{
v___x_19_ = v___x_15_;
v_isShared_20_ = v_isSharedCheck_25_;
goto v_resetjp_18_;
}
else
{
lean_inc(v_im_17_);
lean_inc(v_re_16_);
lean_dec(v___x_15_);
v___x_19_ = lean_box(0);
v_isShared_20_ = v_isSharedCheck_25_;
goto v_resetjp_18_;
}
v_resetjp_18_:
{
lean_object* v___f_21_; lean_object* v___x_23_; 
v___f_21_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_21_, 0, v_im_17_);
if (v_isShared_20_ == 0)
{
lean_ctor_set(v___x_19_, 1, v___f_21_);
v___x_23_ = v___x_19_;
goto v_reusejp_22_;
}
else
{
lean_object* v_reuseFailAlloc_24_; 
v_reuseFailAlloc_24_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_24_, 0, v_re_16_);
lean_ctor_set(v_reuseFailAlloc_24_, 1, v___f_21_);
v___x_23_ = v_reuseFailAlloc_24_;
goto v_reusejp_22_;
}
v_reusejp_22_:
{
return v___x_23_;
}
}
}
else
{
lean_dec(v_b_6_);
lean_dec(v_a_5_);
lean_dec_ref(v_B_4_);
goto v___jp_7_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB(lean_object* v_n_31_, lean_object* v_00_u03b5_32_, lean_object* v_B_33_, lean_object* v_a_34_, lean_object* v_b_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lp_tree_GlobalTheory_PsCo_Pc3_pB___redArg(v_00_u03b5_32_, v_B_33_, v_a_34_, v_b_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_pB___boxed(lean_object* v_n_37_, lean_object* v_00_u03b5_38_, lean_object* v_B_39_, lean_object* v_a_40_, lean_object* v_b_41_){
_start:
{
lean_object* v_res_42_; 
v_res_42_ = lp_tree_GlobalTheory_PsCo_Pc3_pB(v_n_37_, v_00_u03b5_38_, v_B_39_, v_a_40_, v_b_41_);
lean_dec(v_n_37_);
return v_res_42_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM___redArg(lean_object* v_g_43_, lean_object* v_x_44_){
_start:
{
lean_object* v_fst_45_; lean_object* v_snd_46_; lean_object* v___x_47_; 
v_fst_45_ = lean_ctor_get(v_x_44_, 0);
lean_inc(v_fst_45_);
v_snd_46_ = lean_ctor_get(v_x_44_, 1);
lean_inc(v_snd_46_);
lean_dec_ref(v_x_44_);
v___x_47_ = lean_apply_2(v_g_43_, v_fst_45_, v_snd_46_);
return v___x_47_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM(lean_object* v_n_48_, lean_object* v_00_u03b5_49_, lean_object* v_g_50_, lean_object* v_x_51_){
_start:
{
lean_object* v___x_52_; 
v___x_52_ = lp_tree_GlobalTheory_PsCo_Pc3_blkM___redArg(v_g_50_, v_x_51_);
return v___x_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PsCo_Pc3_blkM___boxed(lean_object* v_n_53_, lean_object* v_00_u03b5_54_, lean_object* v_g_55_, lean_object* v_x_56_){
_start:
{
lean_object* v_res_57_; 
v_res_57_ = lp_tree_GlobalTheory_PsCo_Pc3_blkM(v_n_53_, v_00_u03b5_54_, v_g_55_, v_x_56_);
lean_dec_ref(v_00_u03b5_54_);
lean_dec(v_n_53_);
return v_res_57_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_RealPlaceAnalysis_SmoothOnGVIff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_PseudoCoefficientUpqTrivial(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_DiscreteSeriesCharacter(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_TCoefMInMMul(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_RangeShape(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_RealPlaceAnalysis_SmoothOnGVIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_PseudoCoefficientUpqTrivial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_DiscreteSeriesCharacter(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_TCoefMInMMul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

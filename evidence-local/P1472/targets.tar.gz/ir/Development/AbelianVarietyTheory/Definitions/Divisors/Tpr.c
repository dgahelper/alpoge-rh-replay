// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.Tpr
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.WignerVanishingGL public import Formalism.RealPlaceAnalysis.StatementB
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Module_End_instRing___redArg(lean_object*);
lean_object* lp_tree_Formalism_REAL_epow___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0(lean_object* v_00_u03c6_1_, lean_object* v_y_2_, lean_object* v___x_3_, lean_object* v_n_4_, lean_object* v_B_5_, lean_object* v_r_6_, lean_object* v_x_7_, lean_object* v_A_8_, lean_object* v_p_9_, lean_object* v_z_10_){
_start:
{
lean_object* v___x_11_; lean_object* v___x_47__overap_12_; lean_object* v___x_13_; lean_object* v___x_48__overap_14_; lean_object* v___x_15_; 
lean_inc(v_z_10_);
lean_inc(v_y_2_);
v___x_11_ = lean_apply_2(v_00_u03c6_1_, v_y_2_, v_z_10_);
lean_inc(v_x_7_);
lean_inc(v_n_4_);
lean_inc_ref(v___x_3_);
v___x_47__overap_12_ = lp_tree_Formalism_REAL_epow___redArg(v___x_3_, v_n_4_, v_B_5_, v_r_6_, v_x_7_, v_z_10_);
v___x_13_ = lean_apply_1(v___x_47__overap_12_, v___x_11_);
v___x_48__overap_14_ = lp_tree_Formalism_REAL_epow___redArg(v___x_3_, v_n_4_, v_A_8_, v_p_9_, v_x_7_, v_y_2_);
v___x_15_ = lean_apply_1(v___x_48__overap_14_, v___x_13_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0___boxed(lean_object* v_00_u03c6_16_, lean_object* v_y_17_, lean_object* v___x_18_, lean_object* v_n_19_, lean_object* v_B_20_, lean_object* v_r_21_, lean_object* v_x_22_, lean_object* v_A_23_, lean_object* v_p_24_, lean_object* v_z_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0(v_00_u03c6_16_, v_y_17_, v___x_18_, v_n_19_, v_B_20_, v_r_21_, v_x_22_, v_A_23_, v_p_24_, v_z_25_);
lean_dec(v_p_24_);
lean_dec(v_r_21_);
return v_res_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1(lean_object* v_00_u03c6_27_, lean_object* v___x_28_, lean_object* v_n_29_, lean_object* v_B_30_, lean_object* v_r_31_, lean_object* v_x_32_, lean_object* v_A_33_, lean_object* v_p_34_, lean_object* v_toAddMonoid_35_, lean_object* v___x_36_, lean_object* v_y_37_){
_start:
{
lean_object* v___f_38_; lean_object* v___x_39_; 
v___f_38_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__0___boxed), 10, 9);
lean_closure_set(v___f_38_, 0, v_00_u03c6_27_);
lean_closure_set(v___f_38_, 1, v_y_37_);
lean_closure_set(v___f_38_, 2, v___x_28_);
lean_closure_set(v___f_38_, 3, v_n_29_);
lean_closure_set(v___f_38_, 4, v_B_30_);
lean_closure_set(v___f_38_, 5, v_r_31_);
lean_closure_set(v___f_38_, 6, v_x_32_);
lean_closure_set(v___f_38_, 7, v_A_33_);
lean_closure_set(v___f_38_, 8, v_p_34_);
v___x_39_ = lp_mathlib_Finset_sum___redArg(v_toAddMonoid_35_, v___x_36_, v___f_38_);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1___boxed(lean_object* v_00_u03c6_40_, lean_object* v___x_41_, lean_object* v_n_42_, lean_object* v_B_43_, lean_object* v_r_44_, lean_object* v_x_45_, lean_object* v_A_46_, lean_object* v_p_47_, lean_object* v_toAddMonoid_48_, lean_object* v___x_49_, lean_object* v_y_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1(v_00_u03c6_40_, v___x_41_, v_n_42_, v_B_43_, v_r_44_, v_x_45_, v_A_46_, v_p_47_, v_toAddMonoid_48_, v___x_49_, v_y_50_);
lean_dec_ref(v_toAddMonoid_48_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__2(lean_object* v_00_u03c6_52_, lean_object* v___x_53_, lean_object* v_n_54_, lean_object* v_B_55_, lean_object* v_r_56_, lean_object* v_A_57_, lean_object* v_p_58_, lean_object* v_toAddMonoid_59_, lean_object* v___x_60_, lean_object* v_x_61_){
_start:
{
lean_object* v___f_62_; lean_object* v___x_63_; 
lean_inc(v___x_60_);
lean_inc_ref(v_toAddMonoid_59_);
v___f_62_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__1___boxed), 11, 10);
lean_closure_set(v___f_62_, 0, v_00_u03c6_52_);
lean_closure_set(v___f_62_, 1, v___x_53_);
lean_closure_set(v___f_62_, 2, v_n_54_);
lean_closure_set(v___f_62_, 3, v_B_55_);
lean_closure_set(v___f_62_, 4, v_r_56_);
lean_closure_set(v___f_62_, 5, v_x_61_);
lean_closure_set(v___f_62_, 6, v_A_57_);
lean_closure_set(v___f_62_, 7, v_p_58_);
lean_closure_set(v___f_62_, 8, v_toAddMonoid_59_);
lean_closure_set(v___f_62_, 9, v___x_60_);
v___x_63_ = lp_mathlib_Finset_sum___redArg(v_toAddMonoid_59_, v___x_60_, v___f_62_);
lean_dec_ref(v_toAddMonoid_59_);
return v___x_63_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___redArg(lean_object* v_inst_64_, lean_object* v_n_65_, lean_object* v_A_66_, lean_object* v_B_67_, lean_object* v_p_68_, lean_object* v_r_69_, lean_object* v_00_u03c6_70_){
_start:
{
lean_object* v_toAddMonoid_71_; lean_object* v___x_72_; lean_object* v___x_73_; lean_object* v___f_74_; lean_object* v___x_75_; 
v_toAddMonoid_71_ = lean_ctor_get(v_inst_64_, 0);
lean_inc_ref_n(v_toAddMonoid_71_, 2);
lean_inc(v_n_65_);
v___x_72_ = l_List_finRange(v_n_65_);
v___x_73_ = lp_mathlib_Module_End_instRing___redArg(v_inst_64_);
lean_inc(v___x_72_);
v___f_74_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_WigAlg_tpr___redArg___lam__2), 10, 9);
lean_closure_set(v___f_74_, 0, v_00_u03c6_70_);
lean_closure_set(v___f_74_, 1, v___x_73_);
lean_closure_set(v___f_74_, 2, v_n_65_);
lean_closure_set(v___f_74_, 3, v_B_67_);
lean_closure_set(v___f_74_, 4, v_r_69_);
lean_closure_set(v___f_74_, 5, v_A_66_);
lean_closure_set(v___f_74_, 6, v_p_68_);
lean_closure_set(v___f_74_, 7, v_toAddMonoid_71_);
lean_closure_set(v___f_74_, 8, v___x_72_);
v___x_75_ = lp_mathlib_Finset_sum___redArg(v_toAddMonoid_71_, v___x_72_, v___f_74_);
lean_dec_ref(v_toAddMonoid_71_);
return v___x_75_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr(lean_object* v_M_76_, lean_object* v_inst_77_, lean_object* v_inst_78_, lean_object* v_n_79_, lean_object* v_A_80_, lean_object* v_B_81_, lean_object* v_p_82_, lean_object* v_r_83_, lean_object* v_00_u03c6_84_){
_start:
{
lean_object* v___x_85_; 
v___x_85_ = lp_tree_GlobalTheory_WigAlg_tpr___redArg(v_inst_77_, v_n_79_, v_A_80_, v_B_81_, v_p_82_, v_r_83_, v_00_u03c6_84_);
return v___x_85_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_WigAlg_tpr___boxed(lean_object* v_M_86_, lean_object* v_inst_87_, lean_object* v_inst_88_, lean_object* v_n_89_, lean_object* v_A_90_, lean_object* v_B_91_, lean_object* v_p_92_, lean_object* v_r_93_, lean_object* v_00_u03c6_94_){
_start:
{
lean_object* v_res_95_; 
v_res_95_ = lp_tree_GlobalTheory_WigAlg_tpr(v_M_86_, v_inst_87_, v_inst_88_, v_n_89_, v_A_90_, v_B_91_, v_p_92_, v_r_93_, v_00_u03c6_94_);
lean_dec(v_inst_88_);
return v_res_95_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_WignerVanishingGL(uint8_t builtin);
lean_object* initialize_tree_Formalism_RealPlaceAnalysis_StatementB(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_Tpr(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_WignerVanishingGL(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_RealPlaceAnalysis_StatementB(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

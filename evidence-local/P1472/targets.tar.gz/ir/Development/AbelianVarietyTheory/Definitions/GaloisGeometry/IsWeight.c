// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.GaloisGeometry.IsWeight
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.GaloisRepOfPolarizedPair public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.BaseChangeDefiniteUnitary public import Development.AutomorphicArithmetic.AutomorphicVarieties.AutomorphicForms.BlochKatoSelmerVanishes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_toCtorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_toCtorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_toCtorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_toCtorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
case 2:
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
case 3:
{
lean_object* v___x_5_; 
v___x_5_ = lean_unsigned_to_nat(3u);
return v___x_5_;
}
default: 
{
lean_object* v___x_6_; 
v___x_6_ = lean_unsigned_to_nat(4u);
return v___x_6_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorIdx___boxed(lean_object* v_x_7_){
_start:
{
uint8_t v_x_boxed_8_; lean_object* v_res_9_; 
v_x_boxed_8_ = lean_unbox(v_x_7_);
v_res_9_ = lp_tree_GlobalTheory_GalCut_Clause_ctorIdx(v_x_boxed_8_);
return v_res_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_toCtorIdx(uint8_t v_x_10_){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lp_tree_GlobalTheory_GalCut_Clause_ctorIdx(v_x_10_);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_toCtorIdx___boxed(lean_object* v_x_12_){
_start:
{
uint8_t v_x_4__boxed_13_; lean_object* v_res_14_; 
v_x_4__boxed_13_ = lean_unbox(v_x_12_);
v_res_14_ = lp_tree_GlobalTheory_GalCut_Clause_toCtorIdx(v_x_4__boxed_13_);
return v_res_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___redArg(lean_object* v_k_15_){
_start:
{
lean_inc(v_k_15_);
return v_k_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___redArg___boxed(lean_object* v_k_16_){
_start:
{
lean_object* v_res_17_; 
v_res_17_ = lp_tree_GlobalTheory_GalCut_Clause_ctorElim___redArg(v_k_16_);
lean_dec(v_k_16_);
return v_res_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim(lean_object* v_motive_18_, lean_object* v_ctorIdx_19_, uint8_t v_t_20_, lean_object* v_h_21_, lean_object* v_k_22_){
_start:
{
lean_inc(v_k_22_);
return v_k_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ctorElim___boxed(lean_object* v_motive_23_, lean_object* v_ctorIdx_24_, lean_object* v_t_25_, lean_object* v_h_26_, lean_object* v_k_27_){
_start:
{
uint8_t v_t_boxed_28_; lean_object* v_res_29_; 
v_t_boxed_28_ = lean_unbox(v_t_25_);
v_res_29_ = lp_tree_GlobalTheory_GalCut_Clause_ctorElim(v_motive_23_, v_ctorIdx_24_, v_t_boxed_28_, v_h_26_, v_k_27_);
lean_dec(v_k_27_);
lean_dec(v_ctorIdx_24_);
return v_res_29_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___redArg(lean_object* v_ss_30_){
_start:
{
lean_inc(v_ss_30_);
return v_ss_30_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___redArg___boxed(lean_object* v_ss_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_tree_GlobalTheory_GalCut_Clause_ss_elim___redArg(v_ss_31_);
lean_dec(v_ss_31_);
return v_res_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim(lean_object* v_motive_33_, uint8_t v_t_34_, lean_object* v_h_35_, lean_object* v_ss_36_){
_start:
{
lean_inc(v_ss_36_);
return v_ss_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_ss_elim___boxed(lean_object* v_motive_37_, lean_object* v_t_38_, lean_object* v_h_39_, lean_object* v_ss_40_){
_start:
{
uint8_t v_t_boxed_41_; lean_object* v_res_42_; 
v_t_boxed_41_ = lean_unbox(v_t_38_);
v_res_42_ = lp_tree_GlobalTheory_GalCut_Clause_ss_elim(v_motive_37_, v_t_boxed_41_, v_h_39_, v_ss_40_);
lean_dec(v_ss_40_);
return v_res_42_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___redArg(lean_object* v_pure_43_){
_start:
{
lean_inc(v_pure_43_);
return v_pure_43_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___redArg___boxed(lean_object* v_pure_44_){
_start:
{
lean_object* v_res_45_; 
v_res_45_ = lp_tree_GlobalTheory_GalCut_Clause_pure_elim___redArg(v_pure_44_);
lean_dec(v_pure_44_);
return v_res_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim(lean_object* v_motive_46_, uint8_t v_t_47_, lean_object* v_h_48_, lean_object* v_pure_49_){
_start:
{
lean_inc(v_pure_49_);
return v_pure_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_pure_elim___boxed(lean_object* v_motive_50_, lean_object* v_t_51_, lean_object* v_h_52_, lean_object* v_pure_53_){
_start:
{
uint8_t v_t_boxed_54_; lean_object* v_res_55_; 
v_t_boxed_54_ = lean_unbox(v_t_51_);
v_res_55_ = lp_tree_GlobalTheory_GalCut_Clause_pure_elim(v_motive_50_, v_t_boxed_54_, v_h_52_, v_pure_53_);
lean_dec(v_pure_53_);
return v_res_55_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___redArg(lean_object* v_dR_56_){
_start:
{
lean_inc(v_dR_56_);
return v_dR_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___redArg___boxed(lean_object* v_dR_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = lp_tree_GlobalTheory_GalCut_Clause_dR_elim___redArg(v_dR_57_);
lean_dec(v_dR_57_);
return v_res_58_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim(lean_object* v_motive_59_, uint8_t v_t_60_, lean_object* v_h_61_, lean_object* v_dR_62_){
_start:
{
lean_inc(v_dR_62_);
return v_dR_62_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_dR_elim___boxed(lean_object* v_motive_63_, lean_object* v_t_64_, lean_object* v_h_65_, lean_object* v_dR_66_){
_start:
{
uint8_t v_t_boxed_67_; lean_object* v_res_68_; 
v_t_boxed_67_ = lean_unbox(v_t_64_);
v_res_68_ = lp_tree_GlobalTheory_GalCut_Clause_dR_elim(v_motive_63_, v_t_boxed_67_, v_h_65_, v_dR_66_);
lean_dec(v_dR_66_);
return v_res_68_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___redArg(lean_object* v_crys_69_){
_start:
{
lean_inc(v_crys_69_);
return v_crys_69_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___redArg___boxed(lean_object* v_crys_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = lp_tree_GlobalTheory_GalCut_Clause_crys_elim___redArg(v_crys_70_);
lean_dec(v_crys_70_);
return v_res_71_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim(lean_object* v_motive_72_, uint8_t v_t_73_, lean_object* v_h_74_, lean_object* v_crys_75_){
_start:
{
lean_inc(v_crys_75_);
return v_crys_75_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_crys_elim___boxed(lean_object* v_motive_76_, lean_object* v_t_77_, lean_object* v_h_78_, lean_object* v_crys_79_){
_start:
{
uint8_t v_t_boxed_80_; lean_object* v_res_81_; 
v_t_boxed_80_ = lean_unbox(v_t_77_);
v_res_81_ = lp_tree_GlobalTheory_GalCut_Clause_crys_elim(v_motive_76_, v_t_boxed_80_, v_h_78_, v_crys_79_);
lean_dec(v_crys_79_);
return v_res_81_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___redArg(lean_object* v_iwa_82_){
_start:
{
lean_inc(v_iwa_82_);
return v_iwa_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___redArg___boxed(lean_object* v_iwa_83_){
_start:
{
lean_object* v_res_84_; 
v_res_84_ = lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___redArg(v_iwa_83_);
lean_dec(v_iwa_83_);
return v_res_84_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim(lean_object* v_motive_85_, uint8_t v_t_86_, lean_object* v_h_87_, lean_object* v_iwa_88_){
_start:
{
lean_inc(v_iwa_88_);
return v_iwa_88_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Clause_iwa_elim___boxed(lean_object* v_motive_89_, lean_object* v_t_90_, lean_object* v_h_91_, lean_object* v_iwa_92_){
_start:
{
uint8_t v_t_boxed_93_; lean_object* v_res_94_; 
v_t_boxed_93_ = lean_unbox(v_t_90_);
v_res_94_ = lp_tree_GlobalTheory_GalCut_Clause_iwa_elim(v_motive_89_, v_t_boxed_93_, v_h_91_, v_iwa_92_);
lean_dec(v_iwa_92_);
return v_res_94_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorIdx(uint8_t v_x_95_){
_start:
{
switch(v_x_95_)
{
case 0:
{
lean_object* v___x_96_; 
v___x_96_ = lean_unsigned_to_nat(0u);
return v___x_96_;
}
case 1:
{
lean_object* v___x_97_; 
v___x_97_ = lean_unsigned_to_nat(1u);
return v___x_97_;
}
default: 
{
lean_object* v___x_98_; 
v___x_98_ = lean_unsigned_to_nat(2u);
return v___x_98_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorIdx___boxed(lean_object* v_x_99_){
_start:
{
uint8_t v_x_boxed_100_; lean_object* v_res_101_; 
v_x_boxed_100_ = lean_unbox(v_x_99_);
v_res_101_ = lp_tree_GlobalTheory_GalCut_Level_ctorIdx(v_x_boxed_100_);
return v_res_101_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_toCtorIdx(uint8_t v_x_102_){
_start:
{
lean_object* v___x_103_; 
v___x_103_ = lp_tree_GlobalTheory_GalCut_Level_ctorIdx(v_x_102_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_toCtorIdx___boxed(lean_object* v_x_104_){
_start:
{
uint8_t v_x_4__boxed_105_; lean_object* v_res_106_; 
v_x_4__boxed_105_ = lean_unbox(v_x_104_);
v_res_106_ = lp_tree_GlobalTheory_GalCut_Level_toCtorIdx(v_x_4__boxed_105_);
return v_res_106_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___redArg(lean_object* v_k_107_){
_start:
{
lean_inc(v_k_107_);
return v_k_107_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___redArg___boxed(lean_object* v_k_108_){
_start:
{
lean_object* v_res_109_; 
v_res_109_ = lp_tree_GlobalTheory_GalCut_Level_ctorElim___redArg(v_k_108_);
lean_dec(v_k_108_);
return v_res_109_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim(lean_object* v_motive_110_, lean_object* v_ctorIdx_111_, uint8_t v_t_112_, lean_object* v_h_113_, lean_object* v_k_114_){
_start:
{
lean_inc(v_k_114_);
return v_k_114_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_ctorElim___boxed(lean_object* v_motive_115_, lean_object* v_ctorIdx_116_, lean_object* v_t_117_, lean_object* v_h_118_, lean_object* v_k_119_){
_start:
{
uint8_t v_t_boxed_120_; lean_object* v_res_121_; 
v_t_boxed_120_ = lean_unbox(v_t_117_);
v_res_121_ = lp_tree_GlobalTheory_GalCut_Level_ctorElim(v_motive_115_, v_ctorIdx_116_, v_t_boxed_120_, v_h_118_, v_k_119_);
lean_dec(v_k_119_);
lean_dec(v_ctorIdx_116_);
return v_res_121_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___redArg(lean_object* v_all_122_){
_start:
{
lean_inc(v_all_122_);
return v_all_122_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___redArg___boxed(lean_object* v_all_123_){
_start:
{
lean_object* v_res_124_; 
v_res_124_ = lp_tree_GlobalTheory_GalCut_Level_all_elim___redArg(v_all_123_);
lean_dec(v_all_123_);
return v_res_124_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim(lean_object* v_motive_125_, uint8_t v_t_126_, lean_object* v_h_127_, lean_object* v_all_128_){
_start:
{
lean_inc(v_all_128_);
return v_all_128_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_all_elim___boxed(lean_object* v_motive_129_, lean_object* v_t_130_, lean_object* v_h_131_, lean_object* v_all_132_){
_start:
{
uint8_t v_t_boxed_133_; lean_object* v_res_134_; 
v_t_boxed_133_ = lean_unbox(v_t_130_);
v_res_134_ = lp_tree_GlobalTheory_GalCut_Level_all_elim(v_motive_129_, v_t_boxed_133_, v_h_131_, v_all_132_);
lean_dec(v_all_132_);
return v_res_134_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___redArg(lean_object* v_good_135_){
_start:
{
lean_inc(v_good_135_);
return v_good_135_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___redArg___boxed(lean_object* v_good_136_){
_start:
{
lean_object* v_res_137_; 
v_res_137_ = lp_tree_GlobalTheory_GalCut_Level_good_elim___redArg(v_good_136_);
lean_dec(v_good_136_);
return v_res_137_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim(lean_object* v_motive_138_, uint8_t v_t_139_, lean_object* v_h_140_, lean_object* v_good_141_){
_start:
{
lean_inc(v_good_141_);
return v_good_141_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_good_elim___boxed(lean_object* v_motive_142_, lean_object* v_t_143_, lean_object* v_h_144_, lean_object* v_good_145_){
_start:
{
uint8_t v_t_boxed_146_; lean_object* v_res_147_; 
v_t_boxed_146_ = lean_unbox(v_t_143_);
v_res_147_ = lp_tree_GlobalTheory_GalCut_Level_good_elim(v_motive_142_, v_t_boxed_146_, v_h_144_, v_good_145_);
lean_dec(v_good_145_);
return v_res_147_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___redArg(lean_object* v_csd_148_){
_start:
{
lean_inc(v_csd_148_);
return v_csd_148_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___redArg___boxed(lean_object* v_csd_149_){
_start:
{
lean_object* v_res_150_; 
v_res_150_ = lp_tree_GlobalTheory_GalCut_Level_csd_elim___redArg(v_csd_149_);
lean_dec(v_csd_149_);
return v_res_150_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim(lean_object* v_motive_151_, uint8_t v_t_152_, lean_object* v_h_153_, lean_object* v_csd_154_){
_start:
{
lean_inc(v_csd_154_);
return v_csd_154_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_GalCut_Level_csd_elim___boxed(lean_object* v_motive_155_, lean_object* v_t_156_, lean_object* v_h_157_, lean_object* v_csd_158_){
_start:
{
uint8_t v_t_boxed_159_; lean_object* v_res_160_; 
v_t_boxed_159_ = lean_unbox(v_t_156_);
v_res_160_ = lp_tree_GlobalTheory_GalCut_Level_csd_elim(v_motive_155_, v_t_boxed_159_, v_h_157_, v_csd_158_);
lean_dec(v_csd_158_);
return v_res_160_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_GaloisRepOfPolarizedPair(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_BaseChangeDefiniteUnitary(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_AutomorphicForms_BlochKatoSelmerVanishes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_IsWeight(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_GaloisRepOfPolarizedPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_BaseChangeDefiniteUnitary(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_AutomorphicForms_BlochKatoSelmerVanishes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

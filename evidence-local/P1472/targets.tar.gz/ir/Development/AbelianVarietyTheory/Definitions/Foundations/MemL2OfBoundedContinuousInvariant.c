// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Foundations.MemL2OfBoundedContinuousInvariant
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Foundations.WittIndexEqZeroIff public import Development.AbelianVarietyTheory.Definitions.Foundations.ConstTermOnMulLeftOfNormalizer public import Development.AbelianVarietyTheory.Definitions.Foundations.IsIwasawaOfIsCompact public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsNormLeHeightPow public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.NotIsCuspFunOnePlane public import Development.AbelianVarietyTheory.Proofs.HeightProofs.AdelicUnitaryActionAtRealPlace public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.FiniteVolumeAdelicUnitaryQuotient public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.SmoothAutomorphicFormRightTranslateFiniteAdelic public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.IsSmoothAutomorphicFunctionTranslateAtRealPlace public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.FinrankOrth
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspCont(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspCont___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspContinuousL2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspContinuousL2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_blockAlg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_blockAlg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_autForms(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_autForms___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspForms(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspForms___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspCont(lean_object* v_D_1_, lean_object* v_V_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_box(0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspCont___boxed(lean_object* v_D_4_, lean_object* v_V_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_tree_GlobalTheory_Cusp_cuspCont(v_D_4_, v_V_5_);
lean_dec_ref(v_V_5_);
lean_dec_ref(v_D_4_);
return v_res_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspContinuousL2(lean_object* v_D_7_, lean_object* v_V_8_, lean_object* v_00_u03bc_9_, lean_object* v_inst_10_){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lean_box(0);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspContinuousL2___boxed(lean_object* v_D_12_, lean_object* v_V_13_, lean_object* v_00_u03bc_14_, lean_object* v_inst_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_Cusp_cuspContinuousL2(v_D_12_, v_V_13_, v_00_u03bc_14_, v_inst_15_);
lean_dec_ref(v_00_u03bc_14_);
lean_dec_ref(v_V_13_);
lean_dec_ref(v_D_12_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_blockAlg(lean_object* v_p_17_, lean_object* v_q_18_, lean_object* v_n_19_, lean_object* v_A_20_){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lean_box(0);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_blockAlg___boxed(lean_object* v_p_22_, lean_object* v_q_23_, lean_object* v_n_24_, lean_object* v_A_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GlobalTheory_Cusp_blockAlg(v_p_22_, v_q_23_, v_n_24_, v_A_25_);
lean_dec_ref(v_A_25_);
lean_dec(v_n_24_);
lean_dec(v_q_23_);
lean_dec(v_p_22_);
return v_res_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_autForms(lean_object* v_D_27_, lean_object* v_00_u03b8_28_, lean_object* v_V_29_, lean_object* v_K_30_){
_start:
{
lean_object* v___x_31_; 
v___x_31_ = lean_box(0);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_autForms___boxed(lean_object* v_D_32_, lean_object* v_00_u03b8_33_, lean_object* v_V_34_, lean_object* v_K_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_tree_GlobalTheory_Cusp_autForms(v_D_32_, v_00_u03b8_33_, v_V_34_, v_K_35_);
lean_dec_ref(v_V_34_);
lean_dec_ref(v_00_u03b8_33_);
lean_dec_ref(v_D_32_);
return v_res_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspForms(lean_object* v_D_37_, lean_object* v_00_u03b8_38_, lean_object* v_V_39_, lean_object* v_K_40_){
_start:
{
lean_object* v___x_41_; 
v___x_41_ = lean_box(0);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_Cusp_cuspForms___boxed(lean_object* v_D_42_, lean_object* v_00_u03b8_43_, lean_object* v_V_44_, lean_object* v_K_45_){
_start:
{
lean_object* v_res_46_; 
v_res_46_ = lp_tree_GlobalTheory_Cusp_cuspForms(v_D_42_, v_00_u03b8_43_, v_V_44_, v_K_45_);
lean_dec_ref(v_V_44_);
lean_dec_ref(v_00_u03b8_43_);
lean_dec_ref(v_D_42_);
return v_res_46_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_WittIndexEqZeroIff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_ConstTermOnMulLeftOfNormalizer(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_IsIwasawaOfIsCompact(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_NotIsCuspFunOnePlane(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_AdelicUnitaryActionAtRealPlace(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FiniteVolumeAdelicUnitaryQuotient(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_SmoothAutomorphicFormRightTranslateFiniteAdelic(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_IsSmoothAutomorphicFunctionTranslateAtRealPlace(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FinrankOrth(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_MemL2OfBoundedContinuousInvariant(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_WittIndexEqZeroIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_ConstTermOnMulLeftOfNormalizer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_IsIwasawaOfIsCompact(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_NotIsCuspFunOnePlane(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_AdelicUnitaryActionAtRealPlace(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FiniteVolumeAdelicUnitaryQuotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_SmoothAutomorphicFormRightTranslateFiniteAdelic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_IsSmoothAutomorphicFunctionTranslateAtRealPlace(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FinrankOrth(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

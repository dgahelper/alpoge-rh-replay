// Lean compiler output
// Module: Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.SeeSawFourier
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsQuasiFam public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsSumFrame
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_replicateCol___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofRow___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofRow(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ___redArg(lean_object* v_00_u03b6_1_, lean_object* v_a_2_, lean_object* v_a_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lp_mathlib_Matrix_replicateCol___redArg(v_00_u03b6_1_, v_a_2_, v_a_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ(lean_object* v_D_5_, lean_object* v_m_6_, lean_object* v_00_u03b6_7_, lean_object* v_a_8_, lean_object* v_a_9_){
_start:
{
lean_object* v___x_10_; 
v___x_10_ = lp_mathlib_Matrix_replicateCol___redArg(v_00_u03b6_7_, v_a_8_, v_a_9_);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ___boxed(lean_object* v_D_11_, lean_object* v_m_12_, lean_object* v_00_u03b6_13_, lean_object* v_a_14_, lean_object* v_a_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_colQ(v_D_11_, v_m_12_, v_00_u03b6_13_, v_a_14_, v_a_15_);
lean_dec(v_m_12_);
lean_dec_ref(v_D_11_);
return v_res_16_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; 
v___x_17_ = lean_unsigned_to_nat(1u);
v___x_18_ = lean_unsigned_to_nat(0u);
v___x_19_ = lean_nat_mod(v___x_18_, v___x_17_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0(lean_object* v_x_20_, lean_object* v_i_21_){
_start:
{
lean_object* v___x_22_; lean_object* v___x_23_; 
v___x_22_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0);
v___x_23_ = lean_apply_2(v_x_20_, v_i_21_, v___x_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg(lean_object* v_f_24_, lean_object* v_x_25_){
_start:
{
lean_object* v___f_26_; lean_object* v___x_27_; 
v___f_26_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0), 2, 1);
lean_closure_set(v___f_26_, 0, v_x_25_);
v___x_27_ = lean_apply_1(v_f_24_, v___f_26_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol(lean_object* v_k_28_, lean_object* v_n_29_, lean_object* v_f_30_, lean_object* v_x_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg(v_f_30_, v_x_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofRow___redArg(lean_object* v_g_33_, lean_object* v_x_34_){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; 
v___x_35_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofCol___redArg___lam__0___closed__0);
v___x_36_ = lean_apply_1(v_x_34_, v___x_35_);
v___x_37_ = lean_apply_1(v_g_33_, v___x_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofRow(lean_object* v_k_38_, lean_object* v_n_39_, lean_object* v_g_40_, lean_object* v_x_41_){
_start:
{
lean_object* v___x_42_; 
v___x_42_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_SeeSawLineFourier_ofRow___redArg(v_g_40_, v_x_41_);
return v___x_42_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsQuasiFam(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_SiegelEisenstein_SeeSawFourier(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsQuasiFam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

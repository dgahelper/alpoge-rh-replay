// Lean compiler output
// Module: Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.ModelFrames
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsSumFrame public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsQuasiFam public import Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSum
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_CommRing_toCommMonoid___redArg(lean_object*);
lean_object* l_List_range(lean_object*);
lean_object* lp_mathlib_Finset_prod___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_zero___aux__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_fromBlocks___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_Matrix_mulVec___at___00GlobalTheory_MixPer_vecB_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0(lean_object* v_p_1_, lean_object* v_toZero_2_, lean_object* v_u_3_, lean_object* v_l_4_, lean_object* v_s_5_){
_start:
{
lean_object* v___x_6_; lean_object* v___x_7_; uint8_t v___x_8_; 
v___x_6_ = lean_unsigned_to_nat(1u);
v___x_7_ = lean_nat_add(v_l_4_, v___x_6_);
v___x_8_ = lean_nat_dec_eq(v___x_7_, v_p_1_);
lean_dec(v___x_7_);
if (v___x_8_ == 0)
{
lean_dec(v_s_5_);
lean_dec(v_u_3_);
lean_inc(v_toZero_2_);
return v_toZero_2_;
}
else
{
lean_object* v___x_9_; 
v___x_9_ = lean_apply_1(v_u_3_, v_s_5_);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0___boxed(lean_object* v_p_10_, lean_object* v_toZero_11_, lean_object* v_u_12_, lean_object* v_l_13_, lean_object* v_s_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0(v_p_10_, v_toZero_11_, v_u_12_, v_l_13_, v_s_14_);
lean_dec(v_l_13_);
lean_dec(v_toZero_11_);
lean_dec(v_p_10_);
return v_res_15_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0(void){
_start:
{
lean_object* v___x_16_; 
v___x_16_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg(lean_object* v_inst_17_, lean_object* v_p_18_, lean_object* v_u_19_, lean_object* v_a_20_, lean_object* v_a_21_){
_start:
{
lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v_toSemiring_24_; lean_object* v___x_25_; lean_object* v_toZero_26_; lean_object* v___x_27_; lean_object* v_toFun_28_; lean_object* v___f_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_22_ = lp_mathlib_Field_toSemifield___redArg(v_inst_17_);
v___x_23_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_22_);
v_toSemiring_24_ = lean_ctor_get(v___x_23_, 0);
lean_inc_ref(v_toSemiring_24_);
lean_dec_ref(v___x_23_);
v___x_25_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_24_);
v_toZero_26_ = lean_ctor_get(v___x_25_, 1);
lean_inc_n(v_toZero_26_, 2);
lean_dec_ref(v___x_25_);
v___x_27_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___closed__0);
v_toFun_28_ = lean_ctor_get(v___x_27_, 0);
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___lam__0___boxed), 5, 3);
lean_closure_set(v___f_29_, 0, v_p_18_);
lean_closure_set(v___f_29_, 1, v_toZero_26_);
lean_closure_set(v___f_29_, 2, v_u_19_);
v___x_30_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_zero___aux__1___boxed), 6, 4);
lean_closure_set(v___x_30_, 0, lean_box(0));
lean_closure_set(v___x_30_, 1, lean_box(0));
lean_closure_set(v___x_30_, 2, lean_box(0));
lean_closure_set(v___x_30_, 3, v_toZero_26_);
lean_inc(v_toFun_28_);
v___x_31_ = lean_apply_1(v_toFun_28_, v___f_29_);
lean_inc_ref_n(v___x_30_, 2);
v___x_32_ = lp_mathlib_Matrix_fromBlocks___redArg(v___x_30_, v___x_30_, v___x_31_, v___x_30_, v_a_20_, v_a_21_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg___boxed(lean_object* v_inst_33_, lean_object* v_p_34_, lean_object* v_u_35_, lean_object* v_a_36_, lean_object* v_a_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg(v_inst_33_, v_p_34_, v_u_35_, v_a_36_, v_a_37_);
lean_dec_ref(v_inst_33_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat(lean_object* v_k_39_, lean_object* v_inst_40_, lean_object* v_n_41_, lean_object* v_n_x27_42_, lean_object* v_c_43_, lean_object* v_p_44_, lean_object* v_u_45_, lean_object* v_a_46_, lean_object* v_a_47_){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___redArg(v_inst_40_, v_p_44_, v_u_45_, v_a_46_, v_a_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat___boxed(lean_object* v_k_49_, lean_object* v_inst_50_, lean_object* v_n_51_, lean_object* v_n_x27_52_, lean_object* v_c_53_, lean_object* v_p_54_, lean_object* v_u_55_, lean_object* v_a_56_, lean_object* v_a_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_rowMat(v_k_49_, v_inst_50_, v_n_51_, v_n_x27_52_, v_c_53_, v_p_54_, v_u_55_, v_a_56_, v_a_57_);
lean_dec(v_c_53_);
lean_dec_ref(v_inst_50_);
return v_res_58_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg___lam__0(lean_object* v_00_u03b3_59_, lean_object* v_00_u03ba_60_, lean_object* v_toMul_61_, lean_object* v_j_62_){
_start:
{
lean_object* v_inv_63_; lean_object* v___x_64_; lean_object* v___x_65_; 
v_inv_63_ = lean_ctor_get(v_00_u03b3_59_, 1);
lean_inc(v_inv_63_);
lean_dec_ref(v_00_u03b3_59_);
v___x_64_ = lean_apply_1(v_00_u03ba_60_, v_j_62_);
v___x_65_ = lean_apply_2(v_toMul_61_, v___x_64_, v_inv_63_);
return v___x_65_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg(lean_object* v_inst_66_, lean_object* v_00_u03b3_67_, lean_object* v_00_u03ba_68_, lean_object* v_t_u2081_69_, lean_object* v_i_70_){
_start:
{
lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v_toSemiring_73_; lean_object* v___x_74_; lean_object* v_toMul_75_; lean_object* v_val_76_; lean_object* v_toCommRing_77_; lean_object* v___f_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; 
v___x_71_ = lp_mathlib_Field_toSemifield___redArg(v_inst_66_);
v___x_72_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_71_);
v_toSemiring_73_ = lean_ctor_get(v___x_72_, 0);
lean_inc_ref(v_toSemiring_73_);
lean_dec_ref(v___x_72_);
v___x_74_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_73_);
v_toMul_75_ = lean_ctor_get(v___x_74_, 0);
lean_inc_n(v_toMul_75_, 2);
lean_dec_ref(v___x_74_);
v_val_76_ = lean_ctor_get(v_t_u2081_69_, 0);
lean_inc(v_val_76_);
lean_dec_ref(v_t_u2081_69_);
v_toCommRing_77_ = lean_ctor_get(v_inst_66_, 0);
v___f_78_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg___lam__0), 4, 3);
lean_closure_set(v___f_78_, 0, v_00_u03b3_67_);
lean_closure_set(v___f_78_, 1, v_00_u03ba_68_);
lean_closure_set(v___f_78_, 2, v_toMul_75_);
v___x_79_ = lp_mathlib_CommRing_toCommMonoid___redArg(v_toCommRing_77_);
v___x_80_ = l_List_range(v_i_70_);
v___x_81_ = lp_mathlib_Finset_prod___redArg(v___x_79_, v___x_80_, v___f_78_);
lean_dec_ref(v___x_79_);
v___x_82_ = lean_apply_2(v_toMul_75_, v_val_76_, v___x_81_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg___boxed(lean_object* v_inst_83_, lean_object* v_00_u03b3_84_, lean_object* v_00_u03ba_85_, lean_object* v_t_u2081_86_, lean_object* v_i_87_){
_start:
{
lean_object* v_res_88_; 
v_res_88_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg(v_inst_83_, v_00_u03b3_84_, v_00_u03ba_85_, v_t_u2081_86_, v_i_87_);
lean_dec_ref(v_inst_83_);
return v_res_88_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal(lean_object* v_k_89_, lean_object* v_inst_90_, lean_object* v_00_u03b3_91_, lean_object* v_00_u03ba_92_, lean_object* v_t_u2081_93_, lean_object* v_i_94_){
_start:
{
lean_object* v___x_95_; 
v___x_95_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___redArg(v_inst_90_, v_00_u03b3_91_, v_00_u03ba_92_, v_t_u2081_93_, v_i_94_);
return v___x_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal___boxed(lean_object* v_k_96_, lean_object* v_inst_97_, lean_object* v_00_u03b3_98_, lean_object* v_00_u03ba_99_, lean_object* v_t_u2081_100_, lean_object* v_i_101_){
_start:
{
lean_object* v_res_102_; 
v_res_102_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_scal(v_k_96_, v_inst_97_, v_00_u03b3_98_, v_00_u03ba_99_, v_t_u2081_100_, v_i_101_);
lean_dec_ref(v_inst_97_);
return v_res_102_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg(lean_object* v_inst_103_, lean_object* v_00_u03c3_104_, lean_object* v_a_105_, lean_object* v_i_106_){
_start:
{
uint8_t v___x_107_; 
v___x_107_ = lean_nat_dec_lt(v_i_106_, v_00_u03c3_104_);
if (v___x_107_ == 0)
{
uint8_t v___x_108_; 
v___x_108_ = lean_nat_dec_eq(v_i_106_, v_00_u03c3_104_);
if (v___x_108_ == 0)
{
lean_object* v___x_109_; lean_object* v_toRing_110_; lean_object* v___x_111_; lean_object* v___x_112_; lean_object* v_toNeg_113_; lean_object* v___x_114_; lean_object* v_toAddMonoidWithOne_115_; lean_object* v_toOne_116_; lean_object* v___x_117_; 
v___x_109_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_103_);
v_toRing_110_ = lean_ctor_get(v___x_109_, 0);
lean_inc_ref(v_toRing_110_);
lean_dec_ref(v___x_109_);
v___x_111_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_110_);
v___x_112_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_111_);
lean_dec_ref(v___x_111_);
v_toNeg_113_ = lean_ctor_get(v___x_112_, 1);
lean_inc(v_toNeg_113_);
lean_dec_ref(v___x_112_);
v___x_114_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_110_);
v_toAddMonoidWithOne_115_ = lean_ctor_get(v___x_114_, 1);
lean_inc_ref(v_toAddMonoidWithOne_115_);
lean_dec_ref(v___x_114_);
v_toOne_116_ = lean_ctor_get(v_toAddMonoidWithOne_115_, 2);
lean_inc(v_toOne_116_);
lean_dec_ref(v_toAddMonoidWithOne_115_);
v___x_117_ = lean_apply_1(v_toNeg_113_, v_toOne_116_);
return v___x_117_;
}
else
{
lean_dec_ref(v_inst_103_);
lean_inc(v_a_105_);
return v_a_105_;
}
}
else
{
lean_object* v___x_118_; lean_object* v_toRing_119_; lean_object* v___x_120_; lean_object* v_toAddMonoidWithOne_121_; lean_object* v_toOne_122_; 
v___x_118_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_103_);
v_toRing_119_ = lean_ctor_get(v___x_118_, 0);
lean_inc_ref(v_toRing_119_);
lean_dec_ref(v___x_118_);
v___x_120_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_119_);
v_toAddMonoidWithOne_121_ = lean_ctor_get(v___x_120_, 1);
lean_inc_ref(v_toAddMonoidWithOne_121_);
lean_dec_ref(v___x_120_);
v_toOne_122_ = lean_ctor_get(v_toAddMonoidWithOne_121_, 2);
lean_inc(v_toOne_122_);
lean_dec_ref(v_toAddMonoidWithOne_121_);
return v_toOne_122_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg___boxed(lean_object* v_inst_123_, lean_object* v_00_u03c3_124_, lean_object* v_a_125_, lean_object* v_i_126_){
_start:
{
lean_object* v_res_127_; 
v_res_127_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg(v_inst_123_, v_00_u03c3_124_, v_a_125_, v_i_126_);
lean_dec(v_i_126_);
lean_dec(v_a_125_);
lean_dec(v_00_u03c3_124_);
return v_res_127_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef(lean_object* v_k_128_, lean_object* v_inst_129_, lean_object* v_00_u03c3_130_, lean_object* v_a_131_, lean_object* v_i_132_){
_start:
{
lean_object* v___x_133_; 
v___x_133_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___redArg(v_inst_129_, v_00_u03c3_130_, v_a_131_, v_i_132_);
return v___x_133_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef___boxed(lean_object* v_k_134_, lean_object* v_inst_135_, lean_object* v_00_u03c3_136_, lean_object* v_a_137_, lean_object* v_i_138_){
_start:
{
lean_object* v_res_139_; 
v_res_139_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_coef(v_k_134_, v_inst_135_, v_00_u03c3_136_, v_a_137_, v_i_138_);
lean_dec(v_i_138_);
lean_dec(v_a_137_);
lean_dec(v_00_u03c3_136_);
return v_res_139_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg(lean_object* v_00_u03c3_140_, lean_object* v_d_141_, lean_object* v_i_142_, lean_object* v_r_143_){
_start:
{
lean_object* v___x_144_; lean_object* v___x_145_; uint8_t v___x_146_; 
v___x_144_ = lean_unsigned_to_nat(1u);
v___x_145_ = lean_nat_add(v_00_u03c3_140_, v___x_144_);
v___x_146_ = lean_nat_dec_lt(v_i_142_, v___x_145_);
lean_dec(v___x_145_);
if (v___x_146_ == 0)
{
lean_object* v_e_x27_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; 
v_e_x27_147_ = lean_ctor_get(v_d_141_, 1);
lean_inc(v_e_x27_147_);
lean_dec_ref(v_d_141_);
v___x_148_ = lean_unsigned_to_nat(2u);
v___x_149_ = lean_nat_mul(v___x_148_, v_00_u03c3_140_);
v___x_150_ = lean_nat_add(v___x_149_, v___x_144_);
lean_dec(v___x_149_);
v___x_151_ = lean_nat_sub(v___x_150_, v_i_142_);
lean_dec(v_i_142_);
lean_dec(v___x_150_);
v___x_152_ = lean_apply_2(v_e_x27_147_, v_r_143_, v___x_151_);
return v___x_152_;
}
else
{
lean_object* v_e_153_; lean_object* v___x_154_; 
v_e_153_ = lean_ctor_get(v_d_141_, 0);
lean_inc(v_e_153_);
lean_dec_ref(v_d_141_);
v___x_154_ = lean_apply_2(v_e_153_, v_r_143_, v_i_142_);
return v___x_154_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg___boxed(lean_object* v_00_u03c3_155_, lean_object* v_d_156_, lean_object* v_i_157_, lean_object* v_r_158_){
_start:
{
lean_object* v_res_159_; 
v_res_159_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg(v_00_u03c3_155_, v_d_156_, v_i_157_, v_r_158_);
lean_dec(v_00_u03c3_155_);
return v_res_159_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition(lean_object* v_D_160_, lean_object* v_S_161_, lean_object* v_S_u2080_162_, lean_object* v_00_u03c3_163_, lean_object* v_d_164_, lean_object* v_i_165_, lean_object* v_r_166_){
_start:
{
lean_object* v___x_167_; 
v___x_167_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___redArg(v_00_u03c3_163_, v_d_164_, v_i_165_, v_r_166_);
return v___x_167_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition___boxed(lean_object* v_D_168_, lean_object* v_S_169_, lean_object* v_S_u2080_170_, lean_object* v_00_u03c3_171_, lean_object* v_d_172_, lean_object* v_i_173_, lean_object* v_r_174_){
_start:
{
lean_object* v_res_175_; 
v_res_175_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_jacobiWittDecomposition(v_D_168_, v_S_169_, v_S_u2080_170_, v_00_u03c3_171_, v_d_172_, v_i_173_, v_r_174_);
lean_dec(v_00_u03c3_171_);
lean_dec_ref(v_S_u2080_170_);
lean_dec_ref(v_S_169_);
lean_dec_ref(v_D_168_);
return v_res_175_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg(lean_object* v_D_176_, lean_object* v_S_u2080_177_, lean_object* v_00_u03c3_178_, lean_object* v_d_179_, lean_object* v_z_180_, lean_object* v_i_181_, lean_object* v_r_182_){
_start:
{
uint8_t v___x_183_; 
v___x_183_ = lean_nat_dec_lt(v_i_181_, v_00_u03c3_178_);
if (v___x_183_ == 0)
{
uint8_t v___x_184_; 
v___x_184_ = lean_nat_dec_eq(v_i_181_, v_00_u03c3_178_);
if (v___x_184_ == 0)
{
lean_object* v_e_x27_185_; lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; lean_object* v___x_189_; 
lean_dec(v_z_180_);
lean_dec_ref(v_S_u2080_177_);
v_e_x27_185_ = lean_ctor_get(v_d_179_, 1);
lean_inc(v_e_x27_185_);
lean_dec_ref(v_d_179_);
v___x_186_ = lean_unsigned_to_nat(2u);
v___x_187_ = lean_nat_mul(v___x_186_, v_00_u03c3_178_);
v___x_188_ = lean_nat_sub(v___x_187_, v_i_181_);
lean_dec(v_i_181_);
lean_dec(v___x_187_);
v___x_189_ = lean_apply_2(v_e_x27_185_, v_r_182_, v___x_188_);
return v___x_189_;
}
else
{
lean_object* v_host_190_; lean_object* v_toHostAx_191_; lean_object* v_rank_192_; lean_object* v_i_u2080_193_; lean_object* v___x_194_; 
lean_dec(v_i_181_);
v_host_190_ = lean_ctor_get(v_D_176_, 1);
v_toHostAx_191_ = lean_ctor_get(v_host_190_, 0);
v_rank_192_ = lean_ctor_get(v_S_u2080_177_, 4);
lean_inc(v_rank_192_);
lean_dec_ref(v_S_u2080_177_);
v_i_u2080_193_ = lean_ctor_get(v_d_179_, 2);
lean_inc(v_i_u2080_193_);
lean_dec_ref(v_d_179_);
v___x_194_ = lp_tree_Matrix_mulVec___at___00GlobalTheory_MixPer_vecB_spec__0___redArg(v_toHostAx_191_, v_rank_192_, v_i_u2080_193_, v_z_180_, v_r_182_);
return v___x_194_;
}
}
else
{
lean_object* v_e_195_; lean_object* v___x_196_; 
lean_dec(v_z_180_);
lean_dec_ref(v_S_u2080_177_);
v_e_195_ = lean_ctor_get(v_d_179_, 0);
lean_inc(v_e_195_);
lean_dec_ref(v_d_179_);
v___x_196_ = lean_apply_2(v_e_195_, v_r_182_, v_i_181_);
return v___x_196_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg___boxed(lean_object* v_D_197_, lean_object* v_S_u2080_198_, lean_object* v_00_u03c3_199_, lean_object* v_d_200_, lean_object* v_z_201_, lean_object* v_i_202_, lean_object* v_r_203_){
_start:
{
lean_object* v_res_204_; 
v_res_204_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg(v_D_197_, v_S_u2080_198_, v_00_u03c3_199_, v_d_200_, v_z_201_, v_i_202_, v_r_203_);
lean_dec(v_00_u03c3_199_);
lean_dec_ref(v_D_197_);
return v_res_204_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition(lean_object* v_D_205_, lean_object* v_S_206_, lean_object* v_S_u2080_207_, lean_object* v_00_u03c3_208_, lean_object* v_d_209_, lean_object* v_z_210_, lean_object* v_i_211_, lean_object* v_r_212_){
_start:
{
lean_object* v___x_213_; 
v___x_213_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___redArg(v_D_205_, v_S_u2080_207_, v_00_u03c3_208_, v_d_209_, v_z_210_, v_i_211_, v_r_212_);
return v___x_213_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition___boxed(lean_object* v_D_214_, lean_object* v_S_215_, lean_object* v_S_u2080_216_, lean_object* v_00_u03c3_217_, lean_object* v_d_218_, lean_object* v_z_219_, lean_object* v_i_220_, lean_object* v_r_221_){
_start:
{
lean_object* v_res_222_; 
v_res_222_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ModelFrames_besselWittDecomposition(v_D_214_, v_S_215_, v_S_u2080_216_, v_00_u03c3_217_, v_d_218_, v_z_219_, v_i_220_, v_r_221_);
lean_dec(v_00_u03c3_217_);
lean_dec_ref(v_S_215_);
lean_dec_ref(v_D_214_);
return v_res_222_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsQuasiFam(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_SimpleSum(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_SiegelEisenstein_ModelFrames(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsQuasiFam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_SimpleSum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.WeightedNormColumns
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.IsSumFrame public import Development.AbelianVarietyTheory.Definitions.Foundations.SimpleSum
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_zero___aux__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_fromBlocks___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg(lean_object* v_inst_1_, lean_object* v_00_u03c1_2_, lean_object* v_N_3_, lean_object* v_i_4_){
_start:
{
uint8_t v___x_5_; 
v___x_5_ = lean_nat_dec_lt(v_i_4_, v_00_u03c1_2_);
if (v___x_5_ == 0)
{
uint8_t v___x_6_; 
v___x_6_ = lean_nat_dec_eq(v_i_4_, v_00_u03c1_2_);
if (v___x_6_ == 0)
{
lean_object* v___x_7_; lean_object* v_toRing_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v_toNeg_11_; lean_object* v___x_12_; lean_object* v_toAddMonoidWithOne_13_; lean_object* v_toOne_14_; lean_object* v___x_15_; 
lean_dec(v_N_3_);
v___x_7_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_8_ = lean_ctor_get(v___x_7_, 0);
lean_inc_ref(v_toRing_8_);
lean_dec_ref(v___x_7_);
v___x_9_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_8_);
v___x_10_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_9_);
lean_dec_ref(v___x_9_);
v_toNeg_11_ = lean_ctor_get(v___x_10_, 1);
lean_inc(v_toNeg_11_);
lean_dec_ref(v___x_10_);
v___x_12_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_8_);
v_toAddMonoidWithOne_13_ = lean_ctor_get(v___x_12_, 1);
lean_inc_ref(v_toAddMonoidWithOne_13_);
lean_dec_ref(v___x_12_);
v_toOne_14_ = lean_ctor_get(v_toAddMonoidWithOne_13_, 2);
lean_inc(v_toOne_14_);
lean_dec_ref(v_toAddMonoidWithOne_13_);
v___x_15_ = lean_apply_1(v_toNeg_11_, v_toOne_14_);
return v___x_15_;
}
else
{
lean_object* v___x_16_; lean_object* v_toRing_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v_toNeg_20_; lean_object* v___x_21_; 
v___x_16_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_17_ = lean_ctor_get(v___x_16_, 0);
lean_inc_ref(v_toRing_17_);
lean_dec_ref(v___x_16_);
v___x_18_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_17_);
lean_dec_ref(v_toRing_17_);
v___x_19_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_18_);
lean_dec_ref(v___x_18_);
v_toNeg_20_ = lean_ctor_get(v___x_19_, 1);
lean_inc(v_toNeg_20_);
lean_dec_ref(v___x_19_);
v___x_21_ = lean_apply_1(v_toNeg_20_, v_N_3_);
return v___x_21_;
}
}
else
{
lean_object* v___x_22_; lean_object* v_toRing_23_; lean_object* v___x_24_; lean_object* v_toAddMonoidWithOne_25_; lean_object* v_toOne_26_; 
lean_dec(v_N_3_);
v___x_22_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_23_ = lean_ctor_get(v___x_22_, 0);
lean_inc_ref(v_toRing_23_);
lean_dec_ref(v___x_22_);
v___x_24_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_23_);
v_toAddMonoidWithOne_25_ = lean_ctor_get(v___x_24_, 1);
lean_inc_ref(v_toAddMonoidWithOne_25_);
lean_dec_ref(v___x_24_);
v_toOne_26_ = lean_ctor_get(v_toAddMonoidWithOne_25_, 2);
lean_inc(v_toOne_26_);
lean_dec_ref(v_toAddMonoidWithOne_25_);
return v_toOne_26_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg___boxed(lean_object* v_inst_27_, lean_object* v_00_u03c1_28_, lean_object* v_N_29_, lean_object* v_i_30_){
_start:
{
lean_object* v_res_31_; 
v_res_31_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg(v_inst_27_, v_00_u03c1_28_, v_N_29_, v_i_30_);
lean_dec(v_i_30_);
lean_dec(v_00_u03c1_28_);
return v_res_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc(lean_object* v_k_32_, lean_object* v_inst_33_, lean_object* v_00_u03c1_34_, lean_object* v_N_35_, lean_object* v_i_36_){
_start:
{
lean_object* v___x_37_; 
v___x_37_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___redArg(v_inst_33_, v_00_u03c1_34_, v_N_35_, v_i_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc___boxed(lean_object* v_k_38_, lean_object* v_inst_39_, lean_object* v_00_u03c1_40_, lean_object* v_N_41_, lean_object* v_i_42_){
_start:
{
lean_object* v_res_43_; 
v_res_43_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaSrc(v_k_38_, v_inst_39_, v_00_u03c1_40_, v_N_41_, v_i_42_);
lean_dec(v_i_42_);
lean_dec(v_00_u03c1_40_);
return v_res_43_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg(lean_object* v_inst_44_, lean_object* v_00_u03c1_45_, lean_object* v_cst_46_, lean_object* v_i_47_){
_start:
{
lean_object* v___x_48_; lean_object* v___x_49_; uint8_t v___x_50_; 
v___x_48_ = lean_unsigned_to_nat(1u);
v___x_49_ = lean_nat_add(v_i_47_, v___x_48_);
v___x_50_ = lean_nat_dec_lt(v___x_49_, v_00_u03c1_45_);
if (v___x_50_ == 0)
{
uint8_t v___x_51_; 
v___x_51_ = lean_nat_dec_eq(v___x_49_, v_00_u03c1_45_);
lean_dec(v___x_49_);
if (v___x_51_ == 0)
{
lean_object* v___x_52_; lean_object* v_toRing_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v_toNeg_56_; lean_object* v___x_57_; lean_object* v_toAddMonoidWithOne_58_; lean_object* v_toOne_59_; lean_object* v___x_60_; 
v___x_52_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_44_);
v_toRing_53_ = lean_ctor_get(v___x_52_, 0);
lean_inc_ref(v_toRing_53_);
lean_dec_ref(v___x_52_);
v___x_54_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_toRing_53_);
v___x_55_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_54_);
lean_dec_ref(v___x_54_);
v_toNeg_56_ = lean_ctor_get(v___x_55_, 1);
lean_inc(v_toNeg_56_);
lean_dec_ref(v___x_55_);
v___x_57_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_53_);
v_toAddMonoidWithOne_58_ = lean_ctor_get(v___x_57_, 1);
lean_inc_ref(v_toAddMonoidWithOne_58_);
lean_dec_ref(v___x_57_);
v_toOne_59_ = lean_ctor_get(v_toAddMonoidWithOne_58_, 2);
lean_inc(v_toOne_59_);
lean_dec_ref(v_toAddMonoidWithOne_58_);
v___x_60_ = lean_apply_1(v_toNeg_56_, v_toOne_59_);
return v___x_60_;
}
else
{
lean_dec_ref(v_inst_44_);
lean_inc(v_cst_46_);
return v_cst_46_;
}
}
else
{
lean_object* v___x_61_; lean_object* v_toRing_62_; lean_object* v___x_63_; lean_object* v_toAddMonoidWithOne_64_; lean_object* v_toOne_65_; 
lean_dec(v___x_49_);
v___x_61_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_44_);
v_toRing_62_ = lean_ctor_get(v___x_61_, 0);
lean_inc_ref(v_toRing_62_);
lean_dec_ref(v___x_61_);
v___x_63_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_62_);
v_toAddMonoidWithOne_64_ = lean_ctor_get(v___x_63_, 1);
lean_inc_ref(v_toAddMonoidWithOne_64_);
lean_dec_ref(v___x_63_);
v_toOne_65_ = lean_ctor_get(v_toAddMonoidWithOne_64_, 2);
lean_inc(v_toOne_65_);
lean_dec_ref(v_toAddMonoidWithOne_64_);
return v_toOne_65_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg___boxed(lean_object* v_inst_66_, lean_object* v_00_u03c1_67_, lean_object* v_cst_68_, lean_object* v_i_69_){
_start:
{
lean_object* v_res_70_; 
v_res_70_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg(v_inst_66_, v_00_u03c1_67_, v_cst_68_, v_i_69_);
lean_dec(v_i_69_);
lean_dec(v_cst_68_);
lean_dec(v_00_u03c1_67_);
return v_res_70_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt(lean_object* v_k_71_, lean_object* v_inst_72_, lean_object* v_00_u03c1_73_, lean_object* v_cst_74_, lean_object* v_i_75_){
_start:
{
lean_object* v___x_76_; 
v___x_76_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___redArg(v_inst_72_, v_00_u03c1_73_, v_cst_74_, v_i_75_);
return v___x_76_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt___boxed(lean_object* v_k_77_, lean_object* v_inst_78_, lean_object* v_00_u03c1_79_, lean_object* v_cst_80_, lean_object* v_i_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_kaTgt(v_k_77_, v_inst_78_, v_00_u03c1_79_, v_cst_80_, v_i_81_);
lean_dec(v_i_81_);
lean_dec(v_cst_80_);
lean_dec(v_00_u03c1_79_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0(lean_object* v_00_u03c1_83_, lean_object* v_toZero_84_, lean_object* v_b_85_, lean_object* v_r_86_, lean_object* v_i_87_){
_start:
{
uint8_t v___x_88_; 
v___x_88_ = lean_nat_dec_eq(v_i_87_, v_00_u03c1_83_);
if (v___x_88_ == 0)
{
lean_dec(v_r_86_);
lean_dec(v_b_85_);
lean_inc(v_toZero_84_);
return v_toZero_84_;
}
else
{
lean_object* v___x_89_; 
v___x_89_ = lean_apply_1(v_b_85_, v_r_86_);
return v___x_89_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0___boxed(lean_object* v_00_u03c1_90_, lean_object* v_toZero_91_, lean_object* v_b_92_, lean_object* v_r_93_, lean_object* v_i_94_){
_start:
{
lean_object* v_res_95_; 
v_res_95_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0(v_00_u03c1_90_, v_toZero_91_, v_b_92_, v_r_93_, v_i_94_);
lean_dec(v_i_94_);
lean_dec(v_toZero_91_);
lean_dec(v_00_u03c1_90_);
return v_res_95_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0(void){
_start:
{
lean_object* v___x_96_; 
v___x_96_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_96_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg(lean_object* v_inst_97_, lean_object* v_00_u03c1_98_, lean_object* v_b_99_, lean_object* v_a_100_, lean_object* v_a_101_){
_start:
{
lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v_toSemiring_104_; lean_object* v___x_105_; lean_object* v_toZero_106_; lean_object* v___x_107_; lean_object* v_toFun_108_; lean_object* v___f_109_; lean_object* v___x_110_; lean_object* v___x_111_; lean_object* v___x_112_; 
v___x_102_ = lp_mathlib_Field_toSemifield___redArg(v_inst_97_);
v___x_103_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_102_);
v_toSemiring_104_ = lean_ctor_get(v___x_103_, 0);
lean_inc_ref(v_toSemiring_104_);
lean_dec_ref(v___x_103_);
v___x_105_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_104_);
v_toZero_106_ = lean_ctor_get(v___x_105_, 1);
lean_inc_n(v_toZero_106_, 2);
lean_dec_ref(v___x_105_);
v___x_107_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___closed__0);
v_toFun_108_ = lean_ctor_get(v___x_107_, 0);
v___f_109_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___lam__0___boxed), 5, 3);
lean_closure_set(v___f_109_, 0, v_00_u03c1_98_);
lean_closure_set(v___f_109_, 1, v_toZero_106_);
lean_closure_set(v___f_109_, 2, v_b_99_);
v___x_110_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_zero___aux__1___boxed), 6, 4);
lean_closure_set(v___x_110_, 0, lean_box(0));
lean_closure_set(v___x_110_, 1, lean_box(0));
lean_closure_set(v___x_110_, 2, lean_box(0));
lean_closure_set(v___x_110_, 3, v_toZero_106_);
lean_inc(v_toFun_108_);
v___x_111_ = lean_apply_1(v_toFun_108_, v___f_109_);
lean_inc_ref_n(v___x_110_, 2);
v___x_112_ = lp_mathlib_Matrix_fromBlocks___redArg(v___x_110_, v___x_111_, v___x_110_, v___x_110_, v_a_100_, v_a_101_);
return v___x_112_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg___boxed(lean_object* v_inst_113_, lean_object* v_00_u03c1_114_, lean_object* v_b_115_, lean_object* v_a_116_, lean_object* v_a_117_){
_start:
{
lean_object* v_res_118_; 
v_res_118_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg(v_inst_113_, v_00_u03c1_114_, v_b_115_, v_a_116_, v_a_117_);
lean_dec_ref(v_inst_113_);
return v_res_118_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol(lean_object* v_k_119_, lean_object* v_inst_120_, lean_object* v_n_121_, lean_object* v_n_x27_122_, lean_object* v_00_u03c1_123_, lean_object* v_b_124_, lean_object* v_a_125_, lean_object* v_a_126_){
_start:
{
lean_object* v___x_127_; 
v___x_127_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___redArg(v_inst_120_, v_00_u03c1_123_, v_b_124_, v_a_125_, v_a_126_);
return v___x_127_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol___boxed(lean_object* v_k_128_, lean_object* v_inst_129_, lean_object* v_n_130_, lean_object* v_n_x27_131_, lean_object* v_00_u03c1_132_, lean_object* v_b_133_, lean_object* v_a_134_, lean_object* v_a_135_){
_start:
{
lean_object* v_res_136_; 
v_res_136_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_WeightedNormColumns_zCol(v_k_128_, v_inst_129_, v_n_130_, v_n_x27_131_, v_00_u03c1_132_, v_b_133_, v_a_134_, v_a_135_);
lean_dec_ref(v_inst_129_);
return v_res_136_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_SimpleSum(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_SiegelEisenstein_WeightedNormColumns(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_IsSumFrame(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Foundations_SimpleSum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

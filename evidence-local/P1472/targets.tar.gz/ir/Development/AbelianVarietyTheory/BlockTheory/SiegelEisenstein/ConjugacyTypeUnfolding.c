// Lean compiler output
// Module: Development.AbelianVarietyTheory.BlockTheory.SiegelEisenstein.ConjugacyTypeUnfolding
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.SiegelLatticeTheory.HaarTransversals.PoincareInHH public import Formalism.LocalToGlobal.SiegelLatticeTheory.FlagStabilizerTensors.RowsJoinPinned public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.WittSmallGroupEmbeddingMemPointwiseStabilizerIso
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_DivisionRing_toDivInvMonoid___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lp_tree_Nat_cast___at___00Formalism_L2_Pj_w0E_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0;
static lean_once_cell_t lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV___redArg(lean_object* v_x_1_, lean_object* v_a_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_apply_1(v_x_1_, v_a_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV(lean_object* v_I_4_, lean_object* v_I_x27_5_, lean_object* v_h_6_, lean_object* v_x_7_, lean_object* v_a_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lean_apply_1(v_x_7_, v_a_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV___boxed(lean_object* v_I_10_, lean_object* v_I_x27_11_, lean_object* v_h_12_, lean_object* v_x_13_, lean_object* v_a_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_castV(v_I_10_, v_I_x27_11_, v_h_12_, v_x_13_, v_a_14_);
lean_dec_ref(v_I_x27_11_);
lean_dec_ref(v_I_10_);
return v_res_15_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0(void){
_start:
{
lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; 
v___x_16_ = lean_unsigned_to_nat(2u);
v___x_17_ = lean_unsigned_to_nat(0u);
v___x_18_ = lean_nat_mod(v___x_17_, v___x_16_);
return v___x_18_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1(void){
_start:
{
lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; 
v___x_19_ = lean_unsigned_to_nat(2u);
v___x_20_ = lean_unsigned_to_nat(1u);
v___x_21_ = lean_nat_mod(v___x_20_, v___x_19_);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS(lean_object* v_D_22_){
_start:
{
lean_object* v_host_23_; lean_object* v_toHostAx_24_; lean_object* v_g_25_; lean_object* v_instField_26_; lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v_toDiv_29_; lean_object* v_toRing_30_; lean_object* v___x_31_; lean_object* v_toAddMonoidWithOne_32_; lean_object* v_toOne_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; 
v_host_23_ = lean_ctor_get(v_D_22_, 1);
lean_inc_ref(v_host_23_);
lean_dec_ref(v_D_22_);
v_toHostAx_24_ = lean_ctor_get(v_host_23_, 0);
lean_inc_ref(v_toHostAx_24_);
v_g_25_ = lean_ctor_get(v_host_23_, 6);
lean_inc_ref_n(v_g_25_, 2);
lean_dec_ref(v_host_23_);
v_instField_26_ = lean_ctor_get(v_toHostAx_24_, 3);
lean_inc_ref(v_instField_26_);
v___x_27_ = lp_mathlib_Field_toDivisionRing___redArg(v_instField_26_);
v___x_28_ = lp_mathlib_DivisionRing_toDivInvMonoid___redArg(v___x_27_);
v_toDiv_29_ = lean_ctor_get(v___x_28_, 2);
lean_inc(v_toDiv_29_);
lean_dec_ref(v___x_28_);
v_toRing_30_ = lean_ctor_get(v___x_27_, 0);
lean_inc_ref(v_toRing_30_);
lean_dec_ref(v___x_27_);
v___x_31_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_30_);
v_toAddMonoidWithOne_32_ = lean_ctor_get(v___x_31_, 1);
lean_inc_ref(v_toAddMonoidWithOne_32_);
lean_dec_ref(v___x_31_);
v_toOne_33_ = lean_ctor_get(v_toAddMonoidWithOne_32_, 2);
lean_inc(v_toOne_33_);
lean_dec_ref(v_toAddMonoidWithOne_32_);
v___x_34_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__0);
v___x_35_ = lean_apply_1(v_g_25_, v___x_34_);
v___x_36_ = lean_obj_once(&lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1, &lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1_once, _init_lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_ConjugacyTypeUnfolding_thetaS___closed__1);
v___x_37_ = lean_apply_1(v_g_25_, v___x_36_);
v___x_38_ = lean_nat_mul(v___x_35_, v___x_37_);
lean_dec(v___x_37_);
lean_dec(v___x_35_);
v___x_39_ = lp_tree_Nat_cast___at___00Formalism_L2_Pj_w0E_spec__0(v_toHostAx_24_, v___x_38_);
v___x_40_ = lean_apply_2(v_toDiv_29_, v_toOne_33_, v___x_39_);
return v___x_40_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_HaarTransversals_PoincareInHH(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_FlagStabilizerTensors_RowsJoinPinned(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_WittSmallGroupEmbeddingMemPointwiseStabilizerIso(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_SiegelEisenstein_ConjugacyTypeUnfolding(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_HaarTransversals_PoincareInHH(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_SiegelLatticeTheory_FlagStabilizerTensors_RowsJoinPinned(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_WittSmallGroupEmbeddingMemPointwiseStabilizerIso(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

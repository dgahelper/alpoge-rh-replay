// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.DownwardThetaIntegralSobolevContinuous
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.LengthPosOfPosDef public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.AdjFormula public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ParamsEx public import Formalism.LocalToGlobal.IndefiniteReal.LinksStage public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsNormLeHeightPow public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisGeometry₂.HoweUnram public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.GaussianBinomialClosedForm public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.SqNormIntegralFundamentalDomainEqL2NormSq public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.ThetaKernelIteratedIntegralsSwap public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ThetaGrowthOfThetaSquareIntegrable public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.DefiniteUnitaryCocompact public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsRepsOfOpenCompact public import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.SmulEqZeroOfInf public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.OmPureTensorOOfFinite public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ThetaIntegrandIntegrable
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_LengthPosOfPosDef(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_AdjFormula(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ParamsEx(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_LinksStage(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_HoweUnram(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_GaussianBinomialClosedForm(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_SqNormIntegralFundamentalDomainEqL2NormSq(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_ThetaKernelIteratedIntegralsSwap(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ThetaGrowthOfThetaSquareIntegrable(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_DefiniteUnitaryCocompact(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsRepsOfOpenCompact(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_SmulEqZeroOfInf(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_OmPureTensorOOfFinite(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ThetaIntegrandIntegrable(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_DownwardThetaIntegralSobolevContinuous(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_LengthPosOfPosDef(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_AdjFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ParamsEx(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_LinksStage(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisGeometry_u2082_HoweUnram(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_GaussianBinomialClosedForm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_SqNormIntegralFundamentalDomainEqL2NormSq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_ThetaKernelIteratedIntegralsSwap(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ThetaGrowthOfThetaSquareIntegrable(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_DefiniteUnitaryCocompact(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsRepsOfOpenCompact(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_SmulEqZeroOfInf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_OmPureTensorOOfFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ThetaIntegrandIntegrable(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

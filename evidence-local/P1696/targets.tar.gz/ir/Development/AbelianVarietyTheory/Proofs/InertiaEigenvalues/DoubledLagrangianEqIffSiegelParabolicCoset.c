// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.DoubledLagrangianEqIffSiegelParabolicCoset
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.FrameOfFst
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
lean_object* lp_tree_GlobalTheory_SWLagTerms_blk___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_toBlocks_u2081_u2081___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_toBlocks_u2082_u2081___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_toBlocks_u2082_u2082___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_toBlocks_u2081_u2082___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SWLagSame_rowD_u2081(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SWLagSame_rowD_u2082(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SWLagSame_rowD_u2081(lean_object* v_D_1_, lean_object* v_W_2_, lean_object* v_g_3_, lean_object* v_a_4_, lean_object* v_a_5_){
_start:
{
lean_object* v_host_6_; lean_object* v_toHostAx_7_; lean_object* v_instField_8_; lean_object* v___x_9_; lean_object* v_toRing_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v_toSub_13_; lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; 
v_host_6_ = lean_ctor_get(v_D_1_, 1);
v_toHostAx_7_ = lean_ctor_get(v_host_6_, 0);
v_instField_8_ = lean_ctor_get(v_toHostAx_7_, 3);
lean_inc_ref(v_instField_8_);
v___x_9_ = lp_mathlib_Field_toDivisionRing___redArg(v_instField_8_);
v_toRing_10_ = lean_ctor_get(v___x_9_, 0);
lean_inc_ref(v_toRing_10_);
lean_dec_ref(v___x_9_);
v___x_11_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_10_);
v___x_12_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_11_);
lean_dec_ref(v___x_11_);
v_toSub_13_ = lean_ctor_get(v___x_12_, 2);
lean_inc(v_toSub_13_);
lean_dec_ref(v___x_12_);
v___x_14_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SWLagTerms_blk___boxed), 5, 3);
lean_closure_set(v___x_14_, 0, v_D_1_);
lean_closure_set(v___x_14_, 1, v_W_2_);
lean_closure_set(v___x_14_, 2, v_g_3_);
lean_inc(v_a_5_);
lean_inc(v_a_4_);
lean_inc_ref(v___x_14_);
v___x_15_ = lp_mathlib_Matrix_toBlocks_u2081_u2081___redArg(v___x_14_, v_a_4_, v_a_5_);
v___x_16_ = lp_mathlib_Matrix_toBlocks_u2082_u2081___redArg(v___x_14_, v_a_4_, v_a_5_);
v___x_17_ = lean_apply_2(v_toSub_13_, v___x_15_, v___x_16_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SWLagSame_rowD_u2082(lean_object* v_D_18_, lean_object* v_W_19_, lean_object* v_g_20_, lean_object* v_a_21_, lean_object* v_a_22_){
_start:
{
lean_object* v_host_23_; lean_object* v_toHostAx_24_; lean_object* v_instField_25_; lean_object* v___x_26_; lean_object* v_toRing_27_; lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v_toSub_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; 
v_host_23_ = lean_ctor_get(v_D_18_, 1);
v_toHostAx_24_ = lean_ctor_get(v_host_23_, 0);
v_instField_25_ = lean_ctor_get(v_toHostAx_24_, 3);
lean_inc_ref(v_instField_25_);
v___x_26_ = lp_mathlib_Field_toDivisionRing___redArg(v_instField_25_);
v_toRing_27_ = lean_ctor_get(v___x_26_, 0);
lean_inc_ref(v_toRing_27_);
lean_dec_ref(v___x_26_);
v___x_28_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_27_);
v___x_29_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_28_);
lean_dec_ref(v___x_28_);
v_toSub_30_ = lean_ctor_get(v___x_29_, 2);
lean_inc(v_toSub_30_);
lean_dec_ref(v___x_29_);
v___x_31_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SWLagTerms_blk___boxed), 5, 3);
lean_closure_set(v___x_31_, 0, v_D_18_);
lean_closure_set(v___x_31_, 1, v_W_19_);
lean_closure_set(v___x_31_, 2, v_g_20_);
lean_inc(v_a_22_);
lean_inc(v_a_21_);
lean_inc_ref(v___x_31_);
v___x_32_ = lp_mathlib_Matrix_toBlocks_u2082_u2082___redArg(v___x_31_, v_a_21_, v_a_22_);
v___x_33_ = lp_mathlib_Matrix_toBlocks_u2081_u2082___redArg(v___x_31_, v_a_21_, v_a_22_);
v___x_34_ = lean_apply_2(v_toSub_30_, v___x_32_, v___x_33_);
return v___x_34_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_FrameOfFst(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_DoubledLagrangianEqIffSiegelParabolicCoset(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_FrameOfFst(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

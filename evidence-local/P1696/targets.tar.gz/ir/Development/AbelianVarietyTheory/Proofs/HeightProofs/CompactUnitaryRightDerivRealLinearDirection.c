// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.HeightProofs.CompactUnitaryRightDerivRealLinearDirection
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.BesselHermitianTheta.AllTied public import Development.AbelianVarietyTheory.BlockTheory.HeightDefect.FinitePartTypes public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.DiscreteSeriesUpqExistsIffDsExists public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.DiscreteSeriesUpqUniqueOfClassification public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HarishChandraModulesOn public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.HasDRepIffHasDerivAt public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.HasTypeAllAddOfEquiv public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.OneAddHsConjLe public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ContinuousOnAtTau public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.CoefBoundOfCasselmanWallach public import Development.AbelianVarietyTheory.Proofs.HeightProofs.FiniteDimensionalPolyV public import Development.AbelianVarietyTheory.Proofs.HeightProofs.ContDiffMatrixRightInvariantDerivative
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_tree_Finset_sum___at___00GlobalTheory_SmoothForms_polar_spec__0___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__0(lean_object* v_k_1_, lean_object* v_a_2_, lean_object* v_Y_3_, lean_object* v_b_4_, lean_object* v_l_5_){
_start:
{
lean_object* v_val_6_; lean_object* v___x_7_; lean_object* v_re_8_; lean_object* v_im_9_; lean_object* v___x_10_; lean_object* v___x_11_; 
v_val_6_ = lean_ctor_get(v_k_1_, 0);
lean_inc(v_val_6_);
lean_dec_ref(v_k_1_);
lean_inc(v_l_5_);
v___x_7_ = lean_apply_2(v_val_6_, v_a_2_, v_l_5_);
v_re_8_ = lean_ctor_get(v___x_7_, 0);
lean_inc(v_re_8_);
v_im_9_ = lean_ctor_get(v___x_7_, 1);
lean_inc(v_im_9_);
lean_dec_ref(v___x_7_);
v___x_10_ = lean_apply_2(v_Y_3_, v_l_5_, v_b_4_);
v___x_11_ = lp_mathlib_Complex_mulAux___at___00Zsqrtd_lift___at___00GaussianInt_toComplex_spec__0_spec__1(v_re_8_, v_im_9_, v___x_10_);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__1(lean_object* v_k_12_, lean_object* v_a_13_, lean_object* v_b_14_, lean_object* v_n_15_, lean_object* v_Y_16_){
_start:
{
lean_object* v___f_17_; lean_object* v___x_18_; lean_object* v___x_19_; 
v___f_17_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__0), 5, 4);
lean_closure_set(v___f_17_, 0, v_k_12_);
lean_closure_set(v___f_17_, 1, v_a_13_);
lean_closure_set(v___f_17_, 2, v_Y_16_);
lean_closure_set(v___f_17_, 3, v_b_14_);
v___x_18_ = l_List_finRange(v_n_15_);
v___x_19_ = lp_tree_Finset_sum___at___00GlobalTheory_SmoothForms_polar_spec__0___redArg(v___x_18_, v___f_17_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___redArg(lean_object* v_n_20_, lean_object* v_k_21_, lean_object* v_a_22_, lean_object* v_b_23_){
_start:
{
lean_object* v___f_24_; 
v___f_24_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__1), 5, 4);
lean_closure_set(v___f_24_, 0, v_k_21_);
lean_closure_set(v___f_24_, 1, v_a_22_);
lean_closure_set(v___f_24_, 2, v_b_23_);
lean_closure_set(v___f_24_, 3, v_n_20_);
return v___f_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer(lean_object* v_n_25_, lean_object* v_00_u03b5_26_, lean_object* v_k_27_, lean_object* v_a_28_, lean_object* v_b_29_){
_start:
{
lean_object* v___f_30_; 
v___f_30_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__1), 5, 4);
lean_closure_set(v___f_30_, 0, v_k_27_);
lean_closure_set(v___f_30_, 1, v_a_28_);
lean_closure_set(v___f_30_, 2, v_b_29_);
lean_closure_set(v___f_30_, 3, v_n_25_);
return v___f_30_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDer___boxed(lean_object* v_n_31_, lean_object* v_00_u03b5_32_, lean_object* v_k_33_, lean_object* v_a_34_, lean_object* v_b_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_tree_GlobalTheory_KFourier_entryDer(v_n_31_, v_00_u03b5_32_, v_k_33_, v_a_34_, v_b_35_);
lean_dec_ref(v_00_u03b5_32_);
return v_res_36_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___redArg___lam__1(lean_object* v_k_37_, lean_object* v_a_38_, lean_object* v_b_39_, lean_object* v_n_40_, lean_object* v_Y_41_){
_start:
{
lean_object* v___f_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v_re_45_; lean_object* v_im_46_; lean_object* v___x_48_; uint8_t v_isShared_49_; uint8_t v_isSharedCheck_54_; 
v___f_42_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDer___redArg___lam__0), 5, 4);
lean_closure_set(v___f_42_, 0, v_k_37_);
lean_closure_set(v___f_42_, 1, v_a_38_);
lean_closure_set(v___f_42_, 2, v_Y_41_);
lean_closure_set(v___f_42_, 3, v_b_39_);
v___x_43_ = l_List_finRange(v_n_40_);
v___x_44_ = lp_tree_Finset_sum___at___00GlobalTheory_SmoothForms_polar_spec__0___redArg(v___x_43_, v___f_42_);
v_re_45_ = lean_ctor_get(v___x_44_, 0);
v_im_46_ = lean_ctor_get(v___x_44_, 1);
v_isSharedCheck_54_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_54_ == 0)
{
v___x_48_ = v___x_44_;
v_isShared_49_ = v_isSharedCheck_54_;
goto v_resetjp_47_;
}
else
{
lean_inc(v_im_46_);
lean_inc(v_re_45_);
lean_dec(v___x_44_);
v___x_48_ = lean_box(0);
v_isShared_49_ = v_isSharedCheck_54_;
goto v_resetjp_47_;
}
v_resetjp_47_:
{
lean_object* v___f_50_; lean_object* v___x_52_; 
v___f_50_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_50_, 0, v_im_46_);
if (v_isShared_49_ == 0)
{
lean_ctor_set(v___x_48_, 1, v___f_50_);
v___x_52_ = v___x_48_;
goto v_reusejp_51_;
}
else
{
lean_object* v_reuseFailAlloc_53_; 
v_reuseFailAlloc_53_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_53_, 0, v_re_45_);
lean_ctor_set(v_reuseFailAlloc_53_, 1, v___f_50_);
v___x_52_ = v_reuseFailAlloc_53_;
goto v_reusejp_51_;
}
v_reusejp_51_:
{
return v___x_52_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___redArg(lean_object* v_n_55_, lean_object* v_k_56_, lean_object* v_a_57_, lean_object* v_b_58_){
_start:
{
lean_object* v___f_59_; 
v___f_59_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDerStar___redArg___lam__1), 5, 4);
lean_closure_set(v___f_59_, 0, v_k_56_);
lean_closure_set(v___f_59_, 1, v_a_57_);
lean_closure_set(v___f_59_, 2, v_b_58_);
lean_closure_set(v___f_59_, 3, v_n_55_);
return v___f_59_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar(lean_object* v_n_60_, lean_object* v_00_u03b5_61_, lean_object* v_k_62_, lean_object* v_a_63_, lean_object* v_b_64_){
_start:
{
lean_object* v___f_65_; 
v___f_65_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_KFourier_entryDerStar___redArg___lam__1), 5, 4);
lean_closure_set(v___f_65_, 0, v_k_62_);
lean_closure_set(v___f_65_, 1, v_a_63_);
lean_closure_set(v___f_65_, 2, v_b_64_);
lean_closure_set(v___f_65_, 3, v_n_60_);
return v___f_65_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_entryDerStar___boxed(lean_object* v_n_66_, lean_object* v_00_u03b5_67_, lean_object* v_k_68_, lean_object* v_a_69_, lean_object* v_b_70_){
_start:
{
lean_object* v_res_71_; 
v_res_71_ = lp_tree_GlobalTheory_KFourier_entryDerStar(v_n_66_, v_00_u03b5_67_, v_k_68_, v_a_69_, v_b_70_);
lean_dec_ref(v_00_u03b5_67_);
return v_res_71_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_AllTied(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_HeightDefect_FinitePartTypes(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqExistsIffDsExists(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqUniqueOfClassification(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_HasTypeAllAddOfEquiv(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_OneAddHsConjLe(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousOnAtTau(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CoefBoundOfCasselmanWallach(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FiniteDimensionalPolyV(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ContDiffMatrixRightInvariantDerivative(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_CompactUnitaryRightDerivRealLinearDirection(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_AllTied(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_HeightDefect_FinitePartTypes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqExistsIffDsExists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqUniqueOfClassification(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_HasTypeAllAddOfEquiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_OneAddHsConjLe(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousOnAtTau(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CoefBoundOfCasselmanWallach(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FiniteDimensionalPolyV(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ContDiffMatrixRightInvariantDerivative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

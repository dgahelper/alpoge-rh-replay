// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsRichSmall
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.PublishedTheorems.WeberRayClassFields.WeberRayFieldSt public import Development.AbelianVarietyTheory.Definitions.HeightFunctions.JointQ public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.AssembleLattice public import Development.AbelianVarietyTheory.Definitions.GlobalTwisting.DisjointExceptional public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ConjugateEmbApply public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.LogClassNumberLeLogAbsDiscrDiv public import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsFieldIdealsPrincipalStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.SzAdjoinRootOfUnity public import Development.AbelianVarietyTheory.Proofs.HeightProofs.SzFieldRangeEmbedding public import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsCapitulationFieldSizeStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsImagQuadraticHostStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.FieldSizeMonotoneStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.SumSizesLeRingPolynomial public import Development.AbelianVarietyTheory.Proofs.HeightProofs.HostXiOrderBoundsStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.FieldSizeSupAddStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.FieldSizeWeberRay
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_WeberRayClassFields_WeberRayFieldSt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_JointQ(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_AssembleLattice(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GlobalTwisting_DisjointExceptional(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ConjugateEmbApply(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_LogClassNumberLeLogAbsDiscrDiv(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsFieldIdealsPrincipalStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SzAdjoinRootOfUnity(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SzFieldRangeEmbedding(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsCapitulationFieldSizeStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsImagQuadraticHostStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeMonotoneStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SumSizesLeRingPolynomial(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_HostXiOrderBoundsStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeSupAddStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeWeberRay(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsRichSmall(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_WeberRayClassFields_WeberRayFieldSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_JointQ(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_AssembleLattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GlobalTwisting_DisjointExceptional(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ConjugateEmbApply(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_LogClassNumberLeLogAbsDiscrDiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsFieldIdealsPrincipalStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SzAdjoinRootOfUnity(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SzFieldRangeEmbedding(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsCapitulationFieldSizeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsImagQuadraticHostStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeMonotoneStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_SumSizesLeRingPolynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_HostXiOrderBoundsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeSupAddStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FieldSizeWeberRay(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsShortSeriesTwistCharOfTwistingIdeleChar
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.HeightProofs.Hilbert90FiniteIdelesCongruenceStatement public import Development.AbelianVarietyTheory.Proofs.HeightProofs.PowClassNumberIntegral public import Development.AbelianVarietyTheory.Proofs.HeightProofs.ExistsXiOKNotTwistCond public import Development.AbelianVarietyTheory.Proofs.JetHarmonics.ExistsGeneratingCharacters public import Development.AbelianVarietyTheory.Definitions.HeightFunctions.IntUnit public import Formalism.LocalToGlobal.ProjectiveLattices.FullXi public import Development.AbelianVarietyTheory.Definitions.HeightFunctions.NormComparisonConstants public import Formalism.LocalToGlobal.ProjectiveLattices.DepthTie public import Development.AbelianVarietyTheory.Definitions.Jets.EmbShortThLeThetaPlain public import Development.AbelianVarietyTheory.Definitions.ExistenceOfLattices.CoeSelfDualLatticeInFrameCoordinatesEq
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_Hilbert90FiniteIdelesCongruenceStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_PowClassNumberIntegral(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsXiOKNotTwistCond(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_ExistsGeneratingCharacters(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_IntUnit(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_FullXi(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_NormComparisonConstants(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_DepthTie(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Jets_EmbShortThLeThetaPlain(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ExistenceOfLattices_CoeSelfDualLatticeInFrameCoordinatesEq(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsShortSeriesTwistCharOfTwistingIdeleChar(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_Hilbert90FiniteIdelesCongruenceStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_PowClassNumberIntegral(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ExistsXiOKNotTwistCond(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_JetHarmonics_ExistsGeneratingCharacters(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_IntUnit(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_FullXi(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_NormComparisonConstants(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_DepthTie(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Jets_EmbShortThLeThetaPlain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ExistenceOfLattices_CoeSelfDualLatticeInFrameCoordinatesEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

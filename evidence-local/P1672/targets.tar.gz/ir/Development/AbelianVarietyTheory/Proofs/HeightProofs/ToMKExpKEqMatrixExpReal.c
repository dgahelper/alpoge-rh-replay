// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.HeightProofs.ToMKExpKEqMatrixExpReal
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.LocalToGlobal.BesselHermitianTheta.AllTied public import Development.AbelianVarietyTheory.BlockTheory.HeightDefect.FinitePartTypes public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.DiscreteSeriesUpqExistsIffDsExists public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.DiscreteSeriesUpqUniqueOfClassification public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HarishChandraModulesOn public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.HasDRepIffHasDerivAt public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.HasTypeAllAddOfEquiv public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.OneAddHsConjLe public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ContinuousOnAtTau public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.CoefBoundOfCasselmanWallach public import Development.AbelianVarietyTheory.Proofs.HeightProofs.FiniteDimensionalPolyV
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_kSub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_kSub___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord___redArg(lean_object* v_c_1_, lean_object* v_M_2_){
_start:
{
lean_object* v_snd_3_; lean_object* v_snd_4_; uint8_t v___x_5_; 
v_snd_3_ = lean_ctor_get(v_c_1_, 1);
lean_inc(v_snd_3_);
v_snd_4_ = lean_ctor_get(v_snd_3_, 1);
v___x_5_ = lean_unbox(v_snd_4_);
if (v___x_5_ == 0)
{
lean_object* v_fst_6_; lean_object* v_fst_7_; lean_object* v___x_8_; lean_object* v_re_9_; lean_object* v_im_10_; lean_object* v___x_12_; uint8_t v_isShared_13_; uint8_t v_isSharedCheck_18_; 
v_fst_6_ = lean_ctor_get(v_c_1_, 0);
lean_inc(v_fst_6_);
lean_dec_ref(v_c_1_);
v_fst_7_ = lean_ctor_get(v_snd_3_, 0);
lean_inc(v_fst_7_);
lean_dec(v_snd_3_);
v___x_8_ = lean_apply_2(v_M_2_, v_fst_6_, v_fst_7_);
v_re_9_ = lean_ctor_get(v___x_8_, 0);
v_im_10_ = lean_ctor_get(v___x_8_, 1);
v_isSharedCheck_18_ = !lean_is_exclusive(v___x_8_);
if (v_isSharedCheck_18_ == 0)
{
v___x_12_ = v___x_8_;
v_isShared_13_ = v_isSharedCheck_18_;
goto v_resetjp_11_;
}
else
{
lean_inc(v_im_10_);
lean_inc(v_re_9_);
lean_dec(v___x_8_);
v___x_12_ = lean_box(0);
v_isShared_13_ = v_isSharedCheck_18_;
goto v_resetjp_11_;
}
v_resetjp_11_:
{
lean_object* v___f_14_; lean_object* v___x_16_; 
v___f_14_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_14_, 0, v_im_10_);
if (v_isShared_13_ == 0)
{
lean_ctor_set(v___x_12_, 1, v___f_14_);
v___x_16_ = v___x_12_;
goto v_reusejp_15_;
}
else
{
lean_object* v_reuseFailAlloc_17_; 
v_reuseFailAlloc_17_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_17_, 0, v_re_9_);
lean_ctor_set(v_reuseFailAlloc_17_, 1, v___f_14_);
v___x_16_ = v_reuseFailAlloc_17_;
goto v_reusejp_15_;
}
v_reusejp_15_:
{
return v___x_16_;
}
}
}
else
{
lean_object* v_fst_19_; lean_object* v_fst_20_; lean_object* v___x_21_; 
v_fst_19_ = lean_ctor_get(v_c_1_, 0);
lean_inc(v_fst_19_);
lean_dec_ref(v_c_1_);
v_fst_20_ = lean_ctor_get(v_snd_3_, 0);
lean_inc(v_fst_20_);
lean_dec(v_snd_3_);
v___x_21_ = lean_apply_2(v_M_2_, v_fst_19_, v_fst_20_);
return v___x_21_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord(lean_object* v_n_22_, lean_object* v_c_23_, lean_object* v_M_24_){
_start:
{
lean_object* v___x_25_; 
v___x_25_ = lp_tree_GlobalTheory_KFourier_mxCoord___redArg(v_c_23_, v_M_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_mxCoord___boxed(lean_object* v_n_26_, lean_object* v_c_27_, lean_object* v_M_28_){
_start:
{
lean_object* v_res_29_; 
v_res_29_ = lp_tree_GlobalTheory_KFourier_mxCoord(v_n_26_, v_c_27_, v_M_28_);
lean_dec(v_n_26_);
return v_res_29_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_kSub(lean_object* v_n_30_, lean_object* v_00_u03b5_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lean_box(0);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_KFourier_kSub___boxed(lean_object* v_n_33_, lean_object* v_00_u03b5_34_){
_start:
{
lean_object* v_res_35_; 
v_res_35_ = lp_tree_GlobalTheory_KFourier_kSub(v_n_33_, v_00_u03b5_34_);
lean_dec_ref(v_00_u03b5_34_);
lean_dec(v_n_33_);
return v_res_35_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_AllTied(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_HeightDefect_FinitePartTypes(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqExistsIffDsExists(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqUniqueOfClassification(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_HasTypeAllAddOfEquiv(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_OneAddHsConjLe(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousOnAtTau(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CoefBoundOfCasselmanWallach(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FiniteDimensionalPolyV(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_ToMKExpKEqMatrixExpReal(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_AllTied(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_HeightDefect_FinitePartTypes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqExistsIffDsExists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_DiscreteSeriesUpqUniqueOfClassification(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_HasTypeAllAddOfEquiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_OneAddHsConjLe(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ContinuousOnAtTau(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CoefBoundOfCasselmanWallach(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_HeightProofs_FiniteDimensionalPolyV(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

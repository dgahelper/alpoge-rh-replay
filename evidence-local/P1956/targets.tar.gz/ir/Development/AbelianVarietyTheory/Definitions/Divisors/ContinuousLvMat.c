// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.Divisors.ContinuousLvMat
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.IsLv
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_Formalism_UG_cT___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_dotProduct___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__4(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__6(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__8(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__10(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__0(lean_object* v_J_1_, lean_object* v_a_2_, lean_object* v_j_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_2(v_J_1_, v_j_3_, v_a_2_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__1(lean_object* v_C_x27_5_, lean_object* v_a_6_, lean_object* v_j_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lean_apply_2(v_C_x27_5_, v_a_6_, v_j_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__3(lean_object* v_Z_x27_9_, lean_object* v_a_10_, lean_object* v_j_11_){
_start:
{
lean_object* v___x_12_; 
v___x_12_ = lean_apply_2(v_Z_x27_9_, v_a_10_, v_j_11_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__4(lean_object* v_D_x27_13_, lean_object* v_a_14_, lean_object* v_j_15_){
_start:
{
lean_object* v___x_16_; 
v___x_16_ = lean_apply_2(v_D_x27_13_, v_a_14_, v_j_15_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__2(lean_object* v_s_17_, lean_object* v_D_18_, lean_object* v_j_19_, lean_object* v_j_20_){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lp_tree_Formalism_UG_cT___redArg(v_s_17_, v_D_18_, v_j_19_, v_j_20_);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5(lean_object* v_s_22_, lean_object* v_D_23_, lean_object* v___x_24_, lean_object* v_toMul_25_, lean_object* v_toAddCommMonoid_26_, lean_object* v___f_27_, lean_object* v_j_28_){
_start:
{
lean_object* v___f_29_; lean_object* v___x_30_; 
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__2), 4, 3);
lean_closure_set(v___f_29_, 0, v_s_22_);
lean_closure_set(v___f_29_, 1, v_D_23_);
lean_closure_set(v___f_29_, 2, v_j_28_);
v___x_30_ = lp_mathlib_dotProduct___redArg(v___x_24_, v_toMul_25_, v_toAddCommMonoid_26_, v___f_29_, v___f_27_);
return v___x_30_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5___boxed(lean_object* v_s_31_, lean_object* v_D_32_, lean_object* v___x_33_, lean_object* v_toMul_34_, lean_object* v_toAddCommMonoid_35_, lean_object* v___f_36_, lean_object* v_j_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5(v_s_31_, v_D_32_, v___x_33_, v_toMul_34_, v_toAddCommMonoid_35_, v___f_36_, v_j_37_);
lean_dec_ref(v_toAddCommMonoid_35_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__6(lean_object* v_s_39_, lean_object* v_Z_40_, lean_object* v_j_41_, lean_object* v_j_42_){
_start:
{
lean_object* v___x_43_; 
v___x_43_ = lp_tree_Formalism_UG_cT___redArg(v_s_39_, v_Z_40_, v_j_41_, v_j_42_);
return v___x_43_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7(lean_object* v_s_44_, lean_object* v_Z_45_, lean_object* v___x_46_, lean_object* v_toMul_47_, lean_object* v_toAddCommMonoid_48_, lean_object* v___f_49_, lean_object* v_j_50_){
_start:
{
lean_object* v___f_51_; lean_object* v___x_52_; 
v___f_51_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__6), 4, 3);
lean_closure_set(v___f_51_, 0, v_s_44_);
lean_closure_set(v___f_51_, 1, v_Z_45_);
lean_closure_set(v___f_51_, 2, v_j_50_);
v___x_52_ = lp_mathlib_dotProduct___redArg(v___x_46_, v_toMul_47_, v_toAddCommMonoid_48_, v___f_51_, v___f_49_);
return v___x_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7___boxed(lean_object* v_s_53_, lean_object* v_Z_54_, lean_object* v___x_55_, lean_object* v_toMul_56_, lean_object* v_toAddCommMonoid_57_, lean_object* v___f_58_, lean_object* v_j_59_){
_start:
{
lean_object* v_res_60_; 
v_res_60_ = lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7(v_s_53_, v_Z_54_, v___x_55_, v_toMul_56_, v_toAddCommMonoid_57_, v___f_58_, v_j_59_);
lean_dec_ref(v_toAddCommMonoid_57_);
return v_res_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__8(lean_object* v_s_61_, lean_object* v_C_62_, lean_object* v_j_63_, lean_object* v_j_64_){
_start:
{
lean_object* v___x_65_; 
v___x_65_ = lp_tree_Formalism_UG_cT___redArg(v_s_61_, v_C_62_, v_j_63_, v_j_64_);
return v___x_65_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9(lean_object* v_s_66_, lean_object* v_C_67_, lean_object* v___x_68_, lean_object* v_toMul_69_, lean_object* v_toAddCommMonoid_70_, lean_object* v___f_71_, lean_object* v_j_72_){
_start:
{
lean_object* v___f_73_; lean_object* v___x_74_; 
v___f_73_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__8), 4, 3);
lean_closure_set(v___f_73_, 0, v_s_66_);
lean_closure_set(v___f_73_, 1, v_C_67_);
lean_closure_set(v___f_73_, 2, v_j_72_);
v___x_74_ = lp_mathlib_dotProduct___redArg(v___x_68_, v_toMul_69_, v_toAddCommMonoid_70_, v___f_73_, v___f_71_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9___boxed(lean_object* v_s_75_, lean_object* v_C_76_, lean_object* v___x_77_, lean_object* v_toMul_78_, lean_object* v_toAddCommMonoid_79_, lean_object* v___f_80_, lean_object* v_j_81_){
_start:
{
lean_object* v_res_82_; 
v_res_82_ = lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9(v_s_75_, v_C_76_, v___x_77_, v_toMul_78_, v_toAddCommMonoid_79_, v___f_80_, v_j_81_);
lean_dec_ref(v_toAddCommMonoid_79_);
return v_res_82_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__10(lean_object* v_Ji_83_, lean_object* v_j_84_, lean_object* v_j_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = lean_apply_2(v_Ji_83_, v_j_84_, v_j_85_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11(lean_object* v_Ji_87_, lean_object* v___x_88_, lean_object* v_toMul_89_, lean_object* v_toAddCommMonoid_90_, lean_object* v___f_91_, lean_object* v_j_92_){
_start:
{
lean_object* v___f_93_; lean_object* v___x_94_; 
v___f_93_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__10), 3, 2);
lean_closure_set(v___f_93_, 0, v_Ji_87_);
lean_closure_set(v___f_93_, 1, v_j_92_);
v___x_94_ = lp_mathlib_dotProduct___redArg(v___x_88_, v_toMul_89_, v_toAddCommMonoid_90_, v___f_93_, v___f_91_);
return v___x_94_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11___boxed(lean_object* v_Ji_95_, lean_object* v___x_96_, lean_object* v_toMul_97_, lean_object* v_toAddCommMonoid_98_, lean_object* v___f_99_, lean_object* v_j_100_){
_start:
{
lean_object* v_res_101_; 
v_res_101_ = lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11(v_Ji_95_, v___x_96_, v_toMul_97_, v_toAddCommMonoid_98_, v___f_99_, v_j_100_);
lean_dec_ref(v_toAddCommMonoid_98_);
return v_res_101_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry___redArg(lean_object* v_inst_102_, lean_object* v_s_103_, lean_object* v_n_104_, lean_object* v_j_105_, lean_object* v_m_106_, lean_object* v_J_107_, lean_object* v_C_108_, lean_object* v_D_109_, lean_object* v_Z_110_, lean_object* v_Ji_111_, lean_object* v_C_x27_112_, lean_object* v_D_x27_113_, lean_object* v_Z_x27_114_, lean_object* v_a_115_, lean_object* v_a_116_){
_start:
{
lean_object* v_toSemiring_117_; lean_object* v___x_118_; lean_object* v_toMul_119_; lean_object* v_toAdd_120_; lean_object* v_toAddCommMonoid_121_; lean_object* v___f_122_; lean_object* v___f_123_; lean_object* v___f_124_; lean_object* v___f_125_; lean_object* v___x_126_; lean_object* v___x_127_; lean_object* v___f_128_; lean_object* v___f_129_; lean_object* v___f_130_; lean_object* v___x_131_; lean_object* v___f_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; 
v_toSemiring_117_ = lean_ctor_get(v_inst_102_, 0);
lean_inc_ref_n(v_toSemiring_117_, 2);
lean_dec_ref(v_inst_102_);
v___x_118_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_117_);
v_toMul_119_ = lean_ctor_get(v___x_118_, 0);
lean_inc_n(v_toMul_119_, 7);
v_toAdd_120_ = lean_ctor_get(v___x_118_, 1);
lean_inc_n(v_toAdd_120_, 2);
lean_dec_ref(v___x_118_);
v_toAddCommMonoid_121_ = lean_ctor_get(v_toSemiring_117_, 0);
lean_inc_ref_n(v_toAddCommMonoid_121_, 5);
lean_dec_ref(v_toSemiring_117_);
v___f_122_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__0), 3, 2);
lean_closure_set(v___f_122_, 0, v_J_107_);
lean_closure_set(v___f_122_, 1, v_a_116_);
lean_inc_n(v_a_115_, 2);
v___f_123_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__1), 3, 2);
lean_closure_set(v___f_123_, 0, v_C_x27_112_);
lean_closure_set(v___f_123_, 1, v_a_115_);
v___f_124_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__3), 3, 2);
lean_closure_set(v___f_124_, 0, v_Z_x27_114_);
lean_closure_set(v___f_124_, 1, v_a_115_);
v___f_125_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__4), 3, 2);
lean_closure_set(v___f_125_, 0, v_D_x27_113_);
lean_closure_set(v___f_125_, 1, v_a_115_);
v___x_126_ = l_List_finRange(v_j_105_);
v___x_127_ = l_List_finRange(v_n_104_);
lean_inc_ref_n(v___f_122_, 2);
lean_inc_n(v___x_127_, 2);
lean_inc_n(v_s_103_, 2);
v___f_128_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__5___boxed), 7, 6);
lean_closure_set(v___f_128_, 0, v_s_103_);
lean_closure_set(v___f_128_, 1, v_D_109_);
lean_closure_set(v___f_128_, 2, v___x_127_);
lean_closure_set(v___f_128_, 3, v_toMul_119_);
lean_closure_set(v___f_128_, 4, v_toAddCommMonoid_121_);
lean_closure_set(v___f_128_, 5, v___f_122_);
v___f_129_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__7___boxed), 7, 6);
lean_closure_set(v___f_129_, 0, v_s_103_);
lean_closure_set(v___f_129_, 1, v_Z_110_);
lean_closure_set(v___f_129_, 2, v___x_127_);
lean_closure_set(v___f_129_, 3, v_toMul_119_);
lean_closure_set(v___f_129_, 4, v_toAddCommMonoid_121_);
lean_closure_set(v___f_129_, 5, v___f_122_);
v___f_130_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__9___boxed), 7, 6);
lean_closure_set(v___f_130_, 0, v_s_103_);
lean_closure_set(v___f_130_, 1, v_C_108_);
lean_closure_set(v___f_130_, 2, v___x_127_);
lean_closure_set(v___f_130_, 3, v_toMul_119_);
lean_closure_set(v___f_130_, 4, v_toAddCommMonoid_121_);
lean_closure_set(v___f_130_, 5, v___f_122_);
v___x_131_ = l_List_finRange(v_m_106_);
lean_inc(v___x_131_);
v___f_132_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SphEisModel_carry___redArg___lam__11___boxed), 6, 5);
lean_closure_set(v___f_132_, 0, v_Ji_111_);
lean_closure_set(v___f_132_, 1, v___x_131_);
lean_closure_set(v___f_132_, 2, v_toMul_119_);
lean_closure_set(v___f_132_, 3, v_toAddCommMonoid_121_);
lean_closure_set(v___f_132_, 4, v___f_129_);
lean_inc(v___x_126_);
v___x_133_ = lp_mathlib_dotProduct___redArg(v___x_126_, v_toMul_119_, v_toAddCommMonoid_121_, v___f_123_, v___f_128_);
v___x_134_ = lp_mathlib_dotProduct___redArg(v___x_131_, v_toMul_119_, v_toAddCommMonoid_121_, v___f_124_, v___f_132_);
v___x_135_ = lean_apply_2(v_toAdd_120_, v___x_133_, v___x_134_);
v___x_136_ = lp_mathlib_dotProduct___redArg(v___x_126_, v_toMul_119_, v_toAddCommMonoid_121_, v___f_125_, v___f_130_);
lean_dec_ref(v_toAddCommMonoid_121_);
v___x_137_ = lean_apply_2(v_toAdd_120_, v___x_135_, v___x_136_);
return v___x_137_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SphEisModel_carry(lean_object* v_A_138_, lean_object* v_inst_139_, lean_object* v_s_140_, lean_object* v_n_141_, lean_object* v_j_142_, lean_object* v_m_143_, lean_object* v_J_144_, lean_object* v_C_145_, lean_object* v_D_146_, lean_object* v_Z_147_, lean_object* v_Ji_148_, lean_object* v_C_x27_149_, lean_object* v_D_x27_150_, lean_object* v_Z_x27_151_, lean_object* v_a_152_, lean_object* v_a_153_){
_start:
{
lean_object* v___x_154_; 
v___x_154_ = lp_tree_GlobalTheory_SphEisModel_carry___redArg(v_inst_139_, v_s_140_, v_n_141_, v_j_142_, v_m_143_, v_J_144_, v_C_145_, v_D_146_, v_Z_147_, v_Ji_148_, v_C_x27_149_, v_D_x27_150_, v_Z_x27_151_, v_a_152_, v_a_153_);
return v___x_154_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_IsLv(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_ContinuousLvMat(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_IsLv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

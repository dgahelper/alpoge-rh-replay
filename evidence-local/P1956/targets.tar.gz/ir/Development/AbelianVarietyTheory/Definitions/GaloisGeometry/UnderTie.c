// Lean compiler output
// Module: Development.AbelianVarietyTheory.Definitions.GaloisGeometry.UnderTie
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.GaloisGeometry.ExistsMidLevIff public import Formalism.LocalToGlobal.Columns.ChainInstY
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___redArg(lean_object* v_t_1_, lean_object* v_A_2_, lean_object* v_i_3_, lean_object* v_00_u03b2_4_, lean_object* v_P_5_, lean_object* v_a_6_){
_start:
{
lean_object* v_X_7_; lean_object* v_m2_8_; lean_object* v___x_9_; lean_object* v___x_10_; uint8_t v___x_11_; 
v_X_7_ = lean_ctor_get(v_t_1_, 6);
v_m2_8_ = lean_ctor_get(v_t_1_, 15);
v___x_9_ = lean_unsigned_to_nat(1u);
v___x_10_ = lean_nat_add(v_m2_8_, v___x_9_);
v___x_11_ = lean_nat_dec_eq(v_i_3_, v___x_10_);
lean_dec(v___x_10_);
if (v___x_11_ == 0)
{
lean_object* v_fieldE_12_; lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v_toSemiring_15_; lean_object* v___x_16_; lean_object* v_toZero_17_; 
lean_dec(v_a_6_);
lean_dec(v_00_u03b2_4_);
lean_dec_ref(v_A_2_);
v_fieldE_12_ = lean_ctor_get(v_X_7_, 1);
v___x_13_ = lp_mathlib_Field_toSemifield___redArg(v_fieldE_12_);
v___x_14_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_13_);
v_toSemiring_15_ = lean_ctor_get(v___x_14_, 0);
lean_inc_ref(v_toSemiring_15_);
lean_dec_ref(v___x_14_);
v___x_16_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_15_);
v_toZero_17_ = lean_ctor_get(v___x_16_, 1);
lean_inc(v_toZero_17_);
lean_dec_ref(v___x_16_);
return v_toZero_17_;
}
else
{
lean_object* v_y0_18_; lean_object* v___x_19_; 
v_y0_18_ = lean_ctor_get(v_A_2_, 6);
lean_inc(v_y0_18_);
lean_dec_ref(v_A_2_);
v___x_19_ = lean_apply_3(v_y0_18_, v_00_u03b2_4_, v_P_5_, v_a_6_);
return v___x_19_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___redArg___boxed(lean_object* v_t_20_, lean_object* v_A_21_, lean_object* v_i_22_, lean_object* v_00_u03b2_23_, lean_object* v_P_24_, lean_object* v_a_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GlobalTheory_TwV_y0At___redArg(v_t_20_, v_A_21_, v_i_22_, v_00_u03b2_23_, v_P_24_, v_a_25_);
lean_dec(v_i_22_);
lean_dec_ref(v_t_20_);
return v_res_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At(lean_object* v_D_27_, lean_object* v_L_28_, lean_object* v_hT_29_, lean_object* v_Gi_30_, lean_object* v_Gl_31_, lean_object* v_Kc_32_, lean_object* v_Y_33_, lean_object* v_cX_34_, lean_object* v_ex_35_, lean_object* v_t_36_, lean_object* v_u_37_, lean_object* v_00_u03bc_38_, lean_object* v_St_39_, lean_object* v_A_40_, lean_object* v_i_41_, lean_object* v_hi_42_, lean_object* v_00_u03b2_43_, lean_object* v_P_44_, lean_object* v_a_45_){
_start:
{
lean_object* v___x_46_; 
v___x_46_ = lp_tree_GlobalTheory_TwV_y0At___redArg(v_t_36_, v_A_40_, v_i_41_, v_00_u03b2_43_, v_P_44_, v_a_45_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TwV_y0At___boxed(lean_object** _args){
lean_object* v_D_47_ = _args[0];
lean_object* v_L_48_ = _args[1];
lean_object* v_hT_49_ = _args[2];
lean_object* v_Gi_50_ = _args[3];
lean_object* v_Gl_51_ = _args[4];
lean_object* v_Kc_52_ = _args[5];
lean_object* v_Y_53_ = _args[6];
lean_object* v_cX_54_ = _args[7];
lean_object* v_ex_55_ = _args[8];
lean_object* v_t_56_ = _args[9];
lean_object* v_u_57_ = _args[10];
lean_object* v_00_u03bc_58_ = _args[11];
lean_object* v_St_59_ = _args[12];
lean_object* v_A_60_ = _args[13];
lean_object* v_i_61_ = _args[14];
lean_object* v_hi_62_ = _args[15];
lean_object* v_00_u03b2_63_ = _args[16];
lean_object* v_P_64_ = _args[17];
lean_object* v_a_65_ = _args[18];
_start:
{
lean_object* v_res_66_; 
v_res_66_ = lp_tree_GlobalTheory_TwV_y0At(v_D_47_, v_L_48_, v_hT_49_, v_Gi_50_, v_Gl_51_, v_Kc_52_, v_Y_53_, v_cX_54_, v_ex_55_, v_t_56_, v_u_57_, v_00_u03bc_58_, v_St_59_, v_A_60_, v_i_61_, v_hi_62_, v_00_u03b2_63_, v_P_64_, v_a_65_);
lean_dec(v_i_61_);
lean_dec_ref(v_St_59_);
lean_dec(v_00_u03bc_58_);
lean_dec(v_u_57_);
lean_dec_ref(v_t_56_);
lean_dec_ref(v_ex_55_);
lean_dec_ref(v_cX_54_);
lean_dec_ref(v_Y_53_);
lean_dec_ref(v_Kc_52_);
lean_dec_ref(v_Gl_51_);
lean_dec_ref(v_Gi_50_);
lean_dec_ref(v_hT_49_);
lean_dec_ref(v_L_48_);
lean_dec_ref(v_D_47_);
return v_res_66_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ExistsMidLevIff(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_ChainInstY(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_UnderTie(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_GaloisGeometry_ExistsMidLevIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_ChainInstY(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

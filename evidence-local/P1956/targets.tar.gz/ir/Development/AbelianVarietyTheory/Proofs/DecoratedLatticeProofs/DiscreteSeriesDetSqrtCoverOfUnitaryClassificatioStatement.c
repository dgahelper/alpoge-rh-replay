// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.DiscreteSeriesDetSqrtCoverOfUnitaryClassificatioStatement
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.DiscreteSeriesDetSqrtCoverOfUnitaryClassificatio public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HarishChandraModulesOn public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.AdmissibleDiscreteSeriesOfHasParam public import Development.AbelianVarietyTheory.PublishedTheorems.DiscreteSeriesUnitary₂.DiscreteSeriesClassificationIff public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsOfIsDSPar public import Development.AbelianVarietyTheory.Statements.CuspFrameWeights.DiscreteSpectrumKFiniteDecomposition
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_DiscreteSeriesDetSqrtCoverOfUnitaryClassificatio(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_DiscreteSeriesUnitary_u2082_DiscreteSeriesClassificationIff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsOfIsDSPar(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_DiscreteSpectrumKFiniteDecomposition(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_DiscreteSeriesDetSqrtCoverOfUnitaryClassificatioStatement(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_DiscreteSeriesDetSqrtCoverOfUnitaryClassificatio(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_DiscreteSeriesUnitary_u2082_DiscreteSeriesClassificationIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsOfIsDSPar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_CuspFrameWeights_DiscreteSpectrumKFiniteDecomposition(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

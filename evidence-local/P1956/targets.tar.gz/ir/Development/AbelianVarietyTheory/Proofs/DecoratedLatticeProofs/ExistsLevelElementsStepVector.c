// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.ExistsLevelElementsStepVector
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.FrameTopAlt public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.RatioOKOfRootOfUnity public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.ChainParSucc public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.ExistsNormLeHeightPow public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.AdmissibleDiscreteSeriesOfHasParam public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HarishChandraModulesOn public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.HasDRepIffHasDerivAt public import Development.AbelianVarietyTheory.PublishedTheorems.AutomorphicForms₂.WeilRepresentationUnitaryPair public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.UnitProductRescaleDisjointFinsets public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.LiftSchurMultiplierCompatibility public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.SpecialisedUniversalSeriesEqTwistedThetaSeries public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.OmPureTensorOOfFinite
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_FrameTopAlt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_RatioOKOfRootOfUnity(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_ChainParSucc(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_WeilRepresentationUnitaryPair(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_UnitProductRescaleDisjointFinsets(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_LiftSchurMultiplierCompatibility(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SpecialisedUniversalSeriesEqTwistedThetaSeries(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_OmPureTensorOOfFinite(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_ExistsLevelElementsStepVector(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_FrameTopAlt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_RatioOKOfRootOfUnity(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_ChainParSucc(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_ExistsNormLeHeightPow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_HasDRepIffHasDerivAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_AutomorphicForms_u2082_WeilRepresentationUnitaryPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_UnitProductRescaleDisjointFinsets(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_LiftSchurMultiplierCompatibility(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SpecialisedUniversalSeriesEqTwistedThetaSeries(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_OmPureTensorOOfFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

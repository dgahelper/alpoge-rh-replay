// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.ExistsIsJ
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.TopFormula public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.MiPinnedWithFinIff public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.AllPositiveModelFiniteDimensionalCompactType public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ExistsMultiplicityLiftLastChainStep public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.MapFnOfEqValC public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.TensorTypesRealPlacesEquivSpanWeylModules public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.NormalizedFockFormPureTensorProperties public import Formalism.LocalToGlobal.HermitianForms.TiedBrInj public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.FiniteDimUnitaryKTypeEqDualWeylModuleStatement public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.TensorWeylModuleMapsInjectiveOnPureSpanStatement public import Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.NegHarishChandraParamRevEqWeylWeightTopStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_TopFormula(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_MiPinnedWithFinIff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AllPositiveModelFiniteDimensionalCompactType(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsMultiplicityLiftLastChainStep(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_MapFnOfEqValC(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_TensorTypesRealPlacesEquivSpanWeylModules(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_NormalizedFockFormPureTensorProperties(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_HermitianForms_TiedBrInj(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_FiniteDimUnitaryKTypeEqDualWeylModuleStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_TensorWeylModuleMapsInjectiveOnPureSpanStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_NegHarishChandraParamRevEqWeylWeightTopStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_ExistsIsJ(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_TopFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_MiPinnedWithFinIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AllPositiveModelFiniteDimensionalCompactType(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsMultiplicityLiftLastChainStep(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_MapFnOfEqValC(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_TensorTypesRealPlacesEquivSpanWeylModules(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_NormalizedFockFormPureTensorProperties(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_HermitianForms_TiedBrInj(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_FiniteDimUnitaryKTypeEqDualWeylModuleStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_TensorWeylModuleMapsInjectiveOnPureSpanStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_NegHarishChandraParamRevEqWeylWeightTopStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

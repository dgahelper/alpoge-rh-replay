// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DecoratedLatticeProofs.EqSmulOfUnitaryEquivariant
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.EvalAtOneExtremalMul public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.SplitPart public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.TopFormula public import Development.AbelianVarietyTheory.Definitions.LatticeFrames.BrEqv public import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.EquivariantMapEqSmul public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.RowActCoefPolyAndUnitaryDense public import Development.AbelianVarietyTheory.Proofs.GlobalInterpolation.StatementWithTransposeOfBranching public import Development.AbelianVarietyTheory.BlockTheory.GlobalSignature.InterlacingEquivariance public import Development.AbelianVarietyTheory.Proofs.FlagMeasures.MapFnOfEqValC public import Formalism.LocalToGlobal.Columns.PolyFnLemmas
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
static lean_once_cell_t lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0;
static lean_once_cell_t lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_4_ = lp_mathlib_Complex_ofReal(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0(lean_object* v_n_5_, lean_object* v_h_6_, lean_object* v_i_7_, lean_object* v_j_8_){
_start:
{
uint8_t v___x_9_; 
v___x_9_ = lean_nat_dec_lt(v_i_7_, v_n_5_);
if (v___x_9_ == 0)
{
uint8_t v___x_10_; 
lean_dec(v_i_7_);
lean_dec_ref(v_h_6_);
v___x_10_ = lean_nat_dec_lt(v_j_8_, v_n_5_);
lean_dec(v_j_8_);
if (v___x_10_ == 0)
{
lean_object* v___x_11_; 
v___x_11_ = lean_obj_once(&lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0, &lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0_once, _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__0);
return v___x_11_;
}
else
{
lean_object* v___x_12_; 
v___x_12_ = lean_obj_once(&lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1, &lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1_once, _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1);
return v___x_12_;
}
}
else
{
uint8_t v___x_13_; 
v___x_13_ = lean_nat_dec_lt(v_j_8_, v_n_5_);
if (v___x_13_ == 0)
{
lean_object* v___x_14_; 
lean_dec(v_j_8_);
lean_dec(v_i_7_);
lean_dec_ref(v_h_6_);
v___x_14_ = lean_obj_once(&lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1, &lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1_once, _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___closed__1);
return v___x_14_;
}
else
{
lean_object* v___x_15_; 
v___x_15_ = lean_apply_2(v_h_6_, v_i_7_, v_j_8_);
return v___x_15_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___boxed(lean_object* v_n_16_, lean_object* v_h_17_, lean_object* v_i_18_, lean_object* v_j_19_){
_start:
{
lean_object* v_res_20_; 
v_res_20_ = lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0(v_n_16_, v_h_17_, v_i_18_, v_j_19_);
lean_dec(v_n_16_);
return v_res_20_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0(void){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg(lean_object* v_n_22_, lean_object* v_h_23_, lean_object* v_a_24_, lean_object* v_a_25_){
_start:
{
lean_object* v___x_26_; lean_object* v_toFun_27_; lean_object* v___f_28_; lean_object* v___x_29_; 
v___x_26_ = lean_obj_once(&lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0, &lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0_once, _init_lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___closed__0);
v_toFun_27_ = lean_ctor_get(v___x_26_, 0);
v___f_28_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg___lam__0___boxed), 4, 2);
lean_closure_set(v___f_28_, 0, v_n_22_);
lean_closure_set(v___f_28_, 1, v_h_23_);
lean_inc(v_toFun_27_);
v___x_29_ = lean_apply_3(v_toFun_27_, v___f_28_, v_a_24_, v_a_25_);
return v___x_29_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat(lean_object* v_N_30_, lean_object* v_n_31_, lean_object* v_h_32_, lean_object* v_a_33_, lean_object* v_a_34_){
_start:
{
lean_object* v___x_35_; 
v___x_35_ = lp_tree_GlobalTheory_BranchMultOne_blkMat___redArg(v_n_31_, v_h_32_, v_a_33_, v_a_34_);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_BranchMultOne_blkMat___boxed(lean_object* v_N_36_, lean_object* v_n_37_, lean_object* v_h_38_, lean_object* v_a_39_, lean_object* v_a_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = lp_tree_GlobalTheory_BranchMultOne_blkMat(v_N_36_, v_n_37_, v_h_38_, v_a_39_, v_a_40_);
lean_dec(v_N_36_);
return v_res_41_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_EvalAtOneExtremalMul(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_SplitPart(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_TopFormula(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_BrEqv(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_GlobalInterpolation_EquivariantMapEqSmul(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_RowActCoefPolyAndUnitaryDense(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_GlobalInterpolation_StatementWithTransposeOfBranching(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_GlobalSignature_InterlacingEquivariance(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_MapFnOfEqValC(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_Columns_PolyFnLemmas(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DecoratedLatticeProofs_EqSmulOfUnitaryEquivariant(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_EvalAtOneExtremalMul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_SplitPart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_TopFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_LatticeFrames_BrEqv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_GlobalInterpolation_EquivariantMapEqSmul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_RowActCoefPolyAndUnitaryDense(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_GlobalInterpolation_StatementWithTransposeOfBranching(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_GlobalSignature_InterlacingEquivariance(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FlagMeasures_MapFnOfEqValC(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_Columns_PolyFnLemmas(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.ThetaNetDimensionAndPointCountBound
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.HeightFunctions.GrowthConstantBoundGcR public import Development.AbelianVarietyTheory.Definitions.ThetaValues.GamAt public import Development.AbelianVarietyTheory.Definitions.ArchimedeanThetaValues.CarchAt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.PlaceDivisors.StChartF public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.PullbackSections.NoCommonZeroSt public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.PullbackSections.SupBoundPageRows public import Formalism.SharpRestriction.Divisibility.GeneratorPowers.ThExprUniqOfChartIndep2 public import Formalism.SharpRestriction.GenusPolyhedralBounds.RelativeIndexClassSets.InnerEuclideanEmbeddingEqAverage public import Formalism.LocalToGlobal.ProjectiveLattices.CurveAsm public import Formalism.LocalToGlobal.ProjectiveLattices.CurveLocInst public import Formalism.LocalToGlobal.ProjectiveLattices.RealPtPf public import Formalism.LocalToGlobal.ProjectiveLattices.TieInst public import Formalism.LocalToGlobal.ProjectiveLattices.CombAlgOfCombBound public import Formalism.LocalToGlobal.ProjectiveLattices.DepthTie public import Formalism.LocalToGlobal.ProjectiveLattices.FullExists public import Development.AbelianVarietyTheory.Definitions.ThetaValues.Generic public import Formalism.LocalToGlobal.ProjectiveLattices.AxHLAM public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.NetDataExists public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.DeepSubMulRecAll public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.PageRelationDegThree public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.GamAtOfLawsCore public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.WeightsBelow public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.SizePageRowsOfSizePageAt public import Development.AbelianVarietyTheory.Proofs.TorusSplitting.PageRows
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_GrowthConstantBoundGcR(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaValues_GamAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_CarchAt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PlaceDivisors_StChartF(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PullbackSections_NoCommonZeroSt(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PullbackSections_SupBoundPageRows(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ThExprUniqOfChartIndep2(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GenusPolyhedralBounds_RelativeIndexClassSets_InnerEuclideanEmbeddingEqAverage(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CurveAsm(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CurveLocInst(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_RealPtPf(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_TieInst(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CombAlgOfCombBound(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_DepthTie(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_FullExists(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaValues_Generic(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_AxHLAM(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_NetDataExists(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_DeepSubMulRecAll(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_PageRelationDegThree(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_GamAtOfLawsCore(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_WeightsBelow(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_SizePageRowsOfSizePageAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TorusSplitting_PageRows(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_ThetaNetDimensionAndPointCountBound(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_HeightFunctions_GrowthConstantBoundGcR(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaValues_GamAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ArchimedeanThetaValues_CarchAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PlaceDivisors_StChartF(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PullbackSections_NoCommonZeroSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_PullbackSections_SupBoundPageRows(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_GeneratorPowers_ThExprUniqOfChartIndep2(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GenusPolyhedralBounds_RelativeIndexClassSets_InnerEuclideanEmbeddingEqAverage(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CurveAsm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CurveLocInst(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_RealPtPf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_TieInst(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_CombAlgOfCombBound(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_DepthTie(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_FullExists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_ThetaValues_Generic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_ProjectiveLattices_AxHLAM(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_NetDataExists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_DeepSubMulRecAll(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_PageRelationDegThree(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_GamAtOfLawsCore(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_WeightsBelow(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_SizePageRowsOfSizePageAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TorusSplitting_PageRows(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: CompanionTheory.HarishChandraModules.KFiniteAnalyticVectors.AdmissibleSmoothVectors.MapStdPoly
// Imports: public import Init public meta import Init public import Formalism.PeriodIntegrals.KFinSmooth public import Formalism.PeriodIntegrals.IsLowUnitH
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Equiv_instFintype___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_Equiv_Perm_signAux2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_List_ofFn___redArg(lean_object*, lean_object*);
lean_object* l_List_foldrTR___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word___redArg___lam__0(lean_object* v_toMul_1_, lean_object* v_E_2_, lean_object* v_a_3_, lean_object* v_w_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
lean_inc(v_toMul_1_);
v___x_5_ = lean_apply_2(v_toMul_1_, v_E_2_, v_a_3_);
v___x_6_ = lean_apply_2(v_toMul_1_, v___x_5_, v_w_4_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word___redArg(lean_object* v_inst_7_, lean_object* v_E_8_, lean_object* v_l_9_){
_start:
{
lean_object* v_toSemiring_10_; lean_object* v___x_11_; lean_object* v_toMul_12_; lean_object* v___f_13_; lean_object* v___x_14_; 
v_toSemiring_10_ = lean_ctor_get(v_inst_7_, 0);
lean_inc_ref(v_toSemiring_10_);
lean_dec_ref(v_inst_7_);
v___x_11_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_10_);
v_toMul_12_ = lean_ctor_get(v___x_11_, 0);
lean_inc(v_toMul_12_);
lean_dec_ref(v___x_11_);
lean_inc(v_E_8_);
v___f_13_ = lean_alloc_closure((void*)(lp_tree_CompanionTheory_D_gk_admitted_word___redArg___lam__0), 4, 2);
lean_closure_set(v___f_13_, 0, v_toMul_12_);
lean_closure_set(v___f_13_, 1, v_E_8_);
v___x_14_ = l_List_foldrTR___redArg(v___f_13_, v_E_8_, v_l_9_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_word(lean_object* v_R_15_, lean_object* v_inst_16_, lean_object* v_E_17_, lean_object* v_l_18_){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = lp_tree_CompanionTheory_D_gk_admitted_word___redArg(v_inst_16_, v_E_17_, v_l_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__0(lean_object* v_00_u03c0_20_, lean_object* v_a_21_, lean_object* v_i_22_){
_start:
{
lean_object* v_toFun_23_; lean_object* v___x_24_; lean_object* v___x_25_; 
v_toFun_23_ = lean_ctor_get(v_00_u03c0_20_, 0);
lean_inc(v_toFun_23_);
lean_dec_ref(v_00_u03c0_20_);
v___x_24_ = lean_apply_1(v_toFun_23_, v_i_22_);
v___x_25_ = lean_apply_1(v_a_21_, v___x_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__1(lean_object* v___x_26_, lean_object* v___x_27_, lean_object* v_a_28_, lean_object* v_toIntCast_29_, lean_object* v_M_30_, lean_object* v_inst_31_, lean_object* v_E_32_, lean_object* v_toMul_33_, lean_object* v_00_u03c0_34_){
_start:
{
lean_object* v___x_35_; lean_object* v_val_36_; lean_object* v___f_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; 
lean_inc_ref(v_00_u03c0_34_);
v___x_35_ = lp_mathlib_Equiv_Perm_signAux2___redArg(v___x_26_, v___x_27_, v_00_u03c0_34_);
v_val_36_ = lean_ctor_get(v___x_35_, 0);
lean_inc(v_val_36_);
lean_dec_ref(v___x_35_);
v___f_37_ = lean_alloc_closure((void*)(lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__0), 3, 2);
lean_closure_set(v___f_37_, 0, v_00_u03c0_34_);
lean_closure_set(v___f_37_, 1, v_a_28_);
v___x_38_ = lean_apply_1(v_toIntCast_29_, v_val_36_);
v___x_39_ = l_List_ofFn___redArg(v_M_30_, v___f_37_);
v___x_40_ = lp_tree_CompanionTheory_D_gk_admitted_word___redArg(v_inst_31_, v_E_32_, v___x_39_);
v___x_41_ = lean_apply_2(v_toMul_33_, v___x_38_, v___x_40_);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg(lean_object* v_inst_42_, lean_object* v_E_43_, lean_object* v_M_44_, lean_object* v_a_45_){
_start:
{
lean_object* v_toSemiring_46_; lean_object* v_toAddCommMonoid_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v_toMul_52_; lean_object* v___x_53_; lean_object* v_toIntCast_54_; lean_object* v___f_55_; lean_object* v___x_56_; 
v_toSemiring_46_ = lean_ctor_get(v_inst_42_, 0);
v_toAddCommMonoid_47_ = lean_ctor_get(v_toSemiring_46_, 0);
lean_inc_ref(v_toAddCommMonoid_47_);
lean_inc_n(v_M_44_, 2);
v___x_48_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_48_, 0, v_M_44_);
v___x_49_ = l_List_finRange(v_M_44_);
lean_inc_n(v___x_49_, 2);
lean_inc_ref_n(v___x_48_, 2);
v___x_50_ = lp_mathlib_Equiv_instFintype___redArg(v___x_48_, v___x_48_, v___x_49_, v___x_49_);
lean_inc_ref(v_toSemiring_46_);
v___x_51_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_46_);
v_toMul_52_ = lean_ctor_get(v___x_51_, 0);
lean_inc(v_toMul_52_);
lean_dec_ref(v___x_51_);
lean_inc_ref(v_inst_42_);
v___x_53_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_42_);
v_toIntCast_54_ = lean_ctor_get(v___x_53_, 0);
lean_inc(v_toIntCast_54_);
lean_dec_ref(v___x_53_);
v___f_55_ = lean_alloc_closure((void*)(lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg___lam__1), 9, 8);
lean_closure_set(v___f_55_, 0, v___x_48_);
lean_closure_set(v___f_55_, 1, v___x_49_);
lean_closure_set(v___f_55_, 2, v_a_45_);
lean_closure_set(v___f_55_, 3, v_toIntCast_54_);
lean_closure_set(v___f_55_, 4, v_M_44_);
lean_closure_set(v___f_55_, 5, v_inst_42_);
lean_closure_set(v___f_55_, 6, v_E_43_);
lean_closure_set(v___f_55_, 7, v_toMul_52_);
v___x_56_ = lp_mathlib_Finset_sum___redArg(v_toAddCommMonoid_47_, v___x_50_, v___f_55_);
lean_dec_ref(v_toAddCommMonoid_47_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_CompanionTheory_D_gk_admitted_stdPoly(lean_object* v_R_57_, lean_object* v_inst_58_, lean_object* v_E_59_, lean_object* v_M_60_, lean_object* v_a_61_){
_start:
{
lean_object* v___x_62_; 
v___x_62_ = lp_tree_CompanionTheory_D_gk_admitted_stdPoly___redArg(v_inst_58_, v_E_59_, v_M_60_, v_a_61_);
return v___x_62_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_PeriodIntegrals_KFinSmooth(uint8_t builtin);
lean_object* initialize_tree_Formalism_PeriodIntegrals_IsLowUnitH(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_HarishChandraModules_KFiniteAnalyticVectors_AdmissibleSmoothVectors_MapStdPoly(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_PeriodIntegrals_KFinSmooth(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_PeriodIntegrals_IsLowUnitH(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

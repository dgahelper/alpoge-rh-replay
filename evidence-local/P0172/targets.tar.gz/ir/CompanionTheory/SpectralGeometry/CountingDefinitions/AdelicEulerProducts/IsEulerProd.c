// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.CountingDefinitions.AdelicEulerProducts.IsEulerProd
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.UnipotentAdelicQuotients.SiegelWeilUnitaryConvergent public import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_HeckeCharacterZeroLocus_SiegelWeilU_actTup___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_TensorProduct_tmul___redArg(lean_object*, lean_object*);
lean_object* l_Fin_cases___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_TensorProduct_addMonoid___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_CommRing_toNonUnitalCommRing___redArg(lean_object*);
lean_object* lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Algebra_TensorProduct_mul___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Finset_sum___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Fin_cons___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___redArg(lean_object* v_inst_1_, lean_object* v_inst_2_, lean_object* v_inst_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_M_6_, lean_object* v_h_7_, lean_object* v_X_8_, lean_object* v_a_9_, lean_object* v_a_10_){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lp_tree_HeckeCharacterZeroLocus_SiegelWeilU_actTup___redArg(v_inst_1_, v_inst_2_, v_inst_3_, v_inst_4_, v_inst_5_, v_M_6_, v_h_7_, v_X_8_, v_a_9_, v_a_10_);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___redArg___boxed(lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_inst_14_, lean_object* v_inst_15_, lean_object* v_inst_16_, lean_object* v_M_17_, lean_object* v_h_18_, lean_object* v_X_19_, lean_object* v_a_20_, lean_object* v_a_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree_GlobalTheory_CompanionTheory_SW_actW___redArg(v_inst_12_, v_inst_13_, v_inst_14_, v_inst_15_, v_inst_16_, v_M_17_, v_h_18_, v_X_19_, v_a_20_, v_a_21_);
lean_dec_ref(v_inst_15_);
lean_dec_ref(v_inst_13_);
lean_dec_ref(v_inst_12_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW(lean_object* v_F_23_, lean_object* v_E_24_, lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_R_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_00_u03c3_31_, lean_object* v_M_32_, lean_object* v_n_33_, lean_object* v_J_34_, lean_object* v_h_35_, lean_object* v_X_36_, lean_object* v_a_37_, lean_object* v_a_38_){
_start:
{
lean_object* v___x_39_; 
v___x_39_ = lp_tree_HeckeCharacterZeroLocus_SiegelWeilU_actTup___redArg(v_inst_25_, v_inst_26_, v_inst_27_, v_inst_29_, v_inst_30_, v_M_32_, v_h_35_, v_X_36_, v_a_37_, v_a_38_);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_actW___boxed(lean_object* v_F_40_, lean_object* v_E_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_inst_44_, lean_object* v_R_45_, lean_object* v_inst_46_, lean_object* v_inst_47_, lean_object* v_00_u03c3_48_, lean_object* v_M_49_, lean_object* v_n_50_, lean_object* v_J_51_, lean_object* v_h_52_, lean_object* v_X_53_, lean_object* v_a_54_, lean_object* v_a_55_){
_start:
{
lean_object* v_res_56_; 
v_res_56_ = lp_tree_GlobalTheory_CompanionTheory_SW_actW(v_F_40_, v_E_41_, v_inst_42_, v_inst_43_, v_inst_44_, v_R_45_, v_inst_46_, v_inst_47_, v_00_u03c3_48_, v_M_49_, v_n_50_, v_J_51_, v_h_52_, v_X_53_, v_a_54_, v_a_55_);
lean_dec(v_J_51_);
lean_dec(v_n_50_);
lean_dec(v_00_u03c3_48_);
lean_dec_ref(v_inst_46_);
lean_dec_ref(v_inst_43_);
lean_dec_ref(v_inst_42_);
return v_res_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg___lam__0(lean_object* v_X_57_, lean_object* v_i_58_, lean_object* v_g_59_, lean_object* v_a_60_, lean_object* v_toCommSemiring_61_, lean_object* v___x_62_, lean_object* v_toSMul_63_, lean_object* v___x_64_, lean_object* v_toSMul_65_, lean_object* v_c_66_){
_start:
{
lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_76__overap_69_; lean_object* v___x_70_; 
lean_inc(v_c_66_);
v___x_67_ = lean_apply_2(v_X_57_, v_c_66_, v_i_58_);
v___x_68_ = lean_apply_2(v_g_59_, v_c_66_, v_a_60_);
v___x_76__overap_69_ = lp_mathlib_Algebra_TensorProduct_mul___redArg(v_toCommSemiring_61_, v___x_62_, v_toSMul_63_, v___x_64_, v_toSMul_65_);
v___x_70_ = lean_apply_2(v___x_76__overap_69_, v___x_67_, v___x_68_);
return v___x_70_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg(lean_object* v_inst_71_, lean_object* v_inst_72_, lean_object* v_inst_73_, lean_object* v_inst_74_, lean_object* v_inst_75_, lean_object* v_n_76_, lean_object* v_X_77_, lean_object* v_g_78_, lean_object* v_a_79_, lean_object* v_i_80_){
_start:
{
lean_object* v___x_81_; lean_object* v_toSemiring_82_; lean_object* v_toCommSemiring_83_; lean_object* v_toAddCommMonoid_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v_toSemiring_87_; lean_object* v_toAddCommMonoid_88_; lean_object* v_toSMul_89_; lean_object* v_toSMul_90_; lean_object* v___x_91_; lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v_toCommRing_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___f_98_; lean_object* v___x_99_; 
v___x_81_ = lp_mathlib_Field_toSemifield___redArg(v_inst_71_);
v_toSemiring_82_ = lean_ctor_get(v_inst_74_, 0);
v_toCommSemiring_83_ = lean_ctor_get(v___x_81_, 0);
lean_inc_ref_n(v_toCommSemiring_83_, 2);
lean_dec_ref(v___x_81_);
v_toAddCommMonoid_84_ = lean_ctor_get(v_toSemiring_82_, 0);
v___x_85_ = lp_mathlib_Field_toSemifield___redArg(v_inst_72_);
v___x_86_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_85_);
v_toSemiring_87_ = lean_ctor_get(v___x_86_, 0);
lean_inc_ref(v_toSemiring_87_);
lean_dec_ref(v___x_86_);
v_toAddCommMonoid_88_ = lean_ctor_get(v_toSemiring_87_, 0);
lean_inc_ref(v_toAddCommMonoid_88_);
lean_dec_ref(v_toSemiring_87_);
v_toSMul_89_ = lean_ctor_get(v_inst_75_, 0);
lean_inc_n(v_toSMul_89_, 2);
lean_dec_ref(v_inst_75_);
v_toSMul_90_ = lean_ctor_get(v_inst_73_, 0);
lean_inc_n(v_toSMul_90_, 2);
lean_dec_ref(v_inst_73_);
lean_inc_ref(v_toAddCommMonoid_84_);
v___x_91_ = lp_mathlib_TensorProduct_addMonoid___redArg(v_toCommSemiring_83_, v_toAddCommMonoid_84_, v_toAddCommMonoid_88_, v_toSMul_89_, v_toSMul_90_);
v___x_92_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v_inst_74_);
lean_dec_ref(v_inst_74_);
v___x_93_ = lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(v___x_92_);
v_toCommRing_94_ = lean_ctor_get(v_inst_72_, 0);
v___x_95_ = l_List_finRange(v_n_76_);
v___x_96_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v_toCommRing_94_);
v___x_97_ = lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(v___x_96_);
v___f_98_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg___lam__0), 10, 9);
lean_closure_set(v___f_98_, 0, v_X_77_);
lean_closure_set(v___f_98_, 1, v_i_80_);
lean_closure_set(v___f_98_, 2, v_g_78_);
lean_closure_set(v___f_98_, 3, v_a_79_);
lean_closure_set(v___f_98_, 4, v_toCommSemiring_83_);
lean_closure_set(v___f_98_, 5, v___x_93_);
lean_closure_set(v___f_98_, 6, v_toSMul_89_);
lean_closure_set(v___f_98_, 7, v___x_97_);
lean_closure_set(v___f_98_, 8, v_toSMul_90_);
v___x_99_ = lp_mathlib_Finset_sum___redArg(v___x_91_, v___x_95_, v___f_98_);
lean_dec_ref(v___x_91_);
return v___x_99_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg___boxed(lean_object* v_inst_100_, lean_object* v_inst_101_, lean_object* v_inst_102_, lean_object* v_inst_103_, lean_object* v_inst_104_, lean_object* v_n_105_, lean_object* v_X_106_, lean_object* v_g_107_, lean_object* v_a_108_, lean_object* v_i_109_){
_start:
{
lean_object* v_res_110_; 
v_res_110_ = lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg(v_inst_100_, v_inst_101_, v_inst_102_, v_inst_103_, v_inst_104_, v_n_105_, v_X_106_, v_g_107_, v_a_108_, v_i_109_);
lean_dec_ref(v_inst_101_);
lean_dec_ref(v_inst_100_);
return v_res_110_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul(lean_object* v_F_111_, lean_object* v_E_112_, lean_object* v_inst_113_, lean_object* v_inst_114_, lean_object* v_inst_115_, lean_object* v_R_116_, lean_object* v_inst_117_, lean_object* v_inst_118_, lean_object* v_M_119_, lean_object* v_n_120_, lean_object* v_X_121_, lean_object* v_g_122_, lean_object* v_a_123_, lean_object* v_i_124_){
_start:
{
lean_object* v___x_125_; 
v___x_125_ = lp_tree_GlobalTheory_CompanionTheory_SW_rmul___redArg(v_inst_113_, v_inst_114_, v_inst_115_, v_inst_117_, v_inst_118_, v_n_120_, v_X_121_, v_g_122_, v_a_123_, v_i_124_);
return v___x_125_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_rmul___boxed(lean_object* v_F_126_, lean_object* v_E_127_, lean_object* v_inst_128_, lean_object* v_inst_129_, lean_object* v_inst_130_, lean_object* v_R_131_, lean_object* v_inst_132_, lean_object* v_inst_133_, lean_object* v_M_134_, lean_object* v_n_135_, lean_object* v_X_136_, lean_object* v_g_137_, lean_object* v_a_138_, lean_object* v_i_139_){
_start:
{
lean_object* v_res_140_; 
v_res_140_ = lp_tree_GlobalTheory_CompanionTheory_SW_rmul(v_F_126_, v_E_127_, v_inst_128_, v_inst_129_, v_inst_130_, v_R_131_, v_inst_132_, v_inst_133_, v_M_134_, v_n_135_, v_X_136_, v_g_137_, v_a_138_, v_i_139_);
lean_dec(v_M_134_);
lean_dec_ref(v_inst_129_);
lean_dec_ref(v_inst_128_);
return v_res_140_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0(lean_object* v_s_141_, lean_object* v_toOne_142_, lean_object* v_x_143_, lean_object* v_x_144_){
_start:
{
lean_object* v___x_145_; 
v___x_145_ = lp_mathlib_TensorProduct_tmul___redArg(v_s_141_, v_toOne_142_);
return v___x_145_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0___boxed(lean_object* v_s_146_, lean_object* v_toOne_147_, lean_object* v_x_148_, lean_object* v_x_149_){
_start:
{
lean_object* v_res_150_; 
v_res_150_ = lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0(v_s_146_, v_toOne_147_, v_x_148_, v_x_149_);
lean_dec(v_x_149_);
lean_dec(v_x_148_);
return v_res_150_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg(lean_object* v_inst_151_, lean_object* v_s_152_){
_start:
{
lean_object* v___x_153_; lean_object* v_toRing_154_; lean_object* v___x_155_; lean_object* v_toAddMonoidWithOne_156_; lean_object* v_toOne_157_; lean_object* v___f_158_; 
v___x_153_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_151_);
v_toRing_154_ = lean_ctor_get(v___x_153_, 0);
lean_inc_ref(v_toRing_154_);
lean_dec_ref(v___x_153_);
v___x_155_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_154_);
v_toAddMonoidWithOne_156_ = lean_ctor_get(v___x_155_, 1);
lean_inc_ref(v_toAddMonoidWithOne_156_);
lean_dec_ref(v___x_155_);
v_toOne_157_ = lean_ctor_get(v_toAddMonoidWithOne_156_, 2);
lean_inc(v_toOne_157_);
lean_dec_ref(v_toAddMonoidWithOne_156_);
v___f_158_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg___lam__0___boxed), 4, 2);
lean_closure_set(v___f_158_, 0, v_s_152_);
lean_closure_set(v___f_158_, 1, v_toOne_157_);
return v___f_158_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal(lean_object* v_F_159_, lean_object* v_E_160_, lean_object* v_inst_161_, lean_object* v_inst_162_, lean_object* v_inst_163_, lean_object* v_R_164_, lean_object* v_inst_165_, lean_object* v_inst_166_, lean_object* v_00_u03c3_167_, lean_object* v_s_168_){
_start:
{
lean_object* v___x_169_; 
v___x_169_ = lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___redArg(v_inst_162_, v_s_168_);
return v___x_169_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_hermScal___boxed(lean_object* v_F_170_, lean_object* v_E_171_, lean_object* v_inst_172_, lean_object* v_inst_173_, lean_object* v_inst_174_, lean_object* v_R_175_, lean_object* v_inst_176_, lean_object* v_inst_177_, lean_object* v_00_u03c3_178_, lean_object* v_s_179_){
_start:
{
lean_object* v_res_180_; 
v_res_180_ = lp_tree_GlobalTheory_CompanionTheory_SW_hermScal(v_F_170_, v_E_171_, v_inst_172_, v_inst_173_, v_inst_174_, v_R_175_, v_inst_176_, v_inst_177_, v_00_u03c3_178_, v_s_179_);
lean_dec(v_00_u03c3_178_);
lean_dec_ref(v_inst_177_);
lean_dec_ref(v_inst_176_);
lean_dec_ref(v_inst_174_);
lean_dec_ref(v_inst_172_);
return v_res_180_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0(lean_object* v_inst_181_, lean_object* v_x_182_){
_start:
{
lean_inc(v_inst_181_);
return v_inst_181_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0___boxed(lean_object* v_inst_183_, lean_object* v_x_184_){
_start:
{
lean_object* v_res_185_; 
v_res_185_ = lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0(v_inst_183_, v_x_184_);
lean_dec(v_x_184_);
lean_dec(v_inst_183_);
return v_res_185_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1(lean_object* v_A_186_, lean_object* v_inst_187_, lean_object* v_i_188_, lean_object* v___y_189_){
_start:
{
lean_object* v___x_190_; lean_object* v___x_191_; 
v___x_190_ = lean_apply_1(v_A_186_, v_i_188_);
v___x_191_ = l_Fin_cases___redArg(v_inst_187_, v___x_190_, v___y_189_);
return v___x_191_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1___boxed(lean_object* v_A_192_, lean_object* v_inst_193_, lean_object* v_i_194_, lean_object* v___y_195_){
_start:
{
lean_object* v_res_196_; 
v_res_196_ = lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1(v_A_192_, v_inst_193_, v_i_194_, v___y_195_);
lean_dec(v___y_195_);
lean_dec(v_inst_193_);
return v_res_196_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0(void){
_start:
{
lean_object* v___x_197_; 
v___x_197_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_197_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg(lean_object* v_inst_198_, lean_object* v_M_199_, lean_object* v_t_200_, lean_object* v_A_201_, lean_object* v_a_202_, lean_object* v_a_203_){
_start:
{
lean_object* v___x_204_; lean_object* v_toFun_205_; lean_object* v___f_206_; lean_object* v___f_207_; lean_object* v___x_208_; lean_object* v___x_209_; lean_object* v___x_210_; 
v___x_204_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___closed__0);
v_toFun_205_ = lean_ctor_get(v___x_204_, 0);
lean_inc(v_inst_198_);
v___f_206_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_206_, 0, v_inst_198_);
v___f_207_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__1___boxed), 4, 2);
lean_closure_set(v___f_207_, 0, v_A_201_);
lean_closure_set(v___f_207_, 1, v_inst_198_);
lean_inc(v_M_199_);
v___x_208_ = lean_alloc_closure((void*)(lp_mathlib_Fin_cons___boxed), 5, 4);
lean_closure_set(v___x_208_, 0, v_M_199_);
lean_closure_set(v___x_208_, 1, lean_box(0));
lean_closure_set(v___x_208_, 2, v_t_200_);
lean_closure_set(v___x_208_, 3, v___f_206_);
v___x_209_ = lean_alloc_closure((void*)(lp_mathlib_Fin_cons___boxed), 5, 4);
lean_closure_set(v___x_209_, 0, v_M_199_);
lean_closure_set(v___x_209_, 1, lean_box(0));
lean_closure_set(v___x_209_, 2, v___x_208_);
lean_closure_set(v___x_209_, 3, v___f_207_);
lean_inc(v_toFun_205_);
v___x_210_ = lean_apply_3(v_toFun_205_, v___x_209_, v_a_202_, v_a_203_);
return v___x_210_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_blockOne(lean_object* v_K_211_, lean_object* v_inst_212_, lean_object* v_M_213_, lean_object* v_t_214_, lean_object* v_A_215_, lean_object* v_a_216_, lean_object* v_a_217_){
_start:
{
lean_object* v___x_218_; 
v___x_218_ = lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg(v_inst_212_, v_M_213_, v_t_214_, v_A_215_, v_a_216_, v_a_217_);
return v___x_218_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1(lean_object* v_X_219_, lean_object* v_inst_220_, lean_object* v_a_221_, lean_object* v___y_222_){
_start:
{
lean_object* v___x_223_; lean_object* v___x_224_; 
v___x_223_ = lean_apply_1(v_X_219_, v_a_221_);
v___x_224_ = l_Fin_cases___redArg(v_inst_220_, v___x_223_, v___y_222_);
return v___x_224_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1___boxed(lean_object* v_X_225_, lean_object* v_inst_226_, lean_object* v_a_227_, lean_object* v___y_228_){
_start:
{
lean_object* v_res_229_; 
v_res_229_ = lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1(v_X_225_, v_inst_226_, v_a_227_, v___y_228_);
lean_dec(v___y_228_);
lean_dec(v_inst_226_);
return v_res_229_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg(lean_object* v_inst_230_, lean_object* v_inst_231_, lean_object* v_M_232_, lean_object* v_X_233_, lean_object* v_i_234_, lean_object* v_a_235_){
_start:
{
lean_object* v___f_236_; lean_object* v___f_237_; lean_object* v___x_238_; lean_object* v___x_31__overap_239_; lean_object* v___x_240_; 
lean_inc(v_inst_230_);
v___f_236_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_blockOne___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_236_, 0, v_inst_230_);
v___f_237_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___lam__1___boxed), 4, 2);
lean_closure_set(v___f_237_, 0, v_X_233_);
lean_closure_set(v___f_237_, 1, v_inst_230_);
v___x_238_ = lean_alloc_closure((void*)(lp_mathlib_Fin_cons___boxed), 5, 4);
lean_closure_set(v___x_238_, 0, v_M_232_);
lean_closure_set(v___x_238_, 1, lean_box(0));
lean_closure_set(v___x_238_, 2, v_inst_231_);
lean_closure_set(v___x_238_, 3, v___f_236_);
v___x_31__overap_239_ = l_Fin_cases___redArg(v___x_238_, v___f_237_, v_i_234_);
lean_dec_ref(v___x_238_);
v___x_240_ = lean_apply_1(v___x_31__overap_239_, v_a_235_);
return v___x_240_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg___boxed(lean_object* v_inst_241_, lean_object* v_inst_242_, lean_object* v_M_243_, lean_object* v_X_244_, lean_object* v_i_245_, lean_object* v_a_246_){
_start:
{
lean_object* v_res_247_; 
v_res_247_ = lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg(v_inst_241_, v_inst_242_, v_M_243_, v_X_244_, v_i_245_, v_a_246_);
lean_dec(v_i_245_);
return v_res_247_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup(lean_object* v_K_248_, lean_object* v_inst_249_, lean_object* v_inst_250_, lean_object* v_M_251_, lean_object* v_n_252_, lean_object* v_X_253_, lean_object* v_i_254_, lean_object* v_a_255_){
_start:
{
lean_object* v___x_256_; 
v___x_256_ = lp_tree_GlobalTheory_CompanionTheory_SW_consTup___redArg(v_inst_249_, v_inst_250_, v_M_251_, v_X_253_, v_i_254_, v_a_255_);
return v___x_256_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_consTup___boxed(lean_object* v_K_257_, lean_object* v_inst_258_, lean_object* v_inst_259_, lean_object* v_M_260_, lean_object* v_n_261_, lean_object* v_X_262_, lean_object* v_i_263_, lean_object* v_a_264_){
_start:
{
lean_object* v_res_265_; 
v_res_265_ = lp_tree_GlobalTheory_CompanionTheory_SW_consTup(v_K_257_, v_inst_258_, v_inst_259_, v_M_260_, v_n_261_, v_X_262_, v_i_263_, v_a_264_);
lean_dec(v_i_263_);
lean_dec(v_n_261_);
return v_res_265_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_UnipotentAdelicQuotients_SiegelWeilUnitaryConvergent(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_CountingDefinitions_AdelicEulerProducts_IsEulerProd(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_UnipotentAdelicQuotients_SiegelWeilUnitaryConvergent(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

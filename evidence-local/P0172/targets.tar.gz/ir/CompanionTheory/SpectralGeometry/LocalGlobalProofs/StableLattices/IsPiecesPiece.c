// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsPiecesPiece
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.RealGroups.UnitaryAdmissibility.ArchimedeanUnitaryDual.StSandwich public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.StableLattices.IsCongIdealTwoTorsion
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter___redArg(lean_object* v_x_1_, lean_object* v_h__1_2_, lean_object* v_h__2_3_, lean_object* v_h__3_4_){
_start:
{
if (lean_obj_tag(v_x_1_) == 0)
{
lean_object* v___x_5_; lean_object* v___x_6_; 
lean_dec(v_h__3_4_);
lean_dec(v_h__1_2_);
v___x_5_ = lean_box(0);
v___x_6_ = lean_apply_1(v_h__2_3_, v___x_5_);
return v___x_6_;
}
else
{
lean_object* v_val_7_; 
lean_dec(v_h__2_3_);
v_val_7_ = lean_ctor_get(v_x_1_, 0);
lean_inc(v_val_7_);
lean_dec_ref_known(v_x_1_, 1);
if (lean_obj_tag(v_val_7_) == 0)
{
lean_object* v_val_8_; lean_object* v___x_9_; 
lean_dec(v_h__3_4_);
v_val_8_ = lean_ctor_get(v_val_7_, 0);
lean_inc(v_val_8_);
lean_dec_ref_known(v_val_7_, 1);
v___x_9_ = lean_apply_1(v_h__1_2_, v_val_8_);
return v___x_9_;
}
else
{
lean_object* v_val_10_; lean_object* v___x_11_; 
lean_dec(v_h__1_2_);
v_val_10_ = lean_ctor_get(v_val_7_, 0);
lean_inc(v_val_10_);
lean_dec_ref_known(v_val_7_, 1);
v___x_11_ = lean_apply_1(v_h__3_4_, v_val_10_);
return v___x_11_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter(lean_object* v_l_12_, lean_object* v_motive_13_, lean_object* v_x_14_, lean_object* v_h__1_15_, lean_object* v_h__2_16_, lean_object* v_h__3_17_){
_start:
{
if (lean_obj_tag(v_x_14_) == 0)
{
lean_object* v___x_18_; lean_object* v___x_19_; 
lean_dec(v_h__3_17_);
lean_dec(v_h__1_15_);
v___x_18_ = lean_box(0);
v___x_19_ = lean_apply_1(v_h__2_16_, v___x_18_);
return v___x_19_;
}
else
{
lean_object* v_val_20_; 
lean_dec(v_h__2_16_);
v_val_20_ = lean_ctor_get(v_x_14_, 0);
lean_inc(v_val_20_);
lean_dec_ref_known(v_x_14_, 1);
if (lean_obj_tag(v_val_20_) == 0)
{
lean_object* v_val_21_; lean_object* v___x_22_; 
lean_dec(v_h__3_17_);
v_val_21_ = lean_ctor_get(v_val_20_, 0);
lean_inc(v_val_21_);
lean_dec_ref_known(v_val_20_, 1);
v___x_22_ = lean_apply_1(v_h__1_15_, v_val_21_);
return v___x_22_;
}
else
{
lean_object* v_val_23_; lean_object* v___x_24_; 
lean_dec(v_h__1_15_);
v_val_23_ = lean_ctor_get(v_val_20_, 0);
lean_inc(v_val_23_);
lean_dec_ref_known(v_val_20_, 1);
v___x_24_ = lean_apply_1(v_h__3_17_, v_val_23_);
return v___x_24_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter___boxed(lean_object* v_l_25_, lean_object* v_motive_26_, lean_object* v_x_27_, lean_object* v_h__1_28_, lean_object* v_h__2_29_, lean_object* v_h__3_30_){
_start:
{
lean_object* v_res_31_; 
v_res_31_ = lp_tree___private_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece_0__GlobalTheory_CompanionTheory_Iwahori_wt_match__1_splitter(v_l_25_, v_motive_26_, v_x_27_, v_h__1_28_, v_h__2_29_, v_h__3_30_);
lean_dec(v_l_25_);
return v_res_31_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_RealGroups_UnitaryAdmissibility_ArchimedeanUnitaryDual_StSandwich(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsCongIdealTwoTorsion(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsPiecesPiece(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_RealGroups_UnitaryAdmissibility_ArchimedeanUnitaryDual_StSandwich(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_StableLattices_IsCongIdealTwoTorsion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

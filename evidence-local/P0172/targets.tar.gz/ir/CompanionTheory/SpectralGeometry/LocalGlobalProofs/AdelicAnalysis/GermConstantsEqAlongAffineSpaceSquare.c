// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.GermConstantsEqAlongAffineSpaceSquare
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.UnipotentAdelicQuotients.SWXSDefs public import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_CommRing_toNonUnitalCommRing___redArg(lean_object*);
lean_object* lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(lean_object*);
lean_object* l_Function_comp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecMul(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecMulVec___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qr___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__0(lean_object* v_00_u03c3_1_, lean_object* v___y_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_apply_1(v_00_u03c3_1_, v___y_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1(lean_object* v_toOne_4_, lean_object* v_x_5_){
_start:
{
lean_inc(v_toOne_4_);
return v_toOne_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1___boxed(lean_object* v_toOne_6_, lean_object* v_x_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1(v_toOne_6_, v_x_7_);
lean_dec(v_x_7_);
lean_dec(v_toOne_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg(lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_00_u03c3_12_, lean_object* v_J_13_, lean_object* v_d_14_, lean_object* v_c_15_, lean_object* v_a_16_, lean_object* v_a_17_){
_start:
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v_toSub_20_; lean_object* v_toSemiring_21_; lean_object* v___x_22_; lean_object* v_toAddMonoidWithOne_23_; lean_object* v_toZero_24_; lean_object* v_toOne_25_; lean_object* v___x_26_; lean_object* v_toMul_27_; lean_object* v___f_28_; lean_object* v___f_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; 
lean_inc_ref(v_inst_9_);
v___x_18_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_9_);
v___x_19_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_18_);
v_toSub_20_ = lean_ctor_get(v___x_19_, 2);
lean_inc(v_toSub_20_);
lean_dec_ref(v___x_19_);
v_toSemiring_21_ = lean_ctor_get(v_inst_9_, 0);
lean_inc_ref_n(v_toSemiring_21_, 2);
v___x_22_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_21_);
v_toAddMonoidWithOne_23_ = lean_ctor_get(v___x_18_, 1);
lean_inc_ref(v_toAddMonoidWithOne_23_);
lean_dec_ref(v___x_18_);
v_toZero_24_ = lean_ctor_get(v___x_22_, 1);
lean_inc(v_toZero_24_);
lean_dec_ref(v___x_22_);
v_toOne_25_ = lean_ctor_get(v_toAddMonoidWithOne_23_, 2);
lean_inc(v_toOne_25_);
lean_dec_ref(v_toAddMonoidWithOne_23_);
v___x_26_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_21_);
v_toMul_27_ = lean_ctor_get(v___x_26_, 0);
lean_inc_n(v_toMul_27_, 2);
lean_dec_ref(v___x_26_);
v___f_28_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__0), 2, 1);
lean_closure_set(v___f_28_, 0, v_00_u03c3_12_);
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_29_, 0, v_toOne_25_);
v___x_30_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v_inst_9_);
lean_dec_ref(v_inst_9_);
v___x_31_ = lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(v___x_30_);
lean_inc(v_d_14_);
v___x_32_ = lean_alloc_closure((void*)(l_Function_comp), 6, 5);
lean_closure_set(v___x_32_, 0, lean_box(0));
lean_closure_set(v___x_32_, 1, lean_box(0));
lean_closure_set(v___x_32_, 2, lean_box(0));
lean_closure_set(v___x_32_, 3, v___f_28_);
lean_closure_set(v___x_32_, 4, v_d_14_);
v___x_33_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecMul), 8, 7);
lean_closure_set(v___x_33_, 0, lean_box(0));
lean_closure_set(v___x_33_, 1, lean_box(0));
lean_closure_set(v___x_33_, 2, lean_box(0));
lean_closure_set(v___x_33_, 3, v___x_31_);
lean_closure_set(v___x_33_, 4, v_inst_10_);
lean_closure_set(v___x_33_, 5, v___x_32_);
lean_closure_set(v___x_33_, 6, v_J_13_);
lean_inc(v_a_17_);
lean_inc(v_a_16_);
v___x_34_ = lp_mathlib_Matrix_diagonal___redArg(v_inst_11_, v_toZero_24_, v___f_29_, v_a_16_, v_a_17_);
v___x_35_ = lp_mathlib_Matrix_vecMulVec___redArg(v_toMul_27_, v_d_14_, v___x_33_, v_a_16_, v_a_17_);
v___x_36_ = lean_apply_2(v_toMul_27_, v_c_15_, v___x_35_);
v___x_37_ = lean_apply_2(v_toSub_20_, v___x_34_, v___x_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat(lean_object* v_A_38_, lean_object* v_inst_39_, lean_object* v_n_40_, lean_object* v_inst_41_, lean_object* v_inst_42_, lean_object* v_00_u03c3_43_, lean_object* v_J_44_, lean_object* v_d_45_, lean_object* v_c_46_, lean_object* v_a_47_, lean_object* v_a_48_){
_start:
{
lean_object* v___x_49_; 
v___x_49_ = lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat___redArg(v_inst_39_, v_inst_41_, v_inst_42_, v_00_u03c3_43_, v_J_44_, v_d_45_, v_c_46_, v_a_47_, v_a_48_);
return v___x_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qr___redArg(lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_inst_52_, lean_object* v_00_u03c3_53_, lean_object* v_J_54_, lean_object* v_d_55_, lean_object* v_c_56_){
_start:
{
lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; 
lean_inc(v_c_56_);
lean_inc(v_d_55_);
lean_inc(v_J_54_);
lean_inc_n(v_00_u03c3_53_, 2);
lean_inc_ref(v_inst_52_);
lean_inc(v_inst_51_);
lean_inc_ref(v_inst_50_);
v___x_57_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat), 11, 9);
lean_closure_set(v___x_57_, 0, lean_box(0));
lean_closure_set(v___x_57_, 1, v_inst_50_);
lean_closure_set(v___x_57_, 2, lean_box(0));
lean_closure_set(v___x_57_, 3, v_inst_51_);
lean_closure_set(v___x_57_, 4, v_inst_52_);
lean_closure_set(v___x_57_, 5, v_00_u03c3_53_);
lean_closure_set(v___x_57_, 6, v_J_54_);
lean_closure_set(v___x_57_, 7, v_d_55_);
lean_closure_set(v___x_57_, 8, v_c_56_);
v___x_58_ = lean_apply_1(v_00_u03c3_53_, v_c_56_);
v___x_59_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qrMat), 11, 9);
lean_closure_set(v___x_59_, 0, lean_box(0));
lean_closure_set(v___x_59_, 1, v_inst_50_);
lean_closure_set(v___x_59_, 2, lean_box(0));
lean_closure_set(v___x_59_, 3, v_inst_51_);
lean_closure_set(v___x_59_, 4, v_inst_52_);
lean_closure_set(v___x_59_, 5, v_00_u03c3_53_);
lean_closure_set(v___x_59_, 6, v_J_54_);
lean_closure_set(v___x_59_, 7, v_d_55_);
lean_closure_set(v___x_59_, 8, v___x_58_);
v___x_60_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_60_, 0, v___x_57_);
lean_ctor_set(v___x_60_, 1, v___x_59_);
return v___x_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qr(lean_object* v_A_61_, lean_object* v_inst_62_, lean_object* v_n_63_, lean_object* v_inst_64_, lean_object* v_inst_65_, lean_object* v_00_u03c3_66_, lean_object* v_J_67_, lean_object* v_h_u03c3_68_, lean_object* v_hJ_69_, lean_object* v_d_70_, lean_object* v_c_71_, lean_object* v_hc_72_){
_start:
{
lean_object* v___x_73_; 
v___x_73_ = lp_tree_GlobalTheory_CompanionTheory_SW_QuasiRefl_qr___redArg(v_inst_62_, v_inst_64_, v_inst_65_, v_00_u03c3_66_, v_J_67_, v_d_70_, v_c_71_);
return v___x_73_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_UnipotentAdelicQuotients_SWXSDefs(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_AdelicAnalysis_GermConstantsEqAlongAffineSpaceSquare(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_UnipotentAdelicQuotients_SWXSDefs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SiegelMatrixSymmetricPosdefImag
// Imports: public import Init public meta import Init public import Mathlib public import CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.SumRhoEqTrace
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
extern lean_object* lp_mathlib_Complex_I;
lean_object* lp_mathlib___private_Mathlib_Data_Real_Basic_0__Real_mul(lean_object*, lean_object*);
lean_object* l_instSMulOfMul___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Complex_mulAux___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib___private_Mathlib_Data_Real_Basic_0__Real_mul, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__0_value;
static const lean_closure_object lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instSMulOfMul___redArg___lam__0, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__0_value)} };
static const lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__1 = (const lean_object*)&lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0(lean_object* v_00_u03c4_4_, lean_object* v_w_5_, lean_object* v_B_6_, lean_object* v_00_u03c1_7_, lean_object* v_P_8_, lean_object* v_i_9_, lean_object* v_j_10_){
_start:
{
lean_object* v___x_11_; lean_object* v_re_12_; lean_object* v_im_13_; lean_object* v___x_14_; lean_object* v_re_15_; lean_object* v_im_16_; lean_object* v___x_17_; lean_object* v_re_18_; lean_object* v_im_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___f_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v_re_27_; lean_object* v_im_28_; lean_object* v_re_29_; lean_object* v_im_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v_re_34_; lean_object* v_im_35_; lean_object* v___x_37_; uint8_t v_isShared_38_; uint8_t v_isSharedCheck_44_; 
lean_inc_n(v_w_5_, 2);
v___x_11_ = lean_apply_1(v_00_u03c4_4_, v_w_5_);
v_re_12_ = lean_ctor_get(v___x_11_, 0);
lean_inc(v_re_12_);
v_im_13_ = lean_ctor_get(v___x_11_, 1);
lean_inc(v_im_13_);
lean_dec_ref(v___x_11_);
v___x_14_ = lp_mathlib_Complex_ofReal(v_re_12_);
v_re_15_ = lean_ctor_get(v___x_14_, 0);
lean_inc(v_re_15_);
v_im_16_ = lean_ctor_get(v___x_14_, 1);
lean_inc(v_im_16_);
lean_dec_ref(v___x_14_);
v___x_17_ = lp_mathlib_Complex_I;
v_re_18_ = lean_ctor_get(v___x_17_, 0);
v_im_19_ = lean_ctor_get(v___x_17_, 1);
lean_inc(v_j_10_);
lean_inc(v_i_9_);
v___x_20_ = lean_apply_2(v_B_6_, v_i_9_, v_j_10_);
v___x_21_ = lean_apply_2(v_00_u03c1_7_, v_w_5_, v___x_20_);
v___x_22_ = lp_mathlib_Complex_ofReal(v___x_21_);
v___f_23_ = ((lean_object*)(lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0___closed__1));
v___x_24_ = lp_mathlib_Complex_mulAux___redArg(v___f_23_, v_re_15_, v_im_16_, v___x_22_);
v___x_25_ = lp_mathlib_Complex_ofReal(v_im_13_);
lean_inc(v_im_19_);
lean_inc(v_re_18_);
v___x_26_ = lp_mathlib_Complex_mulAux___redArg(v___f_23_, v_re_18_, v_im_19_, v___x_25_);
v_re_27_ = lean_ctor_get(v___x_26_, 0);
lean_inc(v_re_27_);
v_im_28_ = lean_ctor_get(v___x_26_, 1);
lean_inc(v_im_28_);
lean_dec_ref(v___x_26_);
v_re_29_ = lean_ctor_get(v___x_24_, 0);
lean_inc(v_re_29_);
v_im_30_ = lean_ctor_get(v___x_24_, 1);
lean_inc(v_im_30_);
lean_dec_ref(v___x_24_);
v___x_31_ = lean_apply_3(v_P_8_, v_w_5_, v_i_9_, v_j_10_);
v___x_32_ = lp_mathlib_Complex_ofReal(v___x_31_);
v___x_33_ = lp_mathlib_Complex_mulAux___redArg(v___f_23_, v_re_27_, v_im_28_, v___x_32_);
v_re_34_ = lean_ctor_get(v___x_33_, 0);
v_im_35_ = lean_ctor_get(v___x_33_, 1);
v_isSharedCheck_44_ = !lean_is_exclusive(v___x_33_);
if (v_isSharedCheck_44_ == 0)
{
v___x_37_ = v___x_33_;
v_isShared_38_ = v_isSharedCheck_44_;
goto v_resetjp_36_;
}
else
{
lean_inc(v_im_35_);
lean_inc(v_re_34_);
lean_dec(v___x_33_);
v___x_37_ = lean_box(0);
v_isShared_38_ = v_isSharedCheck_44_;
goto v_resetjp_36_;
}
v_resetjp_36_:
{
lean_object* v___f_39_; lean_object* v___f_40_; lean_object* v___x_42_; 
v___f_39_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_39_, 0, v_re_29_);
lean_closure_set(v___f_39_, 1, v_re_34_);
v___f_40_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_40_, 0, v_im_30_);
lean_closure_set(v___f_40_, 1, v_im_35_);
if (v_isShared_38_ == 0)
{
lean_ctor_set(v___x_37_, 1, v___f_40_);
lean_ctor_set(v___x_37_, 0, v___f_39_);
v___x_42_ = v___x_37_;
goto v_reusejp_41_;
}
else
{
lean_object* v_reuseFailAlloc_43_; 
v_reuseFailAlloc_43_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_43_, 0, v___f_39_);
lean_ctor_set(v_reuseFailAlloc_43_, 1, v___f_40_);
v___x_42_ = v_reuseFailAlloc_43_;
goto v_reusejp_41_;
}
v_reusejp_41_:
{
return v___x_42_;
}
}
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0(void){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg(lean_object* v_B_46_, lean_object* v_00_u03c1_47_, lean_object* v_P_48_, lean_object* v_00_u03c4_49_, lean_object* v_w_50_, lean_object* v_a_51_, lean_object* v_a_52_){
_start:
{
lean_object* v___x_53_; lean_object* v_toFun_54_; lean_object* v___f_55_; lean_object* v___x_56_; 
v___x_53_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___closed__0);
v_toFun_54_ = lean_ctor_get(v___x_53_, 0);
v___f_55_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg___lam__0), 7, 5);
lean_closure_set(v___f_55_, 0, v_00_u03c4_49_);
lean_closure_set(v___f_55_, 1, v_w_50_);
lean_closure_set(v___f_55_, 2, v_B_46_);
lean_closure_set(v___f_55_, 3, v_00_u03c1_47_);
lean_closure_set(v___f_55_, 4, v_P_48_);
lean_inc(v_toFun_54_);
v___x_56_ = lean_apply_3(v_toFun_54_, v___f_55_, v_a_51_, v_a_52_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB(lean_object* v_F_57_, lean_object* v_inst_58_, lean_object* v_00_u03b9_59_, lean_object* v_W_60_, lean_object* v_B_61_, lean_object* v_00_u03c1_62_, lean_object* v_P_63_, lean_object* v_00_u03c4_64_, lean_object* v_w_65_, lean_object* v_a_66_, lean_object* v_a_67_){
_start:
{
lean_object* v___x_68_; 
v___x_68_ = lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___redArg(v_B_61_, v_00_u03c1_62_, v_P_63_, v_00_u03c4_64_, v_w_65_, v_a_66_, v_a_67_);
return v___x_68_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB___boxed(lean_object* v_F_69_, lean_object* v_inst_70_, lean_object* v_00_u03b9_71_, lean_object* v_W_72_, lean_object* v_B_73_, lean_object* v_00_u03c1_74_, lean_object* v_P_75_, lean_object* v_00_u03c4_76_, lean_object* v_w_77_, lean_object* v_a_78_, lean_object* v_a_79_){
_start:
{
lean_object* v_res_80_; 
v_res_80_ = lp_tree_GlobalTheory_CompanionTheory_SW_ThW_ZB(v_F_69_, v_inst_70_, v_00_u03b9_71_, v_W_72_, v_B_73_, v_00_u03c1_74_, v_P_75_, v_00_u03c4_76_, v_w_77_, v_a_78_, v_a_79_);
lean_dec_ref(v_inst_70_);
return v_res_80_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_AdelicAnalysis_SumRhoEqTrace(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_AdelicAnalysis_SiegelMatrixSymmetricPosdefImag(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_AdelicAnalysis_SumRhoEqTrace(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

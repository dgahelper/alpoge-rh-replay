// Lean compiler output
// Module: CompanionTheory.SpectralGeometry.LocalGlobalProofs.AdelicAnalysis.MapMulEqOfNormOne
// Imports: public import Init public meta import Init public import Formalism.UnipotentAdelicQuotients.SWXSDefs public import Formalism.SharpRestriction.GlobalSchurBounds.GeneralLinearActions.GenusMassVolumes
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__0(lean_object* v_toMul_1_, lean_object* v_u_2_, lean_object* v_y_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_2(v_toMul_1_, v_u_2_, v_y_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__1(lean_object* v_toMul_5_, lean_object* v_v_6_, lean_object* v_y_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lean_apply_2(v_toMul_5_, v_v_6_, v_y_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg(lean_object* v_inst_9_, lean_object* v_u_10_, lean_object* v_v_11_){
_start:
{
lean_object* v_toSemiring_12_; lean_object* v___x_13_; lean_object* v_toMul_14_; lean_object* v___x_16_; uint8_t v_isShared_17_; uint8_t v_isSharedCheck_23_; 
v_toSemiring_12_ = lean_ctor_get(v_inst_9_, 0);
lean_inc_ref(v_toSemiring_12_);
lean_dec_ref(v_inst_9_);
v___x_13_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_12_);
v_toMul_14_ = lean_ctor_get(v___x_13_, 0);
v_isSharedCheck_23_ = !lean_is_exclusive(v___x_13_);
if (v_isSharedCheck_23_ == 0)
{
lean_object* v_unused_24_; 
v_unused_24_ = lean_ctor_get(v___x_13_, 1);
lean_dec(v_unused_24_);
v___x_16_ = v___x_13_;
v_isShared_17_ = v_isSharedCheck_23_;
goto v_resetjp_15_;
}
else
{
lean_inc(v_toMul_14_);
lean_dec(v___x_13_);
v___x_16_ = lean_box(0);
v_isShared_17_ = v_isSharedCheck_23_;
goto v_resetjp_15_;
}
v_resetjp_15_:
{
lean_object* v___f_18_; lean_object* v___f_19_; lean_object* v___x_21_; 
lean_inc(v_toMul_14_);
v___f_18_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__0), 3, 2);
lean_closure_set(v___f_18_, 0, v_toMul_14_);
lean_closure_set(v___f_18_, 1, v_u_10_);
v___f_19_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg___lam__1), 3, 2);
lean_closure_set(v___f_19_, 0, v_toMul_14_);
lean_closure_set(v___f_19_, 1, v_v_11_);
if (v_isShared_17_ == 0)
{
lean_ctor_set(v___x_16_, 1, v___f_19_);
lean_ctor_set(v___x_16_, 0, v___f_18_);
v___x_21_ = v___x_16_;
goto v_reusejp_20_;
}
else
{
lean_object* v_reuseFailAlloc_22_; 
v_reuseFailAlloc_22_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_22_, 0, v___f_18_);
lean_ctor_set(v_reuseFailAlloc_22_, 1, v___f_19_);
v___x_21_ = v_reuseFailAlloc_22_;
goto v_reusejp_20_;
}
v_reusejp_20_:
{
return v___x_21_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv(lean_object* v_K_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_inst_28_, lean_object* v_u_29_, lean_object* v_v_30_, lean_object* v_h_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_mulEquiv___redArg(v_inst_26_, v_u_29_, v_v_30_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg___lam__0(lean_object* v_00_u03c3_33_, lean_object* v___y_34_){
_start:
{
lean_object* v___x_35_; 
v___x_35_ = lean_apply_1(v_00_u03c3_33_, v___y_34_);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg(lean_object* v_00_u03c3_36_){
_start:
{
lean_object* v___f_37_; lean_object* v___x_38_; 
v___f_37_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg___lam__0), 2, 1);
lean_closure_set(v___f_37_, 0, v_00_u03c3_36_);
lean_inc_ref(v___f_37_);
v___x_38_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_38_, 0, v___f_37_);
lean_ctor_set(v___x_38_, 1, v___f_37_);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv(lean_object* v_K_39_, lean_object* v_inst_40_, lean_object* v_inst_41_, lean_object* v_00_u03c3_42_, lean_object* v_hc_43_, lean_object* v_hi_44_){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___redArg(v_00_u03c3_42_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv___boxed(lean_object* v_K_46_, lean_object* v_inst_47_, lean_object* v_inst_48_, lean_object* v_00_u03c3_49_, lean_object* v_hc_50_, lean_object* v_hi_51_){
_start:
{
lean_object* v_res_52_; 
v_res_52_ = lp_tree_GlobalTheory_CompanionTheory_SW_NormOneHaar_invEquiv(v_K_46_, v_inst_47_, v_inst_48_, v_00_u03c3_49_, v_hc_50_, v_hi_51_);
lean_dec_ref(v_inst_47_);
return v_res_52_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_UnipotentAdelicQuotients_SWXSDefs(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_CompanionTheory_SpectralGeometry_LocalGlobalProofs_AdelicAnalysis_MapMulEqOfNormOne(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_UnipotentAdelicQuotients_SWXSDefs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GlobalSchurBounds_GeneralLinearActions_GenusMassVolumes(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

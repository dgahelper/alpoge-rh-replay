// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsProjBundleClosureStatement
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsProjBundleClosure public import Development.AbelianVarietyTheory.Definitions.Degenerations.BaseFacts public import Development.AbelianVarietyTheory.Definitions.Degenerations.IsAffineSplitTorusLeft public import Development.AbelianVarietyTheory.Definitions.Degenerations.CompanionTheory public import Development.AbelianVarietyTheory.Statements.SemistableTorsion.UTorsSt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsProjBundleClosure(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_BaseFacts(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_IsAffineSplitTorusLeft(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_CompanionTheory(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Statements_SemistableTorsion_UTorsSt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsProjBundleClosureStatement(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsProjBundleClosure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_BaseFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_IsAffineSplitTorusLeft(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_CompanionTheory(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Statements_SemistableTorsion_UTorsSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

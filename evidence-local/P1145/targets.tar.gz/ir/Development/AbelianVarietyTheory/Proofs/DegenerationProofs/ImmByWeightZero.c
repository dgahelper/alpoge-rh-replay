// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ImmByWeightZero
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Degenerations.PullChartIsLB public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsUniqueIsRatio public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.EqOfWeightEq public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.CoeffSymmSum public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsBasisUniqueMinAndSumsSeparated public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.IsClosedImmersionBySectionsOfSpanStatement public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsClosedImmersionAbelianPartBundleStatement public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.ExistsPureWeightSectionNeZeroAt public import Development.AbelianVarietyTheory.Proofs.DegenerationProofs.PureSectionRatiosGenerateFunctionsStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_PullChartIsLB(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsUniqueIsRatio(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_EqOfWeightEq(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_CoeffSymmSum(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsBasisUniqueMinAndSumsSeparated(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_IsClosedImmersionBySectionsOfSpanStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsClosedImmersionAbelianPartBundleStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsPureWeightSectionNeZeroAt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_PureSectionRatiosGenerateFunctionsStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ImmByWeightZero(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Degenerations_PullChartIsLB(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsUniqueIsRatio(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_EqOfWeightEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_CoeffSymmSum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsBasisUniqueMinAndSumsSeparated(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_IsClosedImmersionBySectionsOfSpanStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsClosedImmersionAbelianPartBundleStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_ExistsPureWeightSectionNeZeroAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DegenerationProofs_PureSectionRatiosGenerateFunctionsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

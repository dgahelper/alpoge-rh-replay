// Lean compiler output
// Module: Development.AutomorphicArithmetic.AutomorphicVarieties.CurveDVRSpecialization.WeightZeroAlgebraLeEntryAlgebra
// Imports: public import Init public meta import Init public import Development.AutomorphicArithmetic.AutomorphicVarieties.CurveDVRSpecialization.RatTorsionFree public import Development.AutomorphicArithmetic.AutomorphicVarieties.PublishedTheorems.KisinCrTrivial public import Development.AutomorphicArithmetic.AutomorphicVarieties.CurveDVRSpecialization.TriangularOfReducibleRankThree public import Development.AutomorphicArithmetic.AutomorphicVarieties.PadicHodgeTheory.LocGood public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.MopBase public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ConjTor public import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.CoordGrading public import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.PartSpan public import Development.AutomorphicArithmetic.AutomorphicVarieties.CommutativeAlgebra.PointsFinite public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.LocalRingsCompletion.dvrFinite public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.LocalRingsCompletion.DvrIntClosure
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_UpperTheory_V_U3_torGL___redArg(lean_object*, lean_object*);
lean_object* lp_tree_UpperTheory_V_U3_conjBy___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift___redArg(lean_object* v_inst_1_, lean_object* v_r_2_, lean_object* v_t_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_unsigned_to_nat(3u);
lean_inc_ref(v_inst_1_);
v___x_5_ = lp_tree_UpperTheory_V_U3_torGL___redArg(v_inst_1_, v_t_3_);
v___x_6_ = lp_tree_UpperTheory_V_U3_conjBy___redArg(v___x_4_, v_inst_1_, v___x_5_, v_r_2_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift(lean_object* v_O_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_G_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_00_u03b7_13_, lean_object* v_00_u03a8_14_, lean_object* v_R_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_r_19_, lean_object* v_t_20_, lean_object* v_ht_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift___redArg(v_inst_16_, v_r_19_, v_t_20_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift___boxed(lean_object* v_O_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_G_26_, lean_object* v_inst_27_, lean_object* v_inst_28_, lean_object* v_00_u03b7_29_, lean_object* v_00_u03a8_30_, lean_object* v_R_31_, lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_inst_34_, lean_object* v_r_35_, lean_object* v_t_36_, lean_object* v_ht_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra_0__torLift(v_O_23_, v_inst_24_, v_inst_25_, v_G_26_, v_inst_27_, v_inst_28_, v_00_u03b7_29_, v_00_u03a8_30_, v_R_31_, v_inst_32_, v_inst_33_, v_inst_34_, v_r_35_, v_t_36_, v_ht_37_);
lean_dec_ref(v_inst_33_);
lean_dec_ref(v_00_u03a8_30_);
lean_dec_ref(v_00_u03b7_29_);
lean_dec_ref(v_inst_27_);
lean_dec_ref(v_inst_24_);
return v_res_38_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_RatTorsionFree(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PublishedTheorems_KisinCrTrivial(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_TriangularOfReducibleRankThree(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_MopBase(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ConjTor(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_CoordGrading(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_PartSpan(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_PointsFinite(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_LocalRingsCompletion_dvrFinite(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_LocalRingsCompletion_DvrIntClosure(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_WeightZeroAlgebraLeEntryAlgebra(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_RatTorsionFree(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PublishedTheorems_KisinCrTrivial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CurveDVRSpecialization_TriangularOfReducibleRankThree(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_MopBase(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ConjTor(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_CoordGrading(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_PartSpan(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CommutativeAlgebra_PointsFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_LocalRingsCompletion_dvrFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_LocalRingsCompletion_DvrIntClosure(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

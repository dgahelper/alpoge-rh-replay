// Lean compiler output
// Module: Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.VlenLe
// Imports: public import Init public meta import Init public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.KatoUse public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ShaInj public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ModelLower public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.DatFacts public import Development.AutomorphicArithmetic.AutomorphicVarieties.PadicHodgeTheory.LocGood public import Development.AutomorphicArithmetic.AutomorphicVarieties.PrimitiveFrobeniusFixed.QocEquiv public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.KummerTheory.LenDirected public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.SelmerTransport.DvrFacts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ShaInj(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelLower(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PrimitiveFrobeniusFixed_QocEquiv(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_KummerTheory_LenDirected(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_DvrFacts(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_VlenLe(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ShaInj(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelLower(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PrimitiveFrobeniusFixed_QocEquiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_KummerTheory_LenDirected(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_DvrFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

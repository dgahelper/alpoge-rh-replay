// Lean compiler output
// Module: Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ModelEx
// Imports: public import Init public meta import Init public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.KatoUse public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.DatFacts public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.UnivEx public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.UnivQuot public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.LocPres public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ModelOfPres public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.BoxPresOf public import Development.AutomorphicArithmetic.AutomorphicVarieties.PadicHodgeTheory.LocGood public import Development.AutomorphicArithmetic.AutomorphicVarieties.CharacterLevelBounds.ClsFacts public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.SelmerTransport.RamFinite public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.SelmerTransport.DvrFacts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Monoid_toMulOneClass___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
lean_object* lp_mathlib_LinearMap_funLeft___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__0(lean_object* v___x_1_, lean_object* v_toInv_2_, lean_object* v_g_3_, lean_object* v_x_4_){
_start:
{
lean_object* v_toMul_5_; lean_object* v___x_6_; lean_object* v___x_7_; 
v_toMul_5_ = lean_ctor_get(v___x_1_, 1);
lean_inc(v_toMul_5_);
lean_dec_ref(v___x_1_);
v___x_6_ = lean_apply_1(v_toInv_2_, v_g_3_);
v___x_7_ = lean_apply_2(v_toMul_5_, v___x_6_, v_x_4_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__1(lean_object* v___x_8_, lean_object* v_toInv_9_, lean_object* v_g_10_, lean_object* v___y_11_, lean_object* v___y_12_){
_start:
{
lean_object* v___f_13_; lean_object* v___x_14_; 
v___f_13_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__0), 4, 3);
lean_closure_set(v___f_13_, 0, v___x_8_);
lean_closure_set(v___f_13_, 1, v_toInv_9_);
lean_closure_set(v___f_13_, 2, v_g_10_);
v___x_14_ = lp_mathlib_LinearMap_funLeft___redArg___lam__0(v___f_13_, v___y_11_, v___y_12_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg(lean_object* v_inst_15_){
_start:
{
lean_object* v_toMonoid_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v_toInv_19_; lean_object* v___f_20_; 
v_toMonoid_16_ = lean_ctor_get(v_inst_15_, 0);
v___x_17_ = lp_mathlib_Monoid_toMulOneClass___redArg(v_toMonoid_16_);
v___x_18_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v_inst_15_);
v_toInv_19_ = lean_ctor_get(v___x_18_, 1);
lean_inc(v_toInv_19_);
lean_dec_ref(v___x_18_);
v___f_20_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___lam__1), 5, 2);
lean_closure_set(v___f_20_, 0, v___x_17_);
lean_closure_set(v___f_20_, 1, v_toInv_19_);
return v___f_20_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg___boxed(lean_object* v_inst_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg(v_inst_21_);
lean_dec_ref(v_inst_21_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR(lean_object* v_R_23_, lean_object* v_inst_24_, lean_object* v_00_u0393_25_, lean_object* v_inst_26_, lean_object* v_H_27_){
_start:
{
lean_object* v___x_28_; 
v___x_28_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___redArg(v_inst_26_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR___boxed(lean_object* v_R_29_, lean_object* v_inst_30_, lean_object* v_00_u0393_31_, lean_object* v_inst_32_, lean_object* v_H_33_){
_start:
{
lean_object* v_res_34_; 
v_res_34_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx_0__permR(v_R_29_, v_inst_30_, v_00_u0393_31_, v_inst_32_, v_H_33_);
lean_dec_ref(v_inst_32_);
lean_dec_ref(v_inst_30_);
return v_res_34_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_UnivEx(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_UnivQuot(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_LocPres(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelOfPres(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_BoxPresOf(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CharacterLevelBounds_ClsFacts(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_RamFinite(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_DvrFacts(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelEx(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_UnivEx(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_UnivQuot(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_LocPres(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ModelOfPres(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_BoxPresOf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_PadicHodgeTheory_LocGood(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_CharacterLevelBounds_ClsFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_RamFinite(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_SelmerTransport_DvrFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

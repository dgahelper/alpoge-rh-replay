// Lean compiler output
// Module: Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ReducibleThreeDim
// Imports: public import Init public meta import Init public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.KatoUse public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.CoboundaryLemmaNoColumn public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.ExistsUnitPowNe public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.BlochKatoNonpositiveWeight public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.DatFacts public import Development.AutomorphicArithmetic.AutomorphicVarieties.UnitaryThreeGroups.AdRepBaseLiftApply public import Development.AutomorphicArithmetic.AutomorphicVarieties.GaloisLibrary.ClassFieldRamification.KwAbs
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_UpperTheory_V_U3_corner___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Int_instDecidableEq___boxed(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
uint8_t lp_mathlib_Units_instDecidableEq___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddCommGroup___redArg(lean_object*);
lean_object* lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_tree_UpperTheory_V_U3_GG_mat___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecEmpty___boxed(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecCons___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_dotProduct___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* l_Fin_cases___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_UpperTheory_V_U3_adRep___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0;
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1;
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2;
static const lean_closure_object lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_Matrix_vecEmpty___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3 = (const lean_object*)&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3_value;
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___closed__0 = (const lean_object*)&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___closed__0_value;
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0;
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1;
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA(lean_object*, lean_object*);
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0;
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1;
static lean_once_cell_t lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2;
static const lean_closure_object lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1))} };
static const lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__3 = (const lean_object*)&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__3_value;
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_1_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1(void){
_start:
{
lean_object* v___x_2_; lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_2_ = lean_unsigned_to_nat(3u);
v___x_3_ = lean_unsigned_to_nat(0u);
v___x_4_ = lean_nat_mod(v___x_3_, v___x_2_);
return v___x_4_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; 
v___x_5_ = lean_unsigned_to_nat(3u);
v___x_6_ = lean_unsigned_to_nat(2u);
v___x_7_ = lean_nat_mod(v___x_6_, v___x_5_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0(lean_object* v_X_9_, lean_object* v___y_10_, lean_object* v___y_11_){
_start:
{
lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v_toFun_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_12_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0);
v___x_13_ = lean_unsigned_to_nat(0u);
v___x_14_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1);
lean_inc_n(v_X_9_, 3);
v___x_15_ = lean_apply_2(v_X_9_, v___x_14_, v___x_14_);
v___x_16_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2);
v___x_17_ = lean_apply_2(v_X_9_, v___x_14_, v___x_16_);
v___x_18_ = lean_apply_2(v_X_9_, v___x_16_, v___x_14_);
v___x_19_ = lean_apply_2(v_X_9_, v___x_16_, v___x_16_);
v_toFun_20_ = lean_ctor_get(v___x_12_, 0);
v___x_21_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
v___x_22_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_22_, 0, lean_box(0));
lean_closure_set(v___x_22_, 1, v___x_13_);
lean_closure_set(v___x_22_, 2, v___x_17_);
lean_closure_set(v___x_22_, 3, v___x_21_);
v___x_23_ = lean_unsigned_to_nat(1u);
v___x_24_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_24_, 0, lean_box(0));
lean_closure_set(v___x_24_, 1, v___x_23_);
lean_closure_set(v___x_24_, 2, v___x_15_);
lean_closure_set(v___x_24_, 3, v___x_22_);
v___x_25_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_25_, 0, lean_box(0));
lean_closure_set(v___x_25_, 1, v___x_13_);
lean_closure_set(v___x_25_, 2, v___x_19_);
lean_closure_set(v___x_25_, 3, v___x_21_);
v___x_26_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_26_, 0, lean_box(0));
lean_closure_set(v___x_26_, 1, v___x_23_);
lean_closure_set(v___x_26_, 2, v___x_18_);
lean_closure_set(v___x_26_, 3, v___x_25_);
v___x_27_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_27_, 0, lean_box(0));
lean_closure_set(v___x_27_, 1, v___x_13_);
lean_closure_set(v___x_27_, 2, v___x_26_);
lean_closure_set(v___x_27_, 3, v___x_21_);
v___x_28_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_28_, 0, lean_box(0));
lean_closure_set(v___x_28_, 1, v___x_23_);
lean_closure_set(v___x_28_, 2, v___x_24_);
lean_closure_set(v___x_28_, 3, v___x_27_);
lean_inc(v_toFun_20_);
v___x_29_ = lean_apply_3(v_toFun_20_, v___x_28_, v___y_10_, v___y_11_);
return v___x_29_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA(lean_object* v_R_31_, lean_object* v_inst_32_){
_start:
{
lean_object* v___f_33_; 
v___f_33_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___closed__0));
return v___f_33_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___boxed(lean_object* v_R_34_, lean_object* v_inst_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA(v_R_34_, v_inst_35_);
lean_dec_ref(v_inst_35_);
return v_res_36_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; 
v___x_37_ = lean_unsigned_to_nat(2u);
v___x_38_ = lean_unsigned_to_nat(0u);
v___x_39_ = lean_nat_mod(v___x_38_, v___x_37_);
return v___x_39_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_40_ = lean_unsigned_to_nat(2u);
v___x_41_ = lean_unsigned_to_nat(1u);
v___x_42_ = lean_nat_mod(v___x_41_, v___x_40_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0(lean_object* v_toZero_43_, lean_object* v_Y_44_, lean_object* v___y_45_, lean_object* v___y_46_){
_start:
{
lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v_toFun_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; 
v___x_47_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0);
v___x_48_ = lean_unsigned_to_nat(2u);
v___x_49_ = lean_unsigned_to_nat(0u);
v___x_50_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0);
lean_inc_n(v_Y_44_, 3);
v___x_51_ = lean_apply_2(v_Y_44_, v___x_50_, v___x_50_);
v___x_52_ = lean_unsigned_to_nat(1u);
v___x_53_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1);
v___x_54_ = lean_apply_2(v_Y_44_, v___x_50_, v___x_53_);
v___x_55_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
v___x_56_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_56_, 0, lean_box(0));
lean_closure_set(v___x_56_, 1, v___x_49_);
lean_closure_set(v___x_56_, 2, v___x_54_);
lean_closure_set(v___x_56_, 3, v___x_55_);
v___x_57_ = lean_apply_2(v_Y_44_, v___x_53_, v___x_50_);
v___x_58_ = lean_apply_2(v_Y_44_, v___x_53_, v___x_53_);
v_toFun_59_ = lean_ctor_get(v___x_47_, 0);
lean_inc_n(v_toZero_43_, 4);
v___x_60_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_60_, 0, lean_box(0));
lean_closure_set(v___x_60_, 1, v___x_49_);
lean_closure_set(v___x_60_, 2, v_toZero_43_);
lean_closure_set(v___x_60_, 3, v___x_55_);
v___x_61_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_61_, 0, lean_box(0));
lean_closure_set(v___x_61_, 1, v___x_52_);
lean_closure_set(v___x_61_, 2, v_toZero_43_);
lean_closure_set(v___x_61_, 3, v___x_56_);
v___x_62_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_62_, 0, lean_box(0));
lean_closure_set(v___x_62_, 1, v___x_48_);
lean_closure_set(v___x_62_, 2, v___x_51_);
lean_closure_set(v___x_62_, 3, v___x_61_);
v___x_63_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_63_, 0, lean_box(0));
lean_closure_set(v___x_63_, 1, v___x_52_);
lean_closure_set(v___x_63_, 2, v_toZero_43_);
lean_closure_set(v___x_63_, 3, v___x_60_);
v___x_64_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_64_, 0, lean_box(0));
lean_closure_set(v___x_64_, 1, v___x_48_);
lean_closure_set(v___x_64_, 2, v_toZero_43_);
lean_closure_set(v___x_64_, 3, v___x_63_);
v___x_65_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_65_, 0, lean_box(0));
lean_closure_set(v___x_65_, 1, v___x_49_);
lean_closure_set(v___x_65_, 2, v___x_58_);
lean_closure_set(v___x_65_, 3, v___x_55_);
v___x_66_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_66_, 0, lean_box(0));
lean_closure_set(v___x_66_, 1, v___x_52_);
lean_closure_set(v___x_66_, 2, v_toZero_43_);
lean_closure_set(v___x_66_, 3, v___x_65_);
v___x_67_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_67_, 0, lean_box(0));
lean_closure_set(v___x_67_, 1, v___x_48_);
lean_closure_set(v___x_67_, 2, v___x_57_);
lean_closure_set(v___x_67_, 3, v___x_66_);
v___x_68_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_68_, 0, lean_box(0));
lean_closure_set(v___x_68_, 1, v___x_49_);
lean_closure_set(v___x_68_, 2, v___x_67_);
lean_closure_set(v___x_68_, 3, v___x_55_);
v___x_69_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_69_, 0, lean_box(0));
lean_closure_set(v___x_69_, 1, v___x_52_);
lean_closure_set(v___x_69_, 2, v___x_64_);
lean_closure_set(v___x_69_, 3, v___x_68_);
v___x_70_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_70_, 0, lean_box(0));
lean_closure_set(v___x_70_, 1, v___x_48_);
lean_closure_set(v___x_70_, 2, v___x_62_);
lean_closure_set(v___x_70_, 3, v___x_69_);
lean_inc(v_toFun_59_);
v___x_71_ = lean_apply_3(v_toFun_59_, v___x_70_, v___y_45_, v___y_46_);
return v___x_71_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg(lean_object* v_inst_72_){
_start:
{
lean_object* v_toSemiring_73_; lean_object* v___x_74_; lean_object* v_toZero_75_; lean_object* v___f_76_; 
v_toSemiring_73_ = lean_ctor_get(v_inst_72_, 0);
lean_inc_ref(v_toSemiring_73_);
lean_dec_ref(v_inst_72_);
v___x_74_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_73_);
v_toZero_75_ = lean_ctor_get(v___x_74_, 1);
lean_inc(v_toZero_75_);
lean_dec_ref(v___x_74_);
v___f_76_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0), 4, 1);
lean_closure_set(v___f_76_, 0, v_toZero_75_);
return v___f_76_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA(lean_object* v_R_77_, lean_object* v_inst_78_){
_start:
{
lean_object* v___x_79_; 
v___x_79_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg(v_inst_78_);
return v___x_79_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; 
v___x_80_ = lean_unsigned_to_nat(3u);
v___x_81_ = lean_unsigned_to_nat(1u);
v___x_82_ = lean_nat_mod(v___x_81_, v___x_80_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0(lean_object* v_toMul_83_, lean_object* v_t_84_, lean_object* v_toAdd_85_, lean_object* v_toSub_86_, lean_object* v_X_87_, lean_object* v___y_88_){
_start:
{
lean_object* v___x_89_; lean_object* v___x_90_; lean_object* v___x_91_; lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_89_ = lean_unsigned_to_nat(0u);
v___x_90_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__1);
v___x_91_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0);
lean_inc_n(v_X_87_, 3);
v___x_92_ = lean_apply_2(v_X_87_, v___x_90_, v___x_91_);
v___x_93_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__2);
v___x_94_ = lean_apply_2(v_X_87_, v___x_91_, v___x_93_);
lean_inc(v_toMul_83_);
lean_inc(v_t_84_);
v___x_95_ = lean_apply_2(v_toMul_83_, v_t_84_, v___x_94_);
v___x_96_ = lean_apply_2(v_toAdd_85_, v___x_92_, v___x_95_);
v___x_97_ = lean_apply_2(v_X_87_, v___x_93_, v___x_91_);
v___x_98_ = lean_apply_2(v_X_87_, v___x_91_, v___x_90_);
v___x_99_ = lean_apply_2(v_toMul_83_, v_t_84_, v___x_98_);
v___x_100_ = lean_apply_2(v_toSub_86_, v___x_97_, v___x_99_);
v___x_101_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
v___x_102_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_102_, 0, lean_box(0));
lean_closure_set(v___x_102_, 1, v___x_89_);
lean_closure_set(v___x_102_, 2, v___x_100_);
lean_closure_set(v___x_102_, 3, v___x_101_);
v___x_103_ = l_Fin_cases___redArg(v___x_96_, v___x_102_, v___y_88_);
lean_dec(v___x_96_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___boxed(lean_object* v_toMul_104_, lean_object* v_t_105_, lean_object* v_toAdd_106_, lean_object* v_toSub_107_, lean_object* v_X_108_, lean_object* v___y_109_){
_start:
{
lean_object* v_res_110_; 
v_res_110_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0(v_toMul_104_, v_t_105_, v_toAdd_106_, v_toSub_107_, v_X_108_, v___y_109_);
lean_dec(v___y_109_);
return v_res_110_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg(lean_object* v_inst_111_, lean_object* v_t_112_){
_start:
{
lean_object* v_toSemiring_113_; lean_object* v___x_114_; lean_object* v_toMul_115_; lean_object* v_toAdd_116_; lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v_toSub_119_; lean_object* v___f_120_; 
v_toSemiring_113_ = lean_ctor_get(v_inst_111_, 0);
lean_inc_ref(v_toSemiring_113_);
v___x_114_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_113_);
v_toMul_115_ = lean_ctor_get(v___x_114_, 0);
lean_inc(v_toMul_115_);
v_toAdd_116_ = lean_ctor_get(v___x_114_, 1);
lean_inc(v_toAdd_116_);
lean_dec_ref(v___x_114_);
v___x_117_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_111_);
v___x_118_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_117_);
lean_dec_ref(v___x_117_);
v_toSub_119_ = lean_ctor_get(v___x_118_, 2);
lean_inc(v_toSub_119_);
lean_dec_ref(v___x_118_);
v___f_120_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___boxed), 6, 4);
lean_closure_set(v___f_120_, 0, v_toMul_115_);
lean_closure_set(v___f_120_, 1, v_t_112_);
lean_closure_set(v___f_120_, 2, v_toAdd_116_);
lean_closure_set(v___f_120_, 3, v_toSub_119_);
return v___f_120_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB(lean_object* v_R_121_, lean_object* v_inst_122_, lean_object* v_t_123_){
_start:
{
lean_object* v___x_124_; 
v___x_124_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg(v_inst_122_, v_t_123_);
return v___x_124_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg___lam__0(lean_object* v_toZero_125_, lean_object* v_toMul_126_, lean_object* v_t_127_, lean_object* v_toNeg_128_, lean_object* v_v_129_, lean_object* v___y_130_, lean_object* v___y_131_){
_start:
{
lean_object* v___x_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v_toFun_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; 
v___x_132_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0);
v___x_133_ = lean_unsigned_to_nat(2u);
v___x_134_ = lean_unsigned_to_nat(0u);
v___x_135_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__0);
lean_inc(v_v_129_);
v___x_136_ = lean_apply_1(v_v_129_, v___x_135_);
v_toFun_137_ = lean_ctor_get(v___x_132_, 0);
v___x_138_ = lean_unsigned_to_nat(1u);
v___x_139_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
lean_inc_n(v_toZero_125_, 3);
v___x_140_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_140_, 0, lean_box(0));
lean_closure_set(v___x_140_, 1, v___x_134_);
lean_closure_set(v___x_140_, 2, v_toZero_125_);
lean_closure_set(v___x_140_, 3, v___x_139_);
lean_inc_ref(v___x_140_);
lean_inc(v___x_136_);
v___x_141_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_141_, 0, lean_box(0));
lean_closure_set(v___x_141_, 1, v___x_138_);
lean_closure_set(v___x_141_, 2, v___x_136_);
lean_closure_set(v___x_141_, 3, v___x_140_);
v___x_142_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg___lam__0___closed__1);
v___x_143_ = lean_apply_1(v_v_129_, v___x_142_);
lean_inc(v_toMul_126_);
lean_inc(v___x_143_);
lean_inc(v_t_127_);
v___x_144_ = lean_apply_2(v_toMul_126_, v_t_127_, v___x_143_);
v___x_145_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_145_, 0, lean_box(0));
lean_closure_set(v___x_145_, 1, v___x_133_);
lean_closure_set(v___x_145_, 2, v_toZero_125_);
lean_closure_set(v___x_145_, 3, v___x_141_);
v___x_146_ = lean_apply_1(v_toNeg_128_, v___x_144_);
v___x_147_ = lean_apply_2(v_toMul_126_, v_t_127_, v___x_136_);
v___x_148_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_148_, 0, lean_box(0));
lean_closure_set(v___x_148_, 1, v___x_134_);
lean_closure_set(v___x_148_, 2, v___x_147_);
lean_closure_set(v___x_148_, 3, v___x_139_);
v___x_149_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_149_, 0, lean_box(0));
lean_closure_set(v___x_149_, 1, v___x_138_);
lean_closure_set(v___x_149_, 2, v_toZero_125_);
lean_closure_set(v___x_149_, 3, v___x_148_);
v___x_150_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_150_, 0, lean_box(0));
lean_closure_set(v___x_150_, 1, v___x_133_);
lean_closure_set(v___x_150_, 2, v___x_146_);
lean_closure_set(v___x_150_, 3, v___x_149_);
v___x_151_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_151_, 0, lean_box(0));
lean_closure_set(v___x_151_, 1, v___x_138_);
lean_closure_set(v___x_151_, 2, v___x_143_);
lean_closure_set(v___x_151_, 3, v___x_140_);
v___x_152_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_152_, 0, lean_box(0));
lean_closure_set(v___x_152_, 1, v___x_133_);
lean_closure_set(v___x_152_, 2, v_toZero_125_);
lean_closure_set(v___x_152_, 3, v___x_151_);
v___x_153_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_153_, 0, lean_box(0));
lean_closure_set(v___x_153_, 1, v___x_134_);
lean_closure_set(v___x_153_, 2, v___x_152_);
lean_closure_set(v___x_153_, 3, v___x_139_);
v___x_154_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_154_, 0, lean_box(0));
lean_closure_set(v___x_154_, 1, v___x_138_);
lean_closure_set(v___x_154_, 2, v___x_150_);
lean_closure_set(v___x_154_, 3, v___x_153_);
v___x_155_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_155_, 0, lean_box(0));
lean_closure_set(v___x_155_, 1, v___x_133_);
lean_closure_set(v___x_155_, 2, v___x_145_);
lean_closure_set(v___x_155_, 3, v___x_154_);
lean_inc(v_toFun_137_);
v___x_156_ = lean_apply_3(v_toFun_137_, v___x_155_, v___y_130_, v___y_131_);
return v___x_156_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg(lean_object* v_inst_157_, lean_object* v_t_158_){
_start:
{
lean_object* v_toSemiring_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v_toZero_162_; lean_object* v___x_163_; lean_object* v_toNeg_164_; lean_object* v___x_165_; lean_object* v_toMul_166_; lean_object* v___f_167_; 
v_toSemiring_159_ = lean_ctor_get(v_inst_157_, 0);
lean_inc_ref_n(v_toSemiring_159_, 2);
v___x_160_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_inst_157_);
lean_dec_ref(v_inst_157_);
v___x_161_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_159_);
v_toZero_162_ = lean_ctor_get(v___x_161_, 1);
lean_inc(v_toZero_162_);
lean_dec_ref(v___x_161_);
v___x_163_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_160_);
lean_dec_ref(v___x_160_);
v_toNeg_164_ = lean_ctor_get(v___x_163_, 1);
lean_inc(v_toNeg_164_);
lean_dec_ref(v___x_163_);
v___x_165_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_159_);
v_toMul_166_ = lean_ctor_get(v___x_165_, 0);
lean_inc(v_toMul_166_);
lean_dec_ref(v___x_165_);
v___f_167_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg___lam__0), 7, 4);
lean_closure_set(v___f_167_, 0, v_toZero_162_);
lean_closure_set(v___f_167_, 1, v_toMul_166_);
lean_closure_set(v___f_167_, 2, v_t_158_);
lean_closure_set(v___f_167_, 3, v_toNeg_164_);
return v___f_167_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB(lean_object* v_R_168_, lean_object* v_inst_169_, lean_object* v_t_170_){
_start:
{
lean_object* v___x_171_; 
v___x_171_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sB___redArg(v_inst_169_, v_t_170_);
return v___x_171_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg___lam__0(lean_object* v_toZero_172_, lean_object* v_X_173_, lean_object* v___y_174_, lean_object* v___y_175_){
_start:
{
lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v_toFun_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; lean_object* v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; lean_object* v___x_189_; lean_object* v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; 
v___x_176_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__0);
v___x_177_ = lean_unsigned_to_nat(1u);
v___x_178_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pB___redArg___lam__0___closed__0);
v___x_179_ = lean_apply_2(v_X_173_, v___x_178_, v___x_178_);
v_toFun_180_ = lean_ctor_get(v___x_176_, 0);
v___x_181_ = lean_unsigned_to_nat(0u);
v___x_182_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
lean_inc_n(v_toZero_172_, 3);
v___x_183_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_183_, 0, lean_box(0));
lean_closure_set(v___x_183_, 1, v___x_181_);
lean_closure_set(v___x_183_, 2, v_toZero_172_);
lean_closure_set(v___x_183_, 3, v___x_182_);
lean_inc_ref(v___x_183_);
v___x_184_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_184_, 0, lean_box(0));
lean_closure_set(v___x_184_, 1, v___x_177_);
lean_closure_set(v___x_184_, 2, v_toZero_172_);
lean_closure_set(v___x_184_, 3, v___x_183_);
v___x_185_ = lean_unsigned_to_nat(2u);
v___x_186_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_186_, 0, lean_box(0));
lean_closure_set(v___x_186_, 1, v___x_185_);
lean_closure_set(v___x_186_, 2, v_toZero_172_);
lean_closure_set(v___x_186_, 3, v___x_184_);
v___x_187_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_187_, 0, lean_box(0));
lean_closure_set(v___x_187_, 1, v___x_177_);
lean_closure_set(v___x_187_, 2, v___x_179_);
lean_closure_set(v___x_187_, 3, v___x_183_);
v___x_188_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_188_, 0, lean_box(0));
lean_closure_set(v___x_188_, 1, v___x_185_);
lean_closure_set(v___x_188_, 2, v_toZero_172_);
lean_closure_set(v___x_188_, 3, v___x_187_);
lean_inc_ref(v___x_186_);
v___x_189_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_189_, 0, lean_box(0));
lean_closure_set(v___x_189_, 1, v___x_181_);
lean_closure_set(v___x_189_, 2, v___x_186_);
lean_closure_set(v___x_189_, 3, v___x_182_);
v___x_190_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_190_, 0, lean_box(0));
lean_closure_set(v___x_190_, 1, v___x_177_);
lean_closure_set(v___x_190_, 2, v___x_188_);
lean_closure_set(v___x_190_, 3, v___x_189_);
v___x_191_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_191_, 0, lean_box(0));
lean_closure_set(v___x_191_, 1, v___x_185_);
lean_closure_set(v___x_191_, 2, v___x_186_);
lean_closure_set(v___x_191_, 3, v___x_190_);
lean_inc(v_toFun_180_);
v___x_192_ = lean_apply_3(v_toFun_180_, v___x_191_, v___y_174_, v___y_175_);
return v___x_192_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg(lean_object* v_inst_193_){
_start:
{
lean_object* v_toSemiring_194_; lean_object* v___x_195_; lean_object* v_toZero_196_; lean_object* v___f_197_; 
v_toSemiring_194_ = lean_ctor_get(v_inst_193_, 0);
lean_inc_ref(v_toSemiring_194_);
lean_dec_ref(v_inst_193_);
v___x_195_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_194_);
v_toZero_196_ = lean_ctor_get(v___x_195_, 1);
lean_inc(v_toZero_196_);
lean_dec_ref(v___x_195_);
v___f_197_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg___lam__0), 4, 1);
lean_closure_set(v___f_197_, 0, v_toZero_196_);
return v___f_197_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC(lean_object* v_R_198_, lean_object* v_inst_199_){
_start:
{
lean_object* v___x_200_; 
v___x_200_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pC___redArg(v_inst_199_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__0(lean_object* v___x_201_, lean_object* v_a_202_, lean_object* v_j_203_){
_start:
{
lean_object* v___x_204_; 
v___x_204_ = lp_tree_UpperTheory_V_U3_corner___redArg(v___x_201_, v_a_202_, v_j_203_);
return v___x_204_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__1(lean_object* v___x_205_, lean_object* v_toZero_206_, lean_object* v___x_207_, lean_object* v_a_208_, lean_object* v_j_209_){
_start:
{
lean_object* v___x_210_; 
v___x_210_ = lp_mathlib_Matrix_diagonal___redArg(v___x_205_, v_toZero_206_, v___x_207_, v_j_209_, v_a_208_);
return v___x_210_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0(void){
_start:
{
lean_object* v___x_211_; lean_object* v___x_212_; 
v___x_211_ = lean_unsigned_to_nat(1u);
v___x_212_ = lean_nat_to_int(v___x_211_);
return v___x_212_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1(void){
_start:
{
lean_object* v___x_213_; lean_object* v___x_214_; 
v___x_213_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__0);
v___x_214_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_214_, 0, v___x_213_);
lean_ctor_set(v___x_214_, 1, v___x_213_);
return v___x_214_;
}
}
static lean_object* _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2(void){
_start:
{
lean_object* v___x_215_; lean_object* v___x_216_; 
v___x_215_ = lean_unsigned_to_nat(2u);
v___x_216_ = l_List_finRange(v___x_215_);
return v___x_216_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg(lean_object* v_inst_219_, lean_object* v_x_220_, lean_object* v_a_221_, lean_object* v_a_222_){
_start:
{
lean_object* v_right_223_; lean_object* v___x_224_; lean_object* v___x_225_; lean_object* v___x_226_; uint8_t v___x_227_; 
v_right_223_ = lean_ctor_get(v_x_220_, 1);
v___x_224_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
v___x_225_ = lean_unsigned_to_nat(1u);
v___x_226_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__1);
lean_inc(v_right_223_);
v___x_227_ = lp_mathlib_Units_instDecidableEq___redArg(v___x_224_, v_right_223_, v___x_226_);
if (v___x_227_ == 0)
{
lean_object* v_toSemiring_228_; lean_object* v___x_229_; lean_object* v_toMul_230_; lean_object* v_toAddCommMonoid_231_; lean_object* v___x_232_; lean_object* v_toZero_233_; lean_object* v___x_234_; lean_object* v___x_235_; lean_object* v_toNeg_236_; lean_object* v___x_237_; lean_object* v_toAddMonoidWithOne_238_; lean_object* v_toOne_239_; lean_object* v___x_240_; lean_object* v___x_241_; lean_object* v___x_242_; lean_object* v___f_243_; lean_object* v___x_244_; lean_object* v___x_245_; lean_object* v___x_246_; lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___f_250_; lean_object* v___x_251_; 
v_toSemiring_228_ = lean_ctor_get(v_inst_219_, 0);
lean_inc_ref_n(v_toSemiring_228_, 2);
v___x_229_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_228_);
v_toMul_230_ = lean_ctor_get(v___x_229_, 0);
lean_inc(v_toMul_230_);
lean_dec_ref(v___x_229_);
v_toAddCommMonoid_231_ = lean_ctor_get(v_toSemiring_228_, 0);
lean_inc_ref(v_toAddCommMonoid_231_);
v___x_232_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_228_);
v_toZero_233_ = lean_ctor_get(v___x_232_, 1);
lean_inc(v_toZero_233_);
lean_dec_ref(v___x_232_);
v___x_234_ = lp_mathlib_Ring_toAddCommGroup___redArg(v_inst_219_);
v___x_235_ = lp_mathlib_SubNegZeroMonoid_toNegZeroClass___redArg(v___x_234_);
lean_dec_ref(v___x_234_);
v_toNeg_236_ = lean_ctor_get(v___x_235_, 1);
lean_inc(v_toNeg_236_);
lean_dec_ref(v___x_235_);
lean_inc_ref(v_inst_219_);
v___x_237_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_219_);
v_toAddMonoidWithOne_238_ = lean_ctor_get(v___x_237_, 1);
lean_inc_ref(v_toAddMonoidWithOne_238_);
lean_dec_ref(v___x_237_);
v_toOne_239_ = lean_ctor_get(v_toAddMonoidWithOne_238_, 2);
lean_inc_n(v_toOne_239_, 2);
lean_dec_ref(v_toAddMonoidWithOne_238_);
v___x_240_ = lean_obj_once(&lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2, &lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2_once, _init_lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__2);
v___x_241_ = lean_unsigned_to_nat(3u);
v___x_242_ = lean_alloc_closure((void*)(lp_tree_UpperTheory_V_U3_GG_mat___boxed), 6, 4);
lean_closure_set(v___x_242_, 0, v___x_241_);
lean_closure_set(v___x_242_, 1, lean_box(0));
lean_closure_set(v___x_242_, 2, v_inst_219_);
lean_closure_set(v___x_242_, 3, v_x_220_);
v___f_243_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__0), 3, 2);
lean_closure_set(v___f_243_, 0, v___x_242_);
lean_closure_set(v___f_243_, 1, v_a_221_);
v___x_244_ = lean_unsigned_to_nat(0u);
v___x_245_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___closed__3));
v___x_246_ = lean_apply_1(v_toNeg_236_, v_toOne_239_);
v___x_247_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___lam__0___closed__3));
v___x_248_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_248_, 0, lean_box(0));
lean_closure_set(v___x_248_, 1, v___x_244_);
lean_closure_set(v___x_248_, 2, v_toOne_239_);
lean_closure_set(v___x_248_, 3, v___x_247_);
v___x_249_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_vecCons___boxed), 5, 4);
lean_closure_set(v___x_249_, 0, lean_box(0));
lean_closure_set(v___x_249_, 1, v___x_225_);
lean_closure_set(v___x_249_, 2, v___x_246_);
lean_closure_set(v___x_249_, 3, v___x_248_);
v___f_250_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg___lam__1), 5, 4);
lean_closure_set(v___f_250_, 0, v___x_245_);
lean_closure_set(v___f_250_, 1, v_toZero_233_);
lean_closure_set(v___f_250_, 2, v___x_249_);
lean_closure_set(v___f_250_, 3, v_a_222_);
v___x_251_ = lp_mathlib_dotProduct___redArg(v___x_240_, v_toMul_230_, v_toAddCommMonoid_231_, v___f_243_, v___f_250_);
lean_dec_ref(v_toAddCommMonoid_231_);
return v___x_251_;
}
else
{
lean_object* v___x_252_; lean_object* v___x_253_; lean_object* v___x_254_; 
v___x_252_ = lean_unsigned_to_nat(3u);
v___x_253_ = lean_alloc_closure((void*)(lp_tree_UpperTheory_V_U3_GG_mat___boxed), 6, 4);
lean_closure_set(v___x_253_, 0, v___x_252_);
lean_closure_set(v___x_253_, 1, lean_box(0));
lean_closure_set(v___x_253_, 2, v_inst_219_);
lean_closure_set(v___x_253_, 3, v_x_220_);
v___x_254_ = lp_tree_UpperTheory_V_U3_corner___redArg(v___x_253_, v_a_221_, v_a_222_);
return v___x_254_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf(lean_object* v_R_255_, lean_object* v_inst_256_, lean_object* v_x_257_, lean_object* v_a_258_, lean_object* v_a_259_){
_start:
{
lean_object* v___x_260_; 
v___x_260_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_wOf___redArg(v_inst_256_, v_x_257_, v_a_258_, v_a_259_);
return v___x_260_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg___lam__0(lean_object* v_inst_261_, lean_object* v_r_262_, lean_object* v_g_263_, lean_object* v___y_264_, lean_object* v___y_265_, lean_object* v___y_266_){
_start:
{
lean_object* v___f_267_; lean_object* v___x_268_; lean_object* v___x_86__overap_269_; lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___f_272_; lean_object* v___x_89__overap_273_; lean_object* v___x_274_; 
v___f_267_ = ((lean_object*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_pA___closed__0));
v___x_268_ = lean_unsigned_to_nat(3u);
lean_inc_ref(v_inst_261_);
v___x_86__overap_269_ = lp_tree_UpperTheory_V_U3_adRep___redArg(v___x_268_, v_inst_261_, v_r_262_);
v___x_270_ = lean_apply_1(v___x_86__overap_269_, v_g_263_);
v___x_271_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_sA___redArg(v_inst_261_);
v___f_272_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_272_, 0, v___x_271_);
lean_closure_set(v___f_272_, 1, v___x_270_);
v___x_89__overap_273_ = lp_mathlib_LinearMap_comp___redArg___lam__0(v___f_272_, v___f_267_, v___y_264_);
v___x_274_ = lean_apply_2(v___x_89__overap_273_, v___y_265_, v___y_266_);
return v___x_274_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg(lean_object* v_inst_275_, lean_object* v_r_276_){
_start:
{
lean_object* v___f_277_; 
v___f_277_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg___lam__0), 6, 2);
lean_closure_set(v___f_277_, 0, v_inst_275_);
lean_closure_set(v___f_277_, 1, v_r_276_);
return v___f_277_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA(lean_object* v_R_278_, lean_object* v_inst_279_, lean_object* v_00_u0393_280_, lean_object* v_inst_281_, lean_object* v_r_282_, lean_object* v_hr_283_){
_start:
{
lean_object* v___f_284_; 
v___f_284_ = lean_alloc_closure((void*)(lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___redArg___lam__0), 6, 2);
lean_closure_set(v___f_284_, 0, v_inst_279_);
lean_closure_set(v___f_284_, 1, v_r_282_);
return v___f_284_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA___boxed(lean_object* v_R_285_, lean_object* v_inst_286_, lean_object* v_00_u0393_287_, lean_object* v_inst_288_, lean_object* v_r_289_, lean_object* v_hr_290_){
_start:
{
lean_object* v_res_291_; 
v_res_291_ = lp_tree___private_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim_0__UpperTheory_V_U3_ReducibleThreeDim_repA(v_R_285_, v_inst_286_, v_00_u0393_287_, v_inst_288_, v_r_289_, v_hr_290_);
lean_dec_ref(v_inst_288_);
return v_res_291_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_CoboundaryLemmaNoColumn(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ExistsUnitPowNe(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_BlochKatoNonpositiveWeight(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_AdRepBaseLiftApply(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_ClassFieldRamification_KwAbs(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ReducibleThreeDim(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_KatoUse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_CoboundaryLemmaNoColumn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_ExistsUnitPowNe(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_BlochKatoNonpositiveWeight(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_DatFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_UnitaryThreeGroups_AdRepBaseLiftApply(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_AutomorphicVarieties_GaloisLibrary_ClassFieldRamification_KwAbs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

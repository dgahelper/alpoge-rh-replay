// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.ThetaFunctionProdConjEqOfHeisenbergFixedStatement
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ThetaFunctionProdConjEqOfHeisenbergFixed public import Mathlib public import Development.AbelianVarietyTheory.Definitions.Divisors.DiscreteSeriesHermitianUnique public import Formalism.LocalToGlobal.IndefiniteReal.LocalNewformFunction public import Formalism.LocalToGlobal.BesselHermitianTheta.TiedSmooth public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.HeisThetaLaws public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.WeilRepLatticeStabilizerVacuumEqDetCharSmul public import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.HomSymplecticHalfFormAlgebraicLawsContinuous
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ThetaFunctionProdConjEqOfHeisenbergFixed(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_DiscreteSeriesHermitianUnique(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_LocalNewformFunction(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_TiedSmooth(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_HeisThetaLaws(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_WeilRepLatticeStabilizerVacuumEqDetCharSmul(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_HomSymplecticHalfFormAlgebraicLawsContinuous(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ThetaFunctionProdConjEqOfHeisenbergFixedStatement(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ThetaFunctionProdConjEqOfHeisenbergFixed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_DiscreteSeriesHermitianUnique(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_LocalNewformFunction(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_BesselHermitianTheta_TiedSmooth(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_HeisThetaLaws(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_WeilRepLatticeStabilizerVacuumEqDetCharSmul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_HomSymplecticHalfFormAlgebraicLawsContinuous(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.TruncationFamilyPlaceAdditive
// Imports: public import Init public meta import Init public import Development.AbelianVarietyTheory.Definitions.Divisors.HasTypeVec public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.LabesseWaldspurger public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ConstantTermVanishing public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.AdjointRadical public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.CuspidalNoRadicalFixed public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.StandardMaximalParabolic public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.CentralizerTensorForms public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.IwasawaDecompositionAdelicStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_HasTypeVec(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_LabesseWaldspurger(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_ConstantTermVanishing(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_AdjointRadical(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_CuspidalNoRadicalFixed(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_StandardMaximalParabolic(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_CentralizerTensorForms(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_IwasawaDecompositionAdelicStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_TruncationFamilyPlaceAdditive(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_Divisors_HasTypeVec(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_LabesseWaldspurger(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_ConstantTermVanishing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_AdjointRadical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_CuspidalNoRadicalFixed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_StandardMaximalParabolic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_CentralizerTensorForms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_IwasawaDecompositionAdelicStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

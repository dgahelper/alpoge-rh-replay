// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.SectionModuleBoundedDenominator
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Statements.GeometryStatements.KeyBadSt public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsThetaMeanSquareNorm public import Development.AutomorphicSpectrum.Statements.GeometryStatements.ZhangDimensionPushDownGrassmannianHeightBounds public import GroundTheory.HeightsAndTheta.Heights.KernelsLattice public import GroundTheory.HeightsAndTheta.Heights.LatticeLemmas.StatementsBundles public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.LeWchartOne public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.EqZeroOfSmulEqZero public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.PrecompleteBases.PsbLb public import Development.AbelianVarietyTheory.Proofs.AbelianSchemeLawProofs.IsIntegralOfSmoothFieldOfConnectedSpace
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_KeyBadSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsThetaMeanSquareNorm(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsLattice(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_LatticeLemmas_StatementsBundles(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LeWchartOne(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_EqZeroOfSmulEqZero(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_SemiabelianSchemes_PrecompleteBases_PsbLb(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_AbelianSchemeLawProofs_IsIntegralOfSmoothFieldOfConnectedSpace(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_SectionModuleBoundedDenominator(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_KeyBadSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsThetaMeanSquareNorm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsLattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_LatticeLemmas_StatementsBundles(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LeWchartOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_EqZeroOfSmulEqZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_SemiabelianSchemes_PrecompleteBases_PsbLb(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_AbelianSchemeLawProofs_IsIntegralOfSmoothFieldOfConnectedSpace(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

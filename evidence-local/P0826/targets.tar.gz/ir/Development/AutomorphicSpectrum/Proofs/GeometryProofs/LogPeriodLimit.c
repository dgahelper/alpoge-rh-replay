// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.LogPeriodLimit
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.SlopeBoundSt public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ArchBetween public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.BdryChart public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ClopenCondOnto public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.UniformisationConclusion public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.HeckeKer public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.BlowupProjections.BlowupProjStatement public import Development.AbelianVarietyTheory.PublishedTheorems.SemiabelianTori.GeometricallyConnectedSplitTorusAff public import GroundTheory.HeightsAndTheta.Heights.Regularisation.Assembly public import GroundTheory.HeightsAndTheta.Heights.Regularisation.PRiemannExtensionSlices public import GroundTheory.HeightsAndTheta.Heights.Regularisation.PPuncturedExpOrder public import GroundTheory.HeightsAndTheta.Heights.Regularisation.PLogCoverDescent public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ImLowerOnKernel public import Development.AutomorphicSpectrum.Proofs.AlgebraProofs.ExistsAdaptedUnimodular public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SymplecticPolydiscPeriodBasisStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.SiegelLimitImagBoundStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.RiemannFormHermitianLatticeStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_Int_cast___at___00ReciprocityTheory_PTheta_ofIntVec_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst___redArg(lean_object* v_u_1_, lean_object* v_k_2_){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_apply_1(v_u_1_, v_k_2_);
v___x_4_ = lp_tree_Int_cast___at___00ReciprocityTheory_PTheta_ofIntVec_spec__0(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst(lean_object* v_g_5_, lean_object* v_u_6_, lean_object* v_k_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst___redArg(v_u_6_, v_k_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst___boxed(lean_object* v_g_9_, lean_object* v_u_10_, lean_object* v_k_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_tree_GlobalTheory_CompanionTheory_Ar_RiemannLimit_cst(v_g_9_, v_u_10_, v_k_11_);
lean_dec(v_g_9_);
return v_res_12_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_Assembly(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PRiemannExtensionSlices(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PPuncturedExpOrder(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PLogCoverDescent(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ImLowerOnKernel(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_ExistsAdaptedUnimodular(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_SymplecticPolydiscPeriodBasisStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_SiegelLimitImagBoundStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_RiemannFormHermitianLatticeStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LogPeriodLimit(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_Assembly(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PRiemannExtensionSlices(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PPuncturedExpOrder(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Regularisation_PLogCoverDescent(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ImLowerOnKernel(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_AlgebraProofs_ExistsAdaptedUnimodular(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_SymplecticPolydiscPeriodBasisStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_SiegelLimitImagBoundStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_RiemannFormHermitianLatticeStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

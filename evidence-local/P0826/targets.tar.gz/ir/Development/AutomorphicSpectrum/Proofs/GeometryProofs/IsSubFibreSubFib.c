// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsSubFibreSubFib
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.SlopeBoundSt public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ArchBetween public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.BdryChart public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ClopenCondOnto public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.UniformisationConclusion public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.HeckeKer public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.BlowupProjections.BlowupProjStatement public import Development.AbelianVarietyTheory.PublishedTheorems.SemiabelianTori.GeometricallyConnectedSplitTorusAff
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_FlagFib_subFib(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_FlagFib_subFib___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_FlagFib_subFib(lean_object* v_X_1_, lean_object* v_00_u03a9_2_, lean_object* v_inst_3_, lean_object* v_G_4_, lean_object* v_inst_5_, lean_object* v_00_u03be_6_, lean_object* v_Li_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_L_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_M_13_, lean_object* v_U_14_, lean_object* v_z_15_, lean_object* v_V_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_MB_19_){
_start:
{
lean_object* v___x_20_; 
v___x_20_ = lean_box(0);
return v___x_20_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_FlagFib_subFib___boxed(lean_object** _args){
lean_object* v_X_21_ = _args[0];
lean_object* v_00_u03a9_22_ = _args[1];
lean_object* v_inst_23_ = _args[2];
lean_object* v_G_24_ = _args[3];
lean_object* v_inst_25_ = _args[4];
lean_object* v_00_u03be_26_ = _args[5];
lean_object* v_Li_27_ = _args[6];
lean_object* v_inst_28_ = _args[7];
lean_object* v_inst_29_ = _args[8];
lean_object* v_L_30_ = _args[9];
lean_object* v_inst_31_ = _args[10];
lean_object* v_inst_32_ = _args[11];
lean_object* v_M_33_ = _args[12];
lean_object* v_U_34_ = _args[13];
lean_object* v_z_35_ = _args[14];
lean_object* v_V_36_ = _args[15];
lean_object* v_inst_37_ = _args[16];
lean_object* v_inst_38_ = _args[17];
lean_object* v_MB_39_ = _args[18];
_start:
{
lean_object* v_res_40_; 
v_res_40_ = lp_tree_GlobalTheory_CompanionTheory_Ar_FlagFib_subFib(v_X_21_, v_00_u03a9_22_, v_inst_23_, v_G_24_, v_inst_25_, v_00_u03be_26_, v_Li_27_, v_inst_28_, v_inst_29_, v_L_30_, v_inst_31_, v_inst_32_, v_M_33_, v_U_34_, v_z_35_, v_V_36_, v_inst_37_, v_inst_38_, v_MB_39_);
lean_dec_ref(v_MB_39_);
lean_dec(v_inst_38_);
lean_dec_ref(v_inst_37_);
lean_dec_ref(v_z_35_);
lean_dec_ref(v_M_33_);
lean_dec_ref(v_inst_31_);
lean_dec(v_inst_29_);
lean_dec_ref(v_inst_28_);
lean_dec_ref(v_00_u03be_26_);
lean_dec_ref(v_inst_25_);
lean_dec_ref(v_G_24_);
lean_dec_ref(v_inst_23_);
lean_dec_ref(v_X_21_);
return v_res_40_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_IsSubFibreSubFib(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.ArithVarCommonCover
// Imports: public import Init public meta import Init public import Development.AutomorphicSpectrum.Statements.GeometryStatements.CmpPair public import Development.AutomorphicSpectrum.Statements.GeometryStatements.CmpSt public import Development.AutomorphicSpectrum.Statements.GeometryStatements.PadicIntegersHenselianFiniteResidue public import Development.AutomorphicSpectrum.Statements.GeometryStatements.HodgeComparisonCompatibility public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.ThetaUnifAV public import Development.AutomorphicSpectrum.Definitions.DivisibilityTowers.Proportional public import Development.WeilBound.CoreStatements.HomogeneousNonvanishing.JNormal public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FiniteExtensionCoordsCompareStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_CmpPair(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_CmpSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_PadicIntegersHenselianFiniteResidue(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeComparisonCompatibility(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_ThetaUnifAV(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_DivisibilityTowers_Proportional(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_HomogeneousNonvanishing_JNormal(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FiniteExtensionCoordsCompareStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ArithVarCommonCover(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_CmpPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_CmpSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_PadicIntegersHenselianFiniteResidue(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeComparisonCompatibility(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_ThetaUnifAV(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_DivisibilityTowers_Proportional(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_HomogeneousNonvanishing_JNormal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FiniteExtensionCoordsCompareStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

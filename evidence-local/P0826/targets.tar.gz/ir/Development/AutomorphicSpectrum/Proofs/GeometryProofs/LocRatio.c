// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.LocRatio
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.SlopeBoundSt public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.ArchBetween public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.BdryChart public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.ClopenCondOnto public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.UniformisationConclusion public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.ToroidalCompactification.HeckeKer public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.BirationalGeometry.BlowupProjections.BlowupProjStatement public import Development.AbelianVarietyTheory.PublishedTheorems.SemiabelianTori.GeometricallyConnectedSplitTorusAff
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_CommRing_toCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_DivisionRing_toDivInvMonoid___redArg(lean_object*);
lean_object* lp_mathlib_Finset_prod___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg___lam__0(lean_object* v_c_1_, lean_object* v_y_2_, lean_object* v_a_3_, lean_object* v_toZPow_4_, lean_object* v_k_5_){
_start:
{
lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v___x_10_; 
lean_inc_n(v_k_5_, 2);
v___x_6_ = lean_apply_1(v_c_1_, v_k_5_);
v___x_7_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_7_, 0, v_k_5_);
lean_ctor_set(v___x_7_, 1, v___x_6_);
v___x_8_ = lean_apply_1(v_y_2_, v___x_7_);
v___x_9_ = lean_apply_1(v_a_3_, v_k_5_);
v___x_10_ = lean_apply_2(v_toZPow_4_, v___x_9_, v___x_8_);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg(lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_y_13_, lean_object* v_a_14_, lean_object* v_e_u2080_15_, lean_object* v_c_16_){
_start:
{
lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v_toSemiring_19_; lean_object* v___x_20_; lean_object* v_toMul_21_; lean_object* v_toCommRing_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v_toZPow_26_; lean_object* v___f_27_; lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_17_ = lp_mathlib_Field_toSemifield___redArg(v_inst_11_);
v___x_18_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_17_);
v_toSemiring_19_ = lean_ctor_get(v___x_18_, 0);
lean_inc_ref(v_toSemiring_19_);
lean_dec_ref(v___x_18_);
v___x_20_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_19_);
v_toMul_21_ = lean_ctor_get(v___x_20_, 0);
lean_inc(v_toMul_21_);
lean_dec_ref(v___x_20_);
v_toCommRing_22_ = lean_ctor_get(v_inst_11_, 0);
v___x_23_ = lp_mathlib_CommRing_toCommMonoid___redArg(v_toCommRing_22_);
v___x_24_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_11_);
v___x_25_ = lp_mathlib_DivisionRing_toDivInvMonoid___redArg(v___x_24_);
lean_dec_ref(v___x_24_);
v_toZPow_26_ = lean_ctor_get(v___x_25_, 3);
lean_inc(v_toZPow_26_);
lean_dec_ref(v___x_25_);
v___f_27_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg___lam__0), 5, 4);
lean_closure_set(v___f_27_, 0, v_c_16_);
lean_closure_set(v___f_27_, 1, v_y_13_);
lean_closure_set(v___f_27_, 2, v_a_14_);
lean_closure_set(v___f_27_, 3, v_toZPow_26_);
v___x_28_ = lp_mathlib_Finset_prod___redArg(v___x_23_, v_inst_12_, v___f_27_);
lean_dec_ref(v___x_23_);
v___x_29_ = lean_apply_2(v_toMul_21_, v___x_28_, v_e_u2080_15_);
return v___x_29_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen(lean_object* v_00_u03a9_30_, lean_object* v_inst_31_, lean_object* v_K_32_, lean_object* v_inst_33_, lean_object* v_J_34_, lean_object* v_y_35_, lean_object* v_a_36_, lean_object* v_e_u2080_37_, lean_object* v_c_38_){
_start:
{
lean_object* v___x_39_; 
v___x_39_ = lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gen___redArg(v_inst_31_, v_inst_33_, v_y_35_, v_a_36_, v_e_u2080_37_, v_c_38_);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___lam__0(lean_object* v_v_40_, lean_object* v_h_41_, lean_object* v_z_42_, lean_object* v_a_43_, lean_object* v_b_44_){
_start:
{
lean_object* v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; 
lean_inc_ref(v_v_40_);
v___x_45_ = lean_apply_1(v_v_40_, v_a_43_);
v___x_46_ = lean_apply_1(v_v_40_, v_b_44_);
v___x_47_ = lean_apply_3(v_h_41_, v_z_42_, v___x_45_, v___x_46_);
return v___x_47_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0(void){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg(lean_object* v_h_49_, lean_object* v_z_50_, lean_object* v_v_51_, lean_object* v_a_52_, lean_object* v_a_53_){
_start:
{
lean_object* v___x_54_; lean_object* v_toFun_55_; lean_object* v___f_56_; lean_object* v___x_57_; 
v___x_54_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___closed__0);
v_toFun_55_ = lean_ctor_get(v___x_54_, 0);
v___f_56_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg___lam__0), 5, 3);
lean_closure_set(v___f_56_, 0, v_v_51_);
lean_closure_set(v___f_56_, 1, v_h_49_);
lean_closure_set(v___f_56_, 2, v_z_50_);
lean_inc(v_toFun_55_);
v___x_57_ = lean_apply_3(v_toFun_55_, v___f_56_, v_a_52_, v_a_53_);
return v___x_57_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt(lean_object* v_X_58_, lean_object* v_00_u03a9_59_, lean_object* v_inst_60_, lean_object* v_K_61_, lean_object* v_J_62_, lean_object* v_00_u03be_63_, lean_object* v_G_64_, lean_object* v_inst_65_, lean_object* v_Li_66_, lean_object* v_inst_67_, lean_object* v_inst_68_, lean_object* v_M_69_, lean_object* v_y_70_, lean_object* v_h_71_, lean_object* v_z_72_, lean_object* v_n_73_, lean_object* v_v_74_, lean_object* v_a_75_, lean_object* v_a_76_){
_start:
{
lean_object* v___x_77_; 
v___x_77_ = lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___redArg(v_h_71_, v_z_72_, v_v_74_, v_a_75_, v_a_76_);
return v___x_77_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt___boxed(lean_object** _args){
lean_object* v_X_78_ = _args[0];
lean_object* v_00_u03a9_79_ = _args[1];
lean_object* v_inst_80_ = _args[2];
lean_object* v_K_81_ = _args[3];
lean_object* v_J_82_ = _args[4];
lean_object* v_00_u03be_83_ = _args[5];
lean_object* v_G_84_ = _args[6];
lean_object* v_inst_85_ = _args[7];
lean_object* v_Li_86_ = _args[8];
lean_object* v_inst_87_ = _args[9];
lean_object* v_inst_88_ = _args[10];
lean_object* v_M_89_ = _args[11];
lean_object* v_y_90_ = _args[12];
lean_object* v_h_91_ = _args[13];
lean_object* v_z_92_ = _args[14];
lean_object* v_n_93_ = _args[15];
lean_object* v_v_94_ = _args[16];
lean_object* v_a_95_ = _args[17];
lean_object* v_a_96_ = _args[18];
_start:
{
lean_object* v_res_97_; 
v_res_97_ = lp_tree_GlobalTheory_CompanionTheory_Ar_RootHt_gramAt(v_X_78_, v_00_u03a9_79_, v_inst_80_, v_K_81_, v_J_82_, v_00_u03be_83_, v_G_84_, v_inst_85_, v_Li_86_, v_inst_87_, v_inst_88_, v_M_89_, v_y_90_, v_h_91_, v_z_92_, v_n_93_, v_v_94_, v_a_95_, v_a_96_);
lean_dec(v_n_93_);
lean_dec(v_y_90_);
lean_dec_ref(v_M_89_);
lean_dec(v_inst_88_);
lean_dec_ref(v_inst_87_);
lean_dec_ref(v_inst_85_);
lean_dec_ref(v_G_84_);
lean_dec_ref(v_00_u03be_83_);
lean_dec_ref(v_inst_80_);
lean_dec_ref(v_X_78_);
return v_res_97_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_LocRatio(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_SlopeBoundSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_ArchBetween(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_BdryChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_ClopenCondOnto(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_UniformisationConclusion(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_ToroidalCompactification_HeckeKer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_BirationalGeometry_BlowupProjections_BlowupProjStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_SemiabelianTori_GeometricallyConnectedSplitTorusAff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

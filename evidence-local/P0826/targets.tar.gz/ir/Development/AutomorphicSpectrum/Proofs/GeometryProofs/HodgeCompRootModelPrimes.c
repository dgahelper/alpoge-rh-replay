// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.GeometryProofs.HodgeCompRootModelPrimes
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsPreFamilyOfLatticeFamilyTwo public import Development.AutomorphicSpectrum.Statements.GeometryStatements.HodgeLatticeFlagBound public import Development.AutomorphicSpectrum.Statements.GeometryStatements.TrivFlagOnHodge public import Development.AutomorphicSpectrum.Statements.GeometryStatements.HodgeLatticeFlagBoundAllPlaces public import Development.AutomorphicSpectrum.Statements.AlgebraStatements.HodgeTateNormComparison public import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.StatementsFlagIndependence public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ArithVarietyCoordIdealStatement public import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.LocalizationModelOverPlaceStatement public import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.PowerSumsVanishOfTrivialFlagsStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsPreFamilyOfLatticeFamilyTwo(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeLatticeFlagBound(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_TrivFlagOnHodge(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeLatticeFlagBoundAllPlaces(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_AlgebraStatements_HodgeTateNormComparison(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_DiscreteValuationNumbers_StatementsFlagIndependence(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ArithVarietyCoordIdealStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_LocalizationModelOverPlaceStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_PowerSumsVanishOfTrivialFlagsStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_HodgeCompRootModelPrimes(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsPreFamilyOfLatticeFamilyTwo(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeLatticeFlagBound(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_TrivFlagOnHodge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_HodgeLatticeFlagBoundAllPlaces(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_AlgebraStatements_HodgeTateNormComparison(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_DiscreteValuationNumbers_StatementsFlagIndependence(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ArithVarietyCoordIdealStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_LocalizationModelOverPlaceStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_PowerSumsVanishOfTrivialFlagsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

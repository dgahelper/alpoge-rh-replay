// Lean compiler output
// Module: Development.WeilBound.CoreStatements.FlagImmersions.EqZeroOfTri
// Imports: public import Init public meta import Init public import Development.WeilBound.CoreStatements.FlagImmersions.Transport public import Development.WeilBound.CoreStatements.VolumeEquality.BaseUnifVec
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lp_tree_Matrix_diagonal___at___00GroundTheory_Heights_u2082_Heights_NineStatements_signMat_spec__0___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
static lean_once_cell_t lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0;
static const lean_closure_object lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__1 = (const lean_object*)&lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0(lean_object* v_x_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_obj_once(&lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0, &lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0_once, _init_lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___closed__0);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0___boxed(lean_object* v_x_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__0(v_x_5_);
lean_dec(v_x_5_);
return v_res_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1(lean_object* v_b_7_, lean_object* v___f_8_, lean_object* v_A_9_, lean_object* v_a_10_, lean_object* v_c_11_){
_start:
{
uint8_t v___x_12_; 
v___x_12_ = lean_nat_dec_le(v_a_10_, v_b_7_);
if (v___x_12_ == 0)
{
lean_object* v___x_13_; 
lean_dec_ref(v_A_9_);
v___x_13_ = lp_tree_Matrix_diagonal___at___00GroundTheory_Heights_u2082_Heights_NineStatements_signMat_spec__0___redArg(v___f_8_, v_a_10_, v_c_11_);
return v___x_13_;
}
else
{
lean_object* v___x_14_; 
lean_dec_ref(v___f_8_);
v___x_14_ = lean_apply_2(v_A_9_, v_a_10_, v_c_11_);
return v___x_14_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1___boxed(lean_object* v_b_15_, lean_object* v___f_16_, lean_object* v_A_17_, lean_object* v_a_18_, lean_object* v_c_19_){
_start:
{
lean_object* v_res_20_; 
v_res_20_ = lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1(v_b_15_, v___f_16_, v_A_17_, v_a_18_, v_c_19_);
lean_dec(v_b_15_);
return v_res_20_;
}
}
static lean_object* _init_lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0(void){
_start:
{
lean_object* v___x_21_; 
v___x_21_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___redArg(lean_object* v_A_23_, lean_object* v_b_24_, lean_object* v_a_25_, lean_object* v_a_26_){
_start:
{
lean_object* v___x_27_; lean_object* v_toFun_28_; lean_object* v___f_29_; lean_object* v___f_30_; lean_object* v___x_31_; 
v___x_27_ = lean_obj_once(&lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0, &lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0_once, _init_lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__0);
v_toFun_28_ = lean_ctor_get(v___x_27_, 0);
v___f_29_ = ((lean_object*)(lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___closed__1));
v___f_30_ = lean_alloc_closure((void*)(lp_tree_RootFieldNumerics_FlImm_cutRows___redArg___lam__1___boxed), 5, 3);
lean_closure_set(v___f_30_, 0, v_b_24_);
lean_closure_set(v___f_30_, 1, v___f_29_);
lean_closure_set(v___f_30_, 2, v_A_23_);
lean_inc(v_toFun_28_);
v___x_31_ = lean_apply_3(v_toFun_28_, v___f_30_, v_a_25_, v_a_26_);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows(lean_object* v_N_32_, lean_object* v_A_33_, lean_object* v_b_34_, lean_object* v_a_35_, lean_object* v_a_36_){
_start:
{
lean_object* v___x_37_; 
v___x_37_ = lp_tree_RootFieldNumerics_FlImm_cutRows___redArg(v_A_33_, v_b_34_, v_a_35_, v_a_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_RootFieldNumerics_FlImm_cutRows___boxed(lean_object* v_N_38_, lean_object* v_A_39_, lean_object* v_b_40_, lean_object* v_a_41_, lean_object* v_a_42_){
_start:
{
lean_object* v_res_43_; 
v_res_43_ = lp_tree_RootFieldNumerics_FlImm_cutRows(v_N_38_, v_A_39_, v_b_40_, v_a_41_, v_a_42_);
lean_dec(v_N_38_);
return v_res_43_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_FlagImmersions_Transport(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_VolumeEquality_BaseUnifVec(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_FlagImmersions_EqZeroOfTri(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_FlagImmersions_Transport(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_VolumeEquality_BaseUnifVec(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

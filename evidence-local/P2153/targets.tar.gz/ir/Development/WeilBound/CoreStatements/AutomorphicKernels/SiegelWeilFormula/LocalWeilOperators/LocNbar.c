// Lean compiler output
// Module: Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.LocNbar
// Imports: public import Init public meta import Init public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.LocForm public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.StepW public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.NbarConj public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.OppositeUnipotentWeylConj public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.StepWN public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LocalWeilOperators.LocJJA
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_LocForm(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_StepW(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_NbarConj(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_OppositeUnipotentWeylConj(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_StepWN(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_LocJJA(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_LocNbar(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_LocForm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_StepW(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_NbarConj(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_OppositeUnipotentWeylConj(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_StepWN(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LocalWeilOperators_LocJJA(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

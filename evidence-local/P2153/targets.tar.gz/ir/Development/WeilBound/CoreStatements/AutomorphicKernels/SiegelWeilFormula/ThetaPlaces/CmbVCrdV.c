// Lean compiler output
// Module: Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaPlaces.CmbVCrdV
// Imports: public import Init public meta import Init public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaPlaces.BasisReprMap
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___lam__0(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___lam__0(lean_object* v_Y_1_, lean_object* v_a_2_, lean_object* v_j_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_apply_2(v_Y_1_, v_j_3_, v_a_2_);
return v___x_4_;
}
}
static lean_object* _init_lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0(void){
_start:
{
lean_object* v___x_5_; 
v___x_5_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg(lean_object* v_Y_6_, lean_object* v_a_7_, lean_object* v_a_8_){
_start:
{
lean_object* v___x_9_; lean_object* v_toFun_10_; lean_object* v___f_11_; lean_object* v___x_12_; 
v___x_9_ = lean_obj_once(&lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0, &lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0_once, _init_lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___closed__0);
v_toFun_10_ = lean_ctor_get(v___x_9_, 0);
v___f_11_ = lean_alloc_closure((void*)(lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg___lam__0), 3, 1);
lean_closure_set(v___f_11_, 0, v_Y_6_);
lean_inc(v_toFun_10_);
v___x_12_ = lean_apply_3(v_toFun_10_, v___f_11_, v_a_7_, v_a_8_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV(lean_object* v_F_13_, lean_object* v_E_14_, lean_object* v_inst_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_m_19_, lean_object* v_n_20_, lean_object* v_v_21_, lean_object* v_Y_22_, lean_object* v_a_23_, lean_object* v_a_24_){
_start:
{
lean_object* v___x_25_; 
v___x_25_ = lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___redArg(v_Y_22_, v_a_23_, v_a_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV___boxed(lean_object* v_F_26_, lean_object* v_E_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_inst_31_, lean_object* v_m_32_, lean_object* v_n_33_, lean_object* v_v_34_, lean_object* v_Y_35_, lean_object* v_a_36_, lean_object* v_a_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_PositivityTheory_SiegelWeilFormula_ThetaDictR_PureC_toMxV(v_F_26_, v_E_27_, v_inst_28_, v_inst_29_, v_inst_30_, v_inst_31_, v_m_32_, v_n_33_, v_v_34_, v_Y_35_, v_a_36_, v_a_37_);
lean_dec(v_n_33_);
lean_dec(v_m_32_);
lean_dec_ref(v_inst_31_);
lean_dec_ref(v_inst_30_);
lean_dec_ref(v_inst_28_);
return v_res_38_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_ThetaPlaces_BasisReprMap(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_ThetaPlaces_CmbVCrdV(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_ThetaPlaces_BasisReprMap(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

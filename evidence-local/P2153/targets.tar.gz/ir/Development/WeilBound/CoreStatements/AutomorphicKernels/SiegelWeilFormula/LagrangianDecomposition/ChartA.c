// Lean compiler output
// Module: Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LagrangianDecomposition.ChartA
// Imports: public import Init public meta import Init public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LagrangianDecomposition.ChartFacts public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.LagrangianDecomposition.UnitaryConjIff
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_id___boxed(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_zero___aux__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_fromCols(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_eB___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_submatrix___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___lam__0(lean_object*, lean_object*);
static const lean_closure_object lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_id___boxed, .m_arity = 2, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))} };
static const lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___closed__0 = (const lean_object*)&lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___lam__0(lean_object* v___x_1_, lean_object* v___y_2_){
_start:
{
lean_object* v_toFun_3_; lean_object* v___x_4_; 
v_toFun_3_ = lean_ctor_get(v___x_1_, 0);
lean_inc(v_toFun_3_);
lean_dec_ref(v___x_1_);
v___x_4_ = lean_apply_1(v_toFun_3_, v___y_2_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg(lean_object* v_inst_6_, lean_object* v_n_7_, lean_object* v_N_8_, lean_object* v_Q_9_, lean_object* v_a_10_, lean_object* v_a_11_){
_start:
{
lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___f_16_; lean_object* v___x_17_; 
v___x_12_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_zero___aux__1___boxed), 6, 4);
lean_closure_set(v___x_12_, 0, lean_box(0));
lean_closure_set(v___x_12_, 1, lean_box(0));
lean_closure_set(v___x_12_, 2, lean_box(0));
lean_closure_set(v___x_12_, 3, v_inst_6_);
v___x_13_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_fromCols), 8, 6);
lean_closure_set(v___x_13_, 0, lean_box(0));
lean_closure_set(v___x_13_, 1, lean_box(0));
lean_closure_set(v___x_13_, 2, lean_box(0));
lean_closure_set(v___x_13_, 3, lean_box(0));
lean_closure_set(v___x_13_, 4, v_Q_9_);
lean_closure_set(v___x_13_, 5, v___x_12_);
v___x_14_ = ((lean_object*)(lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___closed__0));
v___x_15_ = lp_tree_PositivityTheory_SiegelWeilFormula_Ald_eB___redArg(v_N_8_, v_n_7_);
v___f_16_ = lean_alloc_closure((void*)(lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___lam__0), 2, 1);
lean_closure_set(v___f_16_, 0, v___x_15_);
v___x_17_ = lp_mathlib_Matrix_submatrix___redArg(v___x_13_, v___x_14_, v___f_16_, v_a_10_, v_a_11_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg___boxed(lean_object* v_inst_18_, lean_object* v_n_19_, lean_object* v_N_20_, lean_object* v_Q_21_, lean_object* v_a_22_, lean_object* v_a_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg(v_inst_18_, v_n_19_, v_N_20_, v_Q_21_, v_a_22_, v_a_23_);
lean_dec(v_N_20_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ(lean_object* v_R_25_, lean_object* v_inst_26_, lean_object* v_m_27_, lean_object* v_n_28_, lean_object* v_N_29_, lean_object* v_h_30_, lean_object* v_Q_31_, lean_object* v_a_32_, lean_object* v_a_33_){
_start:
{
lean_object* v___x_34_; 
v___x_34_ = lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___redArg(v_inst_26_, v_n_28_, v_N_29_, v_Q_31_, v_a_32_, v_a_33_);
return v___x_34_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ___boxed(lean_object* v_R_35_, lean_object* v_inst_36_, lean_object* v_m_37_, lean_object* v_n_38_, lean_object* v_N_39_, lean_object* v_h_40_, lean_object* v_Q_41_, lean_object* v_a_42_, lean_object* v_a_43_){
_start:
{
lean_object* v_res_44_; 
v_res_44_ = lp_tree_PositivityTheory_SiegelWeilFormula_Ald_embQ(v_R_35_, v_inst_36_, v_m_37_, v_n_38_, v_N_39_, v_h_40_, v_Q_41_, v_a_42_, v_a_43_);
lean_dec(v_N_39_);
lean_dec(v_m_37_);
return v_res_44_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LagrangianDecomposition_ChartFacts(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LagrangianDecomposition_UnitaryConjIff(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LagrangianDecomposition_ChartA(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LagrangianDecomposition_ChartFacts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_LagrangianDecomposition_UnitaryConjIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

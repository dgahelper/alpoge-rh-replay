// Lean compiler output
// Module: Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.RealAdelicFockSpace.LrhoPf
// Imports: public import Init public meta import Init public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.RealAdelicFockSpace.Spf public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.ThetaParabolic.LRhoOm public import Development.WeilBound.CoreStatements.AutomorphicKernels.SiegelWeilFormula.THeis public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.AdelicSchwartzMemL2 public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.SchroedingerPreservesAdelicSchwartz
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_RealAdelicFockSpace_Spf(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_ThetaParabolic_LRhoOm(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_THeis(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_AdelicSchwartzMemL2(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_SchroedingerPreservesAdelicSchwartz(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_RealAdelicFockSpace_LrhoPf(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_RealAdelicFockSpace_Spf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_ThetaParabolic_LRhoOm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SiegelWeilFormula_THeis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_AdelicSchwartzMemL2(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_SchroedingerPreservesAdelicSchwartz(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

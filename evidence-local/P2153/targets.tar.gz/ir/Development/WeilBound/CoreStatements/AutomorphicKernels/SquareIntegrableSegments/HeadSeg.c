// Lean compiler output
// Module: Development.WeilBound.CoreStatements.AutomorphicKernels.SquareIntegrableSegments.HeadSeg
// Imports: public import Init public meta import Init public import Mathlib public import Development.WeilBound.CoreStatements.AutomorphicKernels.SquareIntegrableSegments.EssSquareIntegrableSegmentsMain2 public import Development.WeilBound.CoreStatements.AutomorphicKernels.SquareIntegrableSegments.SegmentSubquotients.SegmentJacquetAllStatement public import Development.WeilBound.CoreStatements.TemperedRepresentationTheory.BernsteinZelevinskyGL.TopStd public import Development.WeilBound.CoreStatements.AutomorphicKernels.LanglandsExhaustion.LanglandsMultisegmentsOfSeg public import Development.AutomorphicSpectrum.Proofs.BlockDecomposition.ExistsSegmentRepresentationStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SquareIntegrableSegments_EssSquareIntegrableSegmentsMain2(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SquareIntegrableSegments_SegmentSubquotients_SegmentJacquetAllStatement(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_BernsteinZelevinskyGL_TopStd(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_LanglandsExhaustion_LanglandsMultisegmentsOfSeg(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_BlockDecomposition_ExistsSegmentRepresentationStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SquareIntegrableSegments_HeadSeg(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SquareIntegrableSegments_EssSquareIntegrableSegmentsMain2(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_SquareIntegrableSegments_SegmentSubquotients_SegmentJacquetAllStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_TemperedRepresentationTheory_BernsteinZelevinskyGL_TopStd(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_AutomorphicKernels_LanglandsExhaustion_LanglandsMultisegmentsOfSeg(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_BlockDecomposition_ExistsSegmentRepresentationStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

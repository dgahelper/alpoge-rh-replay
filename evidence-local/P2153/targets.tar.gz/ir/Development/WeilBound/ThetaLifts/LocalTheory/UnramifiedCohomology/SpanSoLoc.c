// Lean compiler output
// Module: Development.WeilBound.ThetaLifts.LocalTheory.UnramifiedCohomology.SpanSoLoc
// Imports: public import Init public meta import Init public import Development.WeilBound.ThetaLifts.LocalTheory.ConeShifts.KAtCompact public import Development.WeilBound.ThetaLifts.LocalTheory.AdmissiblePureTensorSchwartz public import Development.WeilBound.ThetaLifts.SmallCones.MatCancel public import Development.WeilBound.ThetaLifts.SmallCones.SoDefs public import Development.WeilBound.CoreStatements.LocallyConstantCoinvariants.FullOfSoLoc
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_LocalTheory_ConeShifts_KAtCompact(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_LocalTheory_AdmissiblePureTensorSchwartz(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_SmallCones_MatCancel(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_SmallCones_SoDefs(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_LocallyConstantCoinvariants_FullOfSoLoc(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_ThetaLifts_LocalTheory_UnramifiedCohomology_SpanSoLoc(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_LocalTheory_ConeShifts_KAtCompact(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_LocalTheory_AdmissiblePureTensorSchwartz(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_SmallCones_MatCancel(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_SmallCones_SoDefs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_LocallyConstantCoinvariants_FullOfSoLoc(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

// Lean compiler output
// Module: Development.WeilBound.ThetaLifts.Reductions.WeilPairs.MfacInvMul
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ReindexDblIncM public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.LagrInt public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.Mfac public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.DCdE public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.DiagonalLagrangianIntegralSiegelParabolicTransfoAlt public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.UnitCoef public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.IntegralMul public import Development.WeilBound.ThetaLifts.Reductions.WeilPairs.PrSingle
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ReindexDblIncM(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_LagrInt(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_Mfac(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_DCdE(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_DiagonalLagrangianIntegralSiegelParabolicTransfoAlt(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_UnitCoef(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_IntegralMul(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_PrSingle(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_MfacInvMul(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ReindexDblIncM(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_LagrInt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_Mfac(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_DCdE(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_DiagonalLagrangianIntegralSiegelParabolicTransfoAlt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_UnitCoef(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_IntegralMul(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_ThetaLifts_Reductions_WeilPairs_PrSingle(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

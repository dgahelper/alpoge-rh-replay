// Lean compiler output
// Module: Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.InfinitesimalCharacterLimits.LimitPairSpaces.TypeBOfMemTypSp
// Imports: public import Init public meta import Init public import Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.InfinitesimalCharacterLimits.LimitPairSpaces.TensorSpanEqPairSpace
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib___private_Mathlib_Data_Real_Basic_0__Real_mul(lean_object*, lean_object*);
lean_object* l_instSMulOfMul___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Complex_mulAux___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_mk_u2082_x27_u209b_u2097___redArg___lam__0(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib___private_Mathlib_Data_Real_Basic_0__Real_mul, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__0 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__0_value;
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instSMulOfMul___redArg___lam__0, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__0_value)} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__1 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0, .m_arity = 3, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__0 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__0_value;
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_LinearMap_mk_u2082_x27_u209b_u2097___redArg___lam__0, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__0_value)} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__1 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0(lean_object* v_00_u03c6_u2081_4_, lean_object* v_00_u03c6_u2082_5_, lean_object* v_m_6_){
_start:
{
lean_object* v_fst_7_; lean_object* v_snd_8_; lean_object* v___x_9_; lean_object* v_re_10_; lean_object* v_im_11_; lean_object* v___x_12_; lean_object* v___f_13_; lean_object* v___x_14_; 
v_fst_7_ = lean_ctor_get(v_m_6_, 0);
lean_inc(v_fst_7_);
v_snd_8_ = lean_ctor_get(v_m_6_, 1);
lean_inc(v_snd_8_);
lean_dec_ref(v_m_6_);
v___x_9_ = lean_apply_1(v_00_u03c6_u2081_4_, v_fst_7_);
v_re_10_ = lean_ctor_get(v___x_9_, 0);
lean_inc(v_re_10_);
v_im_11_ = lean_ctor_get(v___x_9_, 1);
lean_inc(v_im_11_);
lean_dec_ref(v___x_9_);
v___x_12_ = lean_apply_1(v_00_u03c6_u2082_5_, v_snd_8_);
v___f_13_ = ((lean_object*)(lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___lam__0___closed__1));
v___x_14_ = lp_mathlib_Complex_mulAux___redArg(v___f_13_, v_re_10_, v_im_11_, v___x_12_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil(lean_object* v_E_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_a_22_, lean_object* v_b_23_, lean_object* v_U_u2081_24_, lean_object* v_U_u2082_25_){
_start:
{
lean_object* v___f_26_; 
v___f_26_ = ((lean_object*)(lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___closed__1));
return v___f_26_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil___boxed(lean_object* v_E_27_, lean_object* v_inst_28_, lean_object* v_inst_29_, lean_object* v_inst_30_, lean_object* v_a_31_, lean_object* v_b_32_, lean_object* v_U_u2081_33_, lean_object* v_U_u2082_34_){
_start:
{
lean_object* v_res_35_; 
v_res_35_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_LV_prodBil(v_E_27_, v_inst_28_, v_inst_29_, v_inst_30_, v_a_31_, v_b_32_, v_U_u2081_33_, v_U_u2082_34_);
lean_dec(v_b_32_);
lean_dec(v_a_31_);
lean_dec_ref(v_inst_28_);
return v_res_35_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LimitPairSpaces_TensorSpanEqPairSpace(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LimitPairSpaces_TypeBOfMemTypSp(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LimitPairSpaces_TensorSpanEqPairSpace(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

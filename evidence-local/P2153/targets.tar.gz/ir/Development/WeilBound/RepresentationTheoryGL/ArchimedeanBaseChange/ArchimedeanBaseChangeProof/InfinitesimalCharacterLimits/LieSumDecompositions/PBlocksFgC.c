// Lean compiler output
// Module: Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.InfinitesimalCharacterLimits.LieSumDecompositions.PBlocksFgC
// Imports: public import Init public meta import Init public import Development.WeilBound.RepresentationTheoryGL.ArchimedeanBaseChange.ArchimedeanBaseChangeProof.InfinitesimalCharacterLimits.LieSumDecompositions.PBlocksFgB public import Development.WeilBound.RepresentationTheoryGL.ResidualSpectrum.SliceTensors.PIndMapB public import Development.WeilBound.RepresentationTheoryGL.ResidualSpectrum.ExponentialNegativity.DiagonalInfinityValues.InfGLValDiag
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Complex_instStarRing___lam__0(lean_object*);
lean_object* lp_mathlib_Pi_instStarForall___redArg___lam__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl(lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
lean_object* lp_mathlib_Complex_ofReal(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_conjTranspose___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__0 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__0_value;
static const lean_closure_object lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_Pi_instStarForall___redArg___lam__0, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__0_value)} };
static const lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__1 = (const lean_object*)&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1850581184____hygCtx___hyg_8_;
v___x_2_ = lp_mathlib_Complex_ofReal(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0(lean_object* v_r_3_, lean_object* v_X_4_, lean_object* v_i_5_, lean_object* v_j_6_, lean_object* v___y_7_){
_start:
{
uint8_t v___x_10_; 
v___x_10_ = lean_nat_dec_le(v_r_3_, v_i_5_);
if (v___x_10_ == 0)
{
lean_dec(v___y_7_);
lean_dec(v_j_6_);
lean_dec(v_i_5_);
lean_dec_ref(v_X_4_);
goto v___jp_8_;
}
else
{
uint8_t v___x_11_; 
v___x_11_ = lean_nat_dec_lt(v_j_6_, v_r_3_);
if (v___x_11_ == 0)
{
lean_dec(v___y_7_);
lean_dec(v_j_6_);
lean_dec(v_i_5_);
lean_dec_ref(v_X_4_);
goto v___jp_8_;
}
else
{
lean_object* v___x_12_; 
v___x_12_ = lean_apply_3(v_X_4_, v_i_5_, v_j_6_, v___y_7_);
return v___x_12_;
}
}
v___jp_8_:
{
lean_object* v___x_9_; 
v___x_9_ = lean_obj_once(&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0, &lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0_once, _init_lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___closed__0);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___boxed(lean_object* v_r_13_, lean_object* v_X_14_, lean_object* v_i_15_, lean_object* v_j_16_, lean_object* v___y_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0(v_r_13_, v_X_14_, v_i_15_, v_j_16_, v___y_17_);
lean_dec(v_r_13_);
return v_res_18_;
}
}
static lean_object* _init_lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0(void){
_start:
{
lean_object* v___x_19_; 
v___x_19_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg(lean_object* v_r_20_, lean_object* v_X_21_, lean_object* v_a_22_, lean_object* v_a_23_, lean_object* v_a_24_){
_start:
{
lean_object* v___x_25_; lean_object* v_toFun_26_; lean_object* v___f_27_; lean_object* v___x_28_; 
v___x_25_ = lean_obj_once(&lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0, &lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0_once, _init_lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___closed__0);
v_toFun_26_ = lean_ctor_get(v___x_25_, 0);
v___f_27_ = lean_alloc_closure((void*)(lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg___lam__0___boxed), 5, 2);
lean_closure_set(v___f_27_, 0, v_r_20_);
lean_closure_set(v___f_27_, 1, v_X_21_);
lean_inc(v_toFun_26_);
v___x_28_ = lean_apply_4(v_toFun_26_, v___f_27_, v_a_22_, v_a_23_, v_a_24_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL(lean_object* v_E_29_, lean_object* v_inst_30_, lean_object* v_r_31_, lean_object* v_s_32_, lean_object* v_X_33_, lean_object* v_a_34_, lean_object* v_a_35_, lean_object* v_a_36_){
_start:
{
lean_object* v___x_37_; 
v___x_37_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg(v_r_31_, v_X_33_, v_a_34_, v_a_35_, v_a_36_);
return v___x_37_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___boxed(lean_object* v_E_38_, lean_object* v_inst_39_, lean_object* v_r_40_, lean_object* v_s_41_, lean_object* v_X_42_, lean_object* v_a_43_, lean_object* v_a_44_, lean_object* v_a_45_){
_start:
{
lean_object* v_res_46_; 
v_res_46_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL(v_E_38_, v_inst_39_, v_r_40_, v_s_41_, v_X_42_, v_a_43_, v_a_44_, v_a_45_);
lean_dec(v_s_41_);
lean_dec_ref(v_inst_39_);
return v_res_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0(lean_object* v_i_47_, lean_object* v___y_48_){
_start:
{
lean_object* v___x_49_; 
v___x_49_ = lp_mathlib_Complex_instStarRing___lam__0(v___y_48_);
return v___x_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0___boxed(lean_object* v_i_50_, lean_object* v___y_51_){
_start:
{
lean_object* v_res_52_; 
v_res_52_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___lam__0(v_i_50_, v___y_51_);
lean_dec(v_i_50_);
return v_res_52_;
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg(lean_object* v_inst_56_, lean_object* v_r_57_, lean_object* v_s_58_, lean_object* v_X_59_, lean_object* v_a_60_, lean_object* v_a_61_, lean_object* v_a_62_){
_start:
{
lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v_re_65_; lean_object* v_im_66_; lean_object* v___f_67_; lean_object* v___x_74__overap_68_; lean_object* v___x_69_; lean_object* v_re_70_; lean_object* v_im_71_; lean_object* v___x_73_; uint8_t v_isShared_74_; uint8_t v_isSharedCheck_82_; 
lean_inc_ref(v_X_59_);
lean_inc(v_r_57_);
v___x_63_ = lean_alloc_closure((void*)(lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___boxed), 8, 5);
lean_closure_set(v___x_63_, 0, lean_box(0));
lean_closure_set(v___x_63_, 1, v_inst_56_);
lean_closure_set(v___x_63_, 2, v_r_57_);
lean_closure_set(v___x_63_, 3, v_s_58_);
lean_closure_set(v___x_63_, 4, v_X_59_);
lean_inc(v_a_62_);
lean_inc(v_a_61_);
lean_inc(v_a_60_);
v___x_64_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_lowL___redArg(v_r_57_, v_X_59_, v_a_60_, v_a_61_, v_a_62_);
v_re_65_ = lean_ctor_get(v___x_64_, 0);
lean_inc(v_re_65_);
v_im_66_ = lean_ctor_get(v___x_64_, 1);
lean_inc(v_im_66_);
lean_dec_ref(v___x_64_);
v___f_67_ = ((lean_object*)(lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg___closed__1));
v___x_74__overap_68_ = lp_mathlib_Matrix_conjTranspose___redArg(v___f_67_, v___x_63_, v_a_60_, v_a_61_);
v___x_69_ = lean_apply_1(v___x_74__overap_68_, v_a_62_);
v_re_70_ = lean_ctor_get(v___x_69_, 0);
v_im_71_ = lean_ctor_get(v___x_69_, 1);
v_isSharedCheck_82_ = !lean_is_exclusive(v___x_69_);
if (v_isSharedCheck_82_ == 0)
{
v___x_73_ = v___x_69_;
v_isShared_74_ = v_isSharedCheck_82_;
goto v_resetjp_72_;
}
else
{
lean_inc(v_im_71_);
lean_inc(v_re_70_);
lean_dec(v___x_69_);
v___x_73_ = lean_box(0);
v_isShared_74_ = v_isSharedCheck_82_;
goto v_resetjp_72_;
}
v_resetjp_72_:
{
lean_object* v___f_75_; lean_object* v___f_76_; lean_object* v___f_77_; lean_object* v___f_78_; lean_object* v___x_80_; 
v___f_75_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_75_, 0, v_re_70_);
v___f_76_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_76_, 0, v_re_65_);
lean_closure_set(v___f_76_, 1, v___f_75_);
v___f_77_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_77_, 0, v_im_71_);
v___f_78_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_1138242547____hygCtx___hyg_8_), 3, 2);
lean_closure_set(v___f_78_, 0, v_im_66_);
lean_closure_set(v___f_78_, 1, v___f_77_);
if (v_isShared_74_ == 0)
{
lean_ctor_set(v___x_73_, 1, v___f_78_);
lean_ctor_set(v___x_73_, 0, v___f_76_);
v___x_80_ = v___x_73_;
goto v_reusejp_79_;
}
else
{
lean_object* v_reuseFailAlloc_81_; 
v_reuseFailAlloc_81_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_81_, 0, v___f_76_);
lean_ctor_set(v_reuseFailAlloc_81_, 1, v___f_78_);
v___x_80_ = v_reuseFailAlloc_81_;
goto v_reusejp_79_;
}
v_reusejp_79_:
{
return v___x_80_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw(lean_object* v_E_83_, lean_object* v_inst_84_, lean_object* v_r_85_, lean_object* v_s_86_, lean_object* v_X_87_, lean_object* v_a_88_, lean_object* v_a_89_, lean_object* v_a_90_){
_start:
{
lean_object* v___x_91_; 
v___x_91_ = lp_tree_PositivityTheory_Rg_BcB_SpectralAccumulation_Cz_BlockFiniteGeneration_skw___redArg(v_inst_84_, v_r_85_, v_s_86_, v_X_87_, v_a_88_, v_a_89_, v_a_90_);
return v___x_91_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LieSumDecompositions_PBlocksFgB(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ResidualSpectrum_SliceTensors_PIndMapB(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ResidualSpectrum_ExponentialNegativity_DiagonalInfinityValues_InfGLValDiag(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LieSumDecompositions_PBlocksFgC(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_ArchimedeanBaseChange_ArchimedeanBaseChangeProof_InfinitesimalCharacterLimits_LieSumDecompositions_PBlocksFgB(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_ResidualSpectrum_SliceTensors_PIndMapB(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_ResidualSpectrum_ExponentialNegativity_DiagonalInfinityValues_InfGLValDiag(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

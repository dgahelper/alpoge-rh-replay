// Lean compiler output
// Module: Development.WeilBound.RepresentationTheoryGL.FormalDegree.FormalDegreeHilbert.DegreeGapNorms.GapNorm
// Imports: public import Init public meta import Init public import Development.WeilBound.RepresentationTheoryGL.FormalDegree.FormalDegreeHilbert.HlamStable public import Development.WeilBound.RepresentationTheoryGL.FormalDegree.FormalDegreeHilbert.DegreeGapNorms.DegPsi public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.ExceptionalGroupG2.FormalDegreeG2.FdCons public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.ExceptionalGroupG2.ExistenceG2.FormulaF public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.ExceptionalGroupG2.ExistenceG2.IsDSSigLam public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.CasimirCoefficients.PsiFor public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.DiscreteSeriesExistence.NormSubOneLeOfHsdA public import ReciprocityTheory.ReductiveGroups.DiscreteSeries.HighestWeights.Exists
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_FormalDegree_FormalDegreeHilbert_HlamStable(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_FormalDegree_FormalDegreeHilbert_DegreeGapNorms_DegPsi(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_FormalDegreeG2_FdCons(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_ExistenceG2_FormulaF(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_ExistenceG2_IsDSSigLam(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_CasimirCoefficients_PsiFor(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_DiscreteSeriesExistence_NormSubOneLeOfHsdA(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_HighestWeights_Exists(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_WeilBound_RepresentationTheoryGL_FormalDegree_FormalDegreeHilbert_DegreeGapNorms_GapNorm(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_FormalDegree_FormalDegreeHilbert_HlamStable(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_RepresentationTheoryGL_FormalDegree_FormalDegreeHilbert_DegreeGapNorms_DegPsi(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_FormalDegreeG2_FdCons(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_ExistenceG2_FormulaF(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_ExceptionalGroupG2_ExistenceG2_IsDSSigLam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_CasimirCoefficients_PsiFor(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_DiscreteSeriesExistence_NormSubOneLeOfHsdA(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_DiscreteSeries_HighestWeights_Exists(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

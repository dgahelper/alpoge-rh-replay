// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsIsLiftOfMemKO
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.IsTypeGroupBlockLift public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.IsCharLab public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsContractNeZero
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Matrix_reindex___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Units_map___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix___redArg(lean_object* v_e_1_){
_start:
{
lean_object* v___x_2_; lean_object* v_toFun_3_; lean_object* v___f_4_; 
lean_inc_ref(v_e_1_);
v___x_2_ = lp_mathlib_Matrix_reindex___redArg(v_e_1_, v_e_1_);
v_toFun_3_ = lean_ctor_get(v___x_2_, 0);
lean_inc(v_toFun_3_);
lean_dec_ref(v___x_2_);
v___f_4_ = lean_alloc_closure((void*)(lp_mathlib_Units_map___redArg___lam__0), 2, 1);
lean_closure_set(v___f_4_, 0, v_toFun_3_);
return v___f_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix(lean_object* v_R_5_, lean_object* v_inst_6_, lean_object* v_m_7_, lean_object* v_n_8_, lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_inst_11_, lean_object* v_inst_12_, lean_object* v_e_13_){
_start:
{
lean_object* v___x_14_; 
v___x_14_ = lp_tree_GlobalTheory_LevelType_reix___redArg(v_e_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LevelType_reix___boxed(lean_object* v_R_15_, lean_object* v_inst_16_, lean_object* v_m_17_, lean_object* v_n_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_e_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_GlobalTheory_LevelType_reix(v_R_15_, v_inst_16_, v_m_17_, v_n_18_, v_inst_19_, v_inst_20_, v_inst_21_, v_inst_22_, v_e_23_);
lean_dec_ref(v_inst_22_);
lean_dec(v_inst_21_);
lean_dec_ref(v_inst_20_);
lean_dec(v_inst_19_);
lean_dec_ref(v_inst_16_);
return v_res_24_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsTypeGroupBlockLift(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsCharLab(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsContractNeZero(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsIsLiftOfMemKO(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsTypeGroupBlockLift(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsCharLab(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsContractNeZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

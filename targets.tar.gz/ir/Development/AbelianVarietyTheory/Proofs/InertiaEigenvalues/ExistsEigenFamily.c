// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsEigenFamily
// Imports: public import Init public meta import Init public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.IsTypeGroupBlockLift
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_EigenFamilyStabilizer_stab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_EigenFamilyStabilizer_stab___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_EigenFamilyStabilizer_stab(lean_object* v_G_1_, lean_object* v_V_2_, lean_object* v_00_u03b9_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_inst_6_, lean_object* v_00_u03c1_7_, lean_object* v_K_8_, lean_object* v_00_u03b8_9_, lean_object* v_h1_10_, lean_object* v_hm_11_, lean_object* v_y_12_){
_start:
{
lean_object* v___x_13_; 
v___x_13_ = lean_box(0);
return v___x_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_EigenFamilyStabilizer_stab___boxed(lean_object* v_G_14_, lean_object* v_V_15_, lean_object* v_00_u03b9_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_00_u03c1_20_, lean_object* v_K_21_, lean_object* v_00_u03b8_22_, lean_object* v_h1_23_, lean_object* v_hm_24_, lean_object* v_y_25_){
_start:
{
lean_object* v_res_26_; 
v_res_26_ = lp_tree_GlobalTheory_EigenFamilyStabilizer_stab(v_G_14_, v_V_15_, v_00_u03b9_16_, v_inst_17_, v_inst_18_, v_inst_19_, v_00_u03c1_20_, v_K_21_, v_00_u03b8_22_, v_h1_23_, v_hm_24_, v_y_25_);
lean_dec(v_y_25_);
lean_dec_ref(v_00_u03b8_22_);
lean_dec(v_00_u03c1_20_);
lean_dec(v_inst_19_);
lean_dec_ref(v_inst_18_);
lean_dec_ref(v_inst_17_);
return v_res_26_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsTypeGroupBlockLift(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEigenFamily(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_IsTypeGroupBlockLift(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

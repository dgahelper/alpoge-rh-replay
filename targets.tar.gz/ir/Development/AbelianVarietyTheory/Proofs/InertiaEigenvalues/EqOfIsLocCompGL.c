// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.EqOfIsLocCompGL
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.IsNormalisedOfIsDiscrete public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.StrongMultiplicityOne public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.SpehDataUnique public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.DiscreteSpectrumOfResidual public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.AdelicGLIwasawaDecompositionStandardParabolic public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.LieDerivativeInducedTensorForms public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.CapCommuteRtInfGL public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.IwasawaDecompositionSmoothNearOneStatement public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ExistsEvalSum
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Complex_commRing;
lean_object* lp_mathlib_CommRing_toCommMonoid___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Finset_prod___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___lam__0(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___lam__0(lean_object* v_m_1_, lean_object* v_00_u03c6_2_, lean_object* v_i_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; 
lean_inc(v_i_3_);
v___x_4_ = lean_apply_1(v_m_1_, v_i_3_);
v___x_5_ = lean_apply_2(v_00_u03c6_2_, v_i_3_, v___x_4_);
return v___x_5_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0(void){
_start:
{
lean_object* v___x_6_; lean_object* v___x_7_; 
v___x_6_ = lp_mathlib_Complex_commRing;
v___x_7_ = lp_mathlib_CommRing_toCommMonoid___redArg(v___x_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___redArg(lean_object* v_c_8_, lean_object* v_00_u03c6_9_, lean_object* v_m_10_){
_start:
{
lean_object* v___f_11_; lean_object* v___x_12_; lean_object* v___x_13_; lean_object* v___x_14_; 
v___f_11_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___lam__0), 3, 2);
lean_closure_set(v___f_11_, 0, v_m_10_);
lean_closure_set(v___f_11_, 1, v_00_u03c6_9_);
v___x_12_ = lean_obj_once(&lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0, &lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0_once, _init_lp_tree_GlobalTheory_DiscSMO_prodForm___redArg___closed__0);
v___x_13_ = l_List_finRange(v_c_8_);
v___x_14_ = lp_mathlib_Finset_prod___redArg(v___x_12_, v___x_13_, v___f_11_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm(lean_object* v_E_15_, lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_c_19_, lean_object* v_n_20_, lean_object* v_00_u03c0_21_, lean_object* v_00_u03c6_22_, lean_object* v_m_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_tree_GlobalTheory_DiscSMO_prodForm___redArg(v_c_19_, v_00_u03c6_22_, v_m_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_DiscSMO_prodForm___boxed(lean_object* v_E_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_inst_28_, lean_object* v_c_29_, lean_object* v_n_30_, lean_object* v_00_u03c0_31_, lean_object* v_00_u03c6_32_, lean_object* v_m_33_){
_start:
{
lean_object* v_res_34_; 
v_res_34_ = lp_tree_GlobalTheory_DiscSMO_prodForm(v_E_25_, v_inst_26_, v_inst_27_, v_inst_28_, v_c_29_, v_n_30_, v_00_u03c0_31_, v_00_u03c6_32_, v_m_33_);
lean_dec_ref(v_00_u03c0_31_);
lean_dec_ref(v_n_30_);
lean_dec_ref(v_inst_26_);
return v_res_34_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_IsNormalisedOfIsDiscrete(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_StrongMultiplicityOne(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SpehDataUnique(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_DiscreteSpectrumOfResidual(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_AdelicGLIwasawaDecompositionStandardParabolic(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_LieDerivativeInducedTensorForms(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CapCommuteRtInfGL(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IwasawaDecompositionSmoothNearOneStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEvalSum(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_EqOfIsLocCompGL(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_IsNormalisedOfIsDiscrete(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_StrongMultiplicityOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_SpehDataUnique(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_DiscreteSpectrumOfResidual(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_AdelicGLIwasawaDecompositionStandardParabolic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_LieDerivativeInducedTensorForms(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_CapCommuteRtInfGL(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IwasawaDecompositionSmoothNearOneStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ExistsEvalSum(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

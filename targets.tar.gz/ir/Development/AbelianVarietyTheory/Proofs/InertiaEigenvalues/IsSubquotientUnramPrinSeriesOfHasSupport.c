// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.IsSubquotientUnramPrinSeriesOfHasSupport
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.RingSpecNormalisedCharacterEq public import Development.AbelianVarietyTheory.PublishedTheorems.GaloisCohomology₂.GaloisRepOfPolarizedCuspidal public import Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.IsPotCrysAtOfMono0 public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.FiniteDimensionalAdjoinRange public import Development.AbelianVarietyTheory.Definitions.AutomorphicMembership.EqOfPowEqOneOfNormSubLt public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.NonemptyEquivMultiProdOne public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.IsIrreducibleIffOfLinearEquiv
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_toPEquiv___redArg(lean_object*);
lean_object* lp_mathlib_PEquiv_toMatrix(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PermPrin_permGL___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PermPrin_permGL(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PermPrin_permGL___redArg(lean_object* v_inst_1_, lean_object* v_n_2_, lean_object* v_00_u03c3_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v_toSemiring_6_; lean_object* v___x_7_; lean_object* v_toZero_8_; lean_object* v___x_10_; uint8_t v_isShared_11_; uint8_t v_isSharedCheck_26_; 
v___x_4_ = lp_mathlib_Field_toSemifield___redArg(v_inst_1_);
v___x_5_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_4_);
v_toSemiring_6_ = lean_ctor_get(v___x_5_, 0);
lean_inc_ref(v_toSemiring_6_);
lean_dec_ref(v___x_5_);
v___x_7_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_6_);
v_toZero_8_ = lean_ctor_get(v___x_7_, 1);
v_isSharedCheck_26_ = !lean_is_exclusive(v___x_7_);
if (v_isSharedCheck_26_ == 0)
{
lean_object* v_unused_27_; 
v_unused_27_ = lean_ctor_get(v___x_7_, 0);
lean_dec(v_unused_27_);
v___x_10_ = v___x_7_;
v_isShared_11_ = v_isSharedCheck_26_;
goto v_resetjp_9_;
}
else
{
lean_inc(v_toZero_8_);
lean_dec(v___x_7_);
v___x_10_ = lean_box(0);
v_isShared_11_ = v_isSharedCheck_26_;
goto v_resetjp_9_;
}
v_resetjp_9_:
{
lean_object* v___x_12_; lean_object* v_toRing_13_; lean_object* v___x_14_; lean_object* v_toAddMonoidWithOne_15_; lean_object* v_toOne_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_24_; 
v___x_12_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_13_ = lean_ctor_get(v___x_12_, 0);
lean_inc_ref(v_toRing_13_);
lean_dec_ref(v___x_12_);
v___x_14_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_13_);
v_toAddMonoidWithOne_15_ = lean_ctor_get(v___x_14_, 1);
lean_inc_ref(v_toAddMonoidWithOne_15_);
lean_dec_ref(v___x_14_);
v_toOne_16_ = lean_ctor_get(v_toAddMonoidWithOne_15_, 2);
lean_inc_n(v_toOne_16_, 2);
lean_dec_ref(v_toAddMonoidWithOne_15_);
v___x_17_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_17_, 0, v_n_2_);
lean_inc_ref(v_00_u03c3_3_);
v___x_18_ = lp_mathlib_Equiv_toPEquiv___redArg(v_00_u03c3_3_);
lean_inc(v_toZero_8_);
lean_inc_ref(v___x_17_);
v___x_19_ = lean_alloc_closure((void*)(lp_mathlib_PEquiv_toMatrix), 9, 7);
lean_closure_set(v___x_19_, 0, lean_box(0));
lean_closure_set(v___x_19_, 1, lean_box(0));
lean_closure_set(v___x_19_, 2, lean_box(0));
lean_closure_set(v___x_19_, 3, v___x_17_);
lean_closure_set(v___x_19_, 4, v_toZero_8_);
lean_closure_set(v___x_19_, 5, v_toOne_16_);
lean_closure_set(v___x_19_, 6, v___x_18_);
v___x_20_ = lp_mathlib_Equiv_symm___redArg(v_00_u03c3_3_);
v___x_21_ = lp_mathlib_Equiv_toPEquiv___redArg(v___x_20_);
v___x_22_ = lean_alloc_closure((void*)(lp_mathlib_PEquiv_toMatrix), 9, 7);
lean_closure_set(v___x_22_, 0, lean_box(0));
lean_closure_set(v___x_22_, 1, lean_box(0));
lean_closure_set(v___x_22_, 2, lean_box(0));
lean_closure_set(v___x_22_, 3, v___x_17_);
lean_closure_set(v___x_22_, 4, v_toZero_8_);
lean_closure_set(v___x_22_, 5, v_toOne_16_);
lean_closure_set(v___x_22_, 6, v___x_21_);
if (v_isShared_11_ == 0)
{
lean_ctor_set(v___x_10_, 1, v___x_22_);
lean_ctor_set(v___x_10_, 0, v___x_19_);
v___x_24_ = v___x_10_;
goto v_reusejp_23_;
}
else
{
lean_object* v_reuseFailAlloc_25_; 
v_reuseFailAlloc_25_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_25_, 0, v___x_19_);
lean_ctor_set(v_reuseFailAlloc_25_, 1, v___x_22_);
v___x_24_ = v_reuseFailAlloc_25_;
goto v_reusejp_23_;
}
v_reusejp_23_:
{
return v___x_24_;
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_PermPrin_permGL(lean_object* v_k_28_, lean_object* v_inst_29_, lean_object* v_n_30_, lean_object* v_00_u03c3_31_){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lp_tree_GlobalTheory_PermPrin_permGL___redArg(v_inst_29_, v_n_30_, v_00_u03c3_31_);
return v___x_32_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_RingSpecNormalisedCharacterEq(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_GaloisRepOfPolarizedCuspidal(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IsPotCrysAtOfMono0(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FiniteDimensionalAdjoinRange(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_EqOfPowEqOneOfNormSubLt(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivMultiProdOne(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_IsIrreducibleIffOfLinearEquiv(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IsSubquotientUnramPrinSeriesOfHasSupport(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_RingSpecNormalisedCharacterEq(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_GaloisCohomology_u2082_GaloisRepOfPolarizedCuspidal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_IsPotCrysAtOfMono0(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_FiniteDimensionalAdjoinRange(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_AutomorphicMembership_EqOfPowEqOneOfNormSubLt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_NonemptyEquivMultiProdOne(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_IsIrreducibleIffOfLinearEquiv(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif

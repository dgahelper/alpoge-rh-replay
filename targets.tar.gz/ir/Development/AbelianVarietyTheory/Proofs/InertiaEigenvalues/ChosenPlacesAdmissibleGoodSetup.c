// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.ChosenPlacesAdmissibleGoodSetup
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.ExistsIsScalar public import Formalism.LocalToGlobal.IndefiniteReal.ConcretePkgSpec public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.FinPartConjMem
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_mathlib_Rat_commSemiring;
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_DivisionRing_toRatAlgebra___redArg(lean_object*);
lean_object* lp_tree_Formalism_HC_HostRaw_conj(lean_object*, lean_object*);
lean_object* lp_mathlib_AlgEquiv_instFunLike___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_NumberField_RingOfIntegers_mapRingHom___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChoiceAdm_cnj(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ChoiceAdm_cnj(lean_object* v_D_1_){
_start:
{
lean_object* v___x_2_; lean_object* v_host_3_; lean_object* v_toHostAx_4_; lean_object* v_R_5_; lean_object* v_instField_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v_toSemiring_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v_toFrame_12_; lean_object* v___x_13_; lean_object* v___x_19__overap_14_; lean_object* v___x_15_; lean_object* v___f_16_; 
v___x_2_ = lp_mathlib_Rat_commSemiring;
v_host_3_ = lean_ctor_get(v_D_1_, 1);
v_toHostAx_4_ = lean_ctor_get(v_host_3_, 0);
lean_inc_ref(v_toHostAx_4_);
v_R_5_ = lean_ctor_get(v_D_1_, 0);
lean_inc_ref(v_R_5_);
lean_dec_ref(v_D_1_);
v_instField_6_ = lean_ctor_get(v_toHostAx_4_, 3);
v___x_7_ = lp_mathlib_Field_toSemifield___redArg(v_instField_6_);
v___x_8_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_7_);
v_toSemiring_9_ = lean_ctor_get(v___x_8_, 0);
lean_inc_ref(v_toSemiring_9_);
lean_dec_ref(v___x_8_);
lean_inc_ref(v_instField_6_);
v___x_10_ = lp_mathlib_Field_toDivisionRing___redArg(v_instField_6_);
v___x_11_ = lp_mathlib_DivisionRing_toRatAlgebra___redArg(v___x_10_);
v_toFrame_12_ = lean_ctor_get(v_R_5_, 0);
lean_inc_ref(v_toFrame_12_);
lean_dec_ref(v_R_5_);
v___x_13_ = lp_tree_Formalism_HC_HostRaw_conj(v_toFrame_12_, v_toHostAx_4_);
lean_dec_ref(v_toFrame_12_);
v___x_19__overap_14_ = lp_mathlib_AlgEquiv_instFunLike___redArg(v___x_2_, v_toSemiring_9_, v_toSemiring_9_, v___x_11_, v___x_11_);
lean_dec_ref(v___x_11_);
lean_dec_ref(v_toSemiring_9_);
v___x_15_ = lean_apply_1(v___x_19__overap_14_, v___x_13_);
v___f_16_ = lean_alloc_closure((void*)(lp_mathlib_NumberField_RingOfIntegers_mapRingHom___redArg___lam__0), 2, 1);
lean_closure_set(v___f_16_, 0, v___x_15_);
return v___f_16_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ExistsIsScalar(uint8_t builtin);
lean_object* initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_ConcretePkgSpec(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FinPartConjMem(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_ChosenPlacesAdmissibleGoodSetup(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_ExistsIsScalar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_LocalToGlobal_IndefiniteReal_ConcretePkgSpec(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_FinPartConjMem(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
